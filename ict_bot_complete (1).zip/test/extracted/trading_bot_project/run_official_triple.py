#!/usr/bin/env python3
"""
run_official_triple.py — السكربت الرسمي للباكتيست
═══════════════════════════════════════════════════
يعيد بالضبط نفس النتائج اللي ظهرت بالمحادثة.

الإطار:
  BIAS: read_bias(Daily+4H) confidence ≥ 50
  NARRATIVE: read_narrative(15M) sweep quality ≥ 25  
  TRIGGER: read_trigger(5M) displacement+FVG
  PLAN: build_plan (SL 0.5-8 ATR)
  Kill Zone: London / NY AM / NY PM
  No-dup FVG: same top+bottom = skip
  Manager: manage_triple_position from ict_smart_runner.py
  Risk: A=0.6%, B=0.3%, C=0.1% (total 1%)
"""
import csv, datetime, sys, os, json, numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ict_sessions import classify_session
from ict_layered_brain import read_bias, read_narrative, read_trigger, build_plan
from ict_smart_runner import manage_triple_position, MarketReader
from ict_math_engine import detect_ict_three_candle_swings


def load_csv(path):
    rows = []
    with open(path) as f:
        for row in csv.DictReader(f):
            dt = datetime.datetime.strptime(row['datetime'], '%Y-%m-%d %H:%M')
            rows.append({
                'ts': int(dt.timestamp() * 1000),
                'dt': row['datetime'],
                'o': float(row['open']),
                'h': float(row['high']),
                'l': float(row['low']),
                'c': float(row['close']),
                'v': float(row['volume']),
            })
    return rows


def slice_data(rows, end_idx, lookback):
    s = max(0, end_idx - lookback + 1)
    chunk = rows[s:end_idx + 1]
    return {
        'timestamps': [r['ts'] for r in chunk],
        'opens': [r['o'] for r in chunk],
        'highs': [r['h'] for r in chunk],
        'lows': [r['l'] for r in chunk],
        'closes': [r['c'] for r in chunk],
        'volumes': [r['v'] for r in chunk],
    }


def aggregate(data, tf_minutes):
    n = len(data['closes'])
    ratio = tf_minutes // 5
    if n < ratio:
        return None
    m = n // ratio
    out = {'timestamps': [], 'opens': [], 'highs': [], 'lows': [], 'closes': [], 'volumes': []}
    for i in range(m):
        s, e = i * ratio, (i + 1) * ratio
        out['timestamps'].append(data['timestamps'][s])
        out['opens'].append(data['opens'][s])
        out['highs'].append(max(data['highs'][s:e]))
        out['lows'].append(min(data['lows'][s:e]))
        out['closes'].append(data['closes'][e - 1])
        out['volumes'].append(sum(data['volumes'][s:e]))
    return out


def run_month(data_path, month_prefix, label, starting_balance, risk_pct=0.01):
    """Run backtest for one month."""
    all_rows = load_csv(data_path)
    month_start = next(i for i, r in enumerate(all_rows) if r['dt'].startswith(month_prefix))
    
    EXECUTABLE_SESSIONS = {"LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"}
    
    balance = starting_balance
    trades = []
    active = None
    entered_fvgs = set()
    candle_1h_count = 0
    candle_4h_count = 0
    
    for idx in range(month_start, len(all_rows)):
        row = all_rows[idx]
        candle_1h_count += 1
        candle_4h_count += 1
        
        # ═══ MANAGE ACTIVE TRADE (every 5M candle) ═══
        if active is not None:
            c5 = {'o': row['o'], 'h': row['h'], 'l': row['l'], 'c': row['c']}
            
            # Build 1H candle every 12 × 5M
            c1h = None
            if candle_1h_count >= 12 and idx >= 12:
                c1h = {
                    'o': all_rows[idx - 11]['o'],
                    'h': max(all_rows[j]['h'] for j in range(idx - 11, idx + 1)),
                    'l': min(all_rows[j]['l'] for j in range(idx - 11, idx + 1)),
                    'c': row['c'],
                }
                candle_1h_count = 0
            
            # Build 4H candle every 48 × 5M
            c4h = None
            if candle_4h_count >= 48 and idx >= 48:
                c4h = {
                    'o': all_rows[idx - 47]['o'],
                    'h': max(all_rows[j]['h'] for j in range(idx - 47, idx + 1)),
                    'l': min(all_rows[j]['l'] for j in range(idx - 47, idx + 1)),
                    'c': row['c'],
                }
                candle_4h_count = 0
            
            events, closed = manage_triple_position(c5, c1h, c4h, active)
            
            if closed:
                active['exit_time'] = row['dt']
                pnl_dollar = active.get('pnl_pct', 0) / 100 * balance
                balance += pnl_dollar
                active['balance_after'] = round(balance, 2)
                active['pnl_dollar'] = round(pnl_dollar, 4)
                trades.append(dict(active))
                active = None
            continue
        
        # ═══ SCAN (every 12 candles = hourly) ═══
        if idx % 12 != 0:
            continue
        
        sess = classify_session(row['ts'])
        if sess['session'] not in EXECUTABLE_SESSIONS:
            continue
        
        # Build multi-TF data
        data_full = slice_data(all_rows, idx, 12000)
        data_5m = slice_data(all_rows, idx, 250)
        data_15m = aggregate(data_full, 15)
        data_4h = aggregate(data_full, 240)
        data_1d = aggregate(data_full, 1440)
        
        if not data_1d or len(data_1d['closes']) < 10:
            continue
        
        # Layer 1: BIAS
        bias = read_bias(data_1d, data_4h)
        if bias['direction'] not in ('BULLISH', 'BEARISH') or bias['confidence'] < 50:
            continue
        
        # Layer 2: NARRATIVE
        if not data_15m or len(data_15m['closes']) < 20:
            continue
        narrative = read_narrative(data_15m, bias['direction'])
        if narrative['state'] != 'SWEEP_FOUND' or narrative['sweep']['quality'] < 25:
            continue
        
        # Layer 3: TRIGGER
        trigger = read_trigger(data_5m, narrative, bias['direction'])
        if not trigger['ready']:
            continue
        
        # Layer 4: PLAN
        plan = build_plan(data_5m, data_1d, trigger, narrative, bias)
        if not plan:
            continue
        
        # No duplicate FVG
        fvg_key = (round(trigger['fvg']['top'], 2), round(trigger['fvg']['bottom'], 2))
        if fvg_key in entered_fvgs:
            continue
        entered_fvgs.add(fvg_key)
        
        is_long = bias['direction'] == 'BULLISH'
        
        # TP3 from Daily
        tp3_price = None
        if data_1d:
            sw_d = detect_ict_three_candle_swings(data_1d)
            targets_d = sw_d['swing_highs'] if is_long else sw_d['swing_lows']
            for sw in targets_d:
                if (is_long and sw['price'] > plan['entry'] + plan['risk'] * 5) or \
                   (not is_long and sw['price'] < plan['entry'] - plan['risk'] * 5):
                    tp3_price = sw['price']
                    break
        
        # ═══ BUILD TRIPLE POSITION ═══
        # Risk allocation: A=60%, B=30%, C=10% of total risk
        total_risk = risk_pct  # e.g. 0.01 = 1%
        
        active = {
            'month': label,
            'entry_time': row['dt'],
            'bias': bias['direction'],
            'is_short': not is_long,
            'atr': plan['atr'],
            'risk': plan['risk'],
            # CRITICAL: risk_pct values as PERCENTAGES for PnL calculation
            # 0.6 means "0.6% of balance" (60% of 1% total risk)
            'risk_pct_a': total_risk * 100 * 0.6,  # e.g. 1% * 100 * 0.6 = 0.6
            'risk_pct_b': total_risk * 100 * 0.3,  # = 0.3
            'risk_pct_c': total_risk * 100 * 0.1,  # = 0.1
            'pos_a': {
                'active': True,
                'entry': plan['entry'],
                'sl': plan['sl'],
                'tp1': plan['tp1']['price'],
                'tp1_hit': False,
                'pnl': 0,
            },
            'pos_b': {
                'active': True,
                'entry': plan['entry'],
                'sl': plan['sl'],
                'tp2_price': plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None,
                'be_set': False,
                'pnl': 0,
            },
            'pos_c': {
                'active': True,
                'entry': plan['entry'],
                'sl': plan['sl'],
                'tp3_price': tp3_price,
                'be_set': False,
                'pnl': 0,
            },
            'sl_atr': plan['sl_atr'],
            'conviction': plan['conviction'],
            'sweep_quality': plan['sweep_quality'],
            'tp1_rr': plan['tp1']['rr'],
            'tp2_rr': plan['tp2'].get('rr', '?') if isinstance(plan['tp2'], dict) else '?',
            'pnl_pct': 0,
            'candle_count': 0,
        }
        candle_1h_count = 0
        candle_4h_count = 0
    
    # Close remaining
    if active:
        active['exit_time'] = all_rows[-1]['dt']
        active['exit_reason_a'] = 'END_OF_DATA'
        active['exit_reason_b'] = 'END_OF_DATA'
        active['exit_reason_c'] = 'END_OF_DATA'
        active['pnl_pct'] = 0
        active['pnl_dollar'] = 0
        active['balance_after'] = round(balance, 2)
        trades.append(active)
    
    return trades, balance


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--risk', type=float, default=0.01, help='Risk per trade (0.01=1%, 0.02=2%)')
    ap.add_argument('--data-dir', default='/home/user/historical_data')
    args = ap.parse_args()
    
    risk = args.risk
    data_dir = args.data_dir
    
    mar_path = os.path.join(data_dir, 'btc_jan_mar_2025.csv')
    jun_path = os.path.join(data_dir, 'btc_apr_jun_2025.csv')
    
    # Check data files exist
    if not os.path.exists(mar_path):
        # Try to create from main file
        main_file = os.path.join(data_dir, 'BTCUSDT_5m_2017-09-01_to_2025-09-23.csv')
        if os.path.exists(main_file):
            print("Creating month data files...")
            import subprocess
            subprocess.run(f"head -1 '{main_file}' > '{mar_path}'", shell=True)
            subprocess.run(f"grep '^2025-01\\|^2025-02\\|^2025-03' '{main_file}' >> '{mar_path}'", shell=True)
            subprocess.run(f"head -1 '{main_file}' > '{jun_path}'", shell=True)
            subprocess.run(f"grep '^2025-04\\|^2025-05\\|^2025-06' '{main_file}' >> '{jun_path}'", shell=True)
        else:
            print(f"ERROR: Data files not found in {data_dir}")
            return
    
    print("=" * 80)
    print(f"  🏆 OFFICIAL TRIPLE POSITION BACKTEST — {risk*100:.0f}% Risk")
    print("=" * 80)
    
    # March
    print(f"\n📅 March 2025...")
    mar_trades, mar_bal = run_month(mar_path, '2025-03-01', 'MAR', 100.0, risk)
    
    # June (starting from March ending balance)
    print(f"📅 June 2025 (starting ${mar_bal:.2f})...")
    jun_trades, final_bal = run_month(jun_path, '2025-06-01', 'JUN', mar_bal, risk)
    
    all_trades = mar_trades + jun_trades
    decided = [t for t in all_trades if t.get('exit_reason_a', '') != 'END_OF_DATA']
    wins = [t for t in decided if t.get('pnl_pct', 0) > 0.01]
    losses = [t for t in decided if t.get('pnl_pct', 0) < -0.01]
    
    print(f"\n{'━' * 80}")
    print(f"  📊 RESULTS — $100 → ${final_bal:.2f} (+{final_bal-100:.2f})")
    print(f"{'━' * 80}")
    print(f"  Trades: {len(decided)} | Wins: {len(wins)} | Losses: {len(losses)}")
    if decided:
        print(f"  Win Rate: {len(wins)/len(decided)*100:.0f}%")
    print(f"  March:  ${mar_bal:.2f} ({mar_bal-100:+.2f})")
    print(f"  June:   ${final_bal:.2f} ({final_bal-mar_bal:+.2f})")
    
    if wins and losses:
        tw = sum(t.get('pnl_dollar', 0) for t in wins)
        tl = abs(sum(t.get('pnl_dollar', 0) for t in losses))
        if tl > 0:
            print(f"  PF: {tw/tl:.2f}")
        print(f"  Avg Win: {np.mean([t['pnl_pct'] for t in wins]):+.3f}%")
        print(f"  Avg Loss: {np.mean([t['pnl_pct'] for t in losses]):+.3f}%")
    
    # Trade details
    print(f"\n{'━' * 80}")
    print(f"  📋 TRADE DETAILS")
    print(f"{'━' * 80}")
    
    for i, t in enumerate(all_trades):
        ea = t.get('exit_reason_a', '?')
        eb = t.get('exit_reason_b', '?')
        ec = t.get('exit_reason_c', '?')
        p = t.get('pnl_pct', 0)
        pd = t.get('pnl_dollar', 0)
        
        try:
            dur = (datetime.datetime.strptime(t.get('exit_time', ''), '%Y-%m-%d %H:%M') -
                   datetime.datetime.strptime(t['entry_time'], '%Y-%m-%d %H:%M')).total_seconds() / 3600
            ds = f"{dur:.0f}h"
        except:
            ds = "?"
        
        em = '💎' if 'TP3' in ec else ('🏆' if 'TP2' in eb else ('✅' if p > 0.01 else ('❌' if p < -0.01 else '🛡️')))
        
        print(f"\n  {em} #{i+1} {t['month']} {t['entry_time']} | {t['bias']}")
        print(f"     A:{ea:10s} B:{eb:15s} C:{ec:15s}")
        print(f"     PnL: {p:+.2f}% (${pd:+.2f}) | Duration: {ds} | Bal: ${t.get('balance_after', '?')}")
    
    # Save results
    os.makedirs('matrix_results', exist_ok=True)
    results = {
        'risk': risk,
        'starting_balance': 100.0,
        'march_balance': round(mar_bal, 2),
        'final_balance': round(final_bal, 2),
        'total_return_pct': round(final_bal - 100, 2),
        'trades': len(decided),
        'wins': len(wins),
        'losses': len(losses),
        'trade_details': [
            {
                'month': t['month'],
                'entry_time': t['entry_time'],
                'exit_time': t.get('exit_time', ''),
                'bias': t['bias'],
                'pnl_pct': round(t.get('pnl_pct', 0), 3),
                'pnl_dollar': round(t.get('pnl_dollar', 0), 4),
                'balance_after': t.get('balance_after', 0),
                'exit_a': t.get('exit_reason_a', '?'),
                'exit_b': t.get('exit_reason_b', '?'),
                'exit_c': t.get('exit_reason_c', '?'),
            }
            for t in all_trades
        ],
    }
    
    with open('matrix_results/official_triple_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n  Results saved to matrix_results/official_triple_results.json")


if __name__ == '__main__':
    main()
