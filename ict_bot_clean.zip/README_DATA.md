# Data Setup Instructions

## Required Data Files
The backtest needs BTC/USDT 5-minute OHLCV data.

## Source
Download `archive 2.zip` from: https://github.com/jfjdjdieifne/aa/blob/main/archive%202.zip
Extract to get: `BTCUSDT_5m_2017-09-01_to_2025-09-23.csv`

## Generate Month Files
```bash
# Put the CSV in a 'data' directory, then:
MAIN="BTCUSDT_5m_2017-09-01_to_2025-09-23.csv"

# January + February + March 2025 (Jan = warmup for Daily bias)
head -1 "$MAIN" > btc_jan_mar_2025.csv
grep "^2025-01\|^2025-02\|^2025-03" "$MAIN" >> btc_jan_mar_2025.csv

# April + May + June 2025 (Apr+May = warmup)
head -1 "$MAIN" > btc_apr_jun_2025.csv
grep "^2025-04\|^2025-05\|^2025-06" "$MAIN" >> btc_apr_jun_2025.csv
```

## Run Backtest
```bash
python3 run_official_triple.py --risk 0.01 --data-dir /path/to/data
python3 run_official_triple.py --risk 0.02 --data-dir /path/to/data
```

## Expected Results
- 1% risk: $100 → $118.74 (PF=5.20, WR=76%)
- 2% risk: $100 → $140.36 (PF=5.06, WR=76%)
