# -*- coding: utf-8 -*-
"""
scan_last_month_michael_style_v3.py
════════════════════════════════════════════════════════════════════
تصحيح ثالث وأخير (بطلب صريح: "اشتغل متل ما مايكل بيشتغل - إذا مناخد
صفقتين تلاتة باليوم بيكفي عَ مدى شهر كامل"):

⚠️ الفجوة بالنسخة الثانية: كنت أفحص فقط اللحظة الدقيقة لافتتاح الجلسة
(08:30 أو 13:30 NY بالضبط) - لكن مايكل نفسه (كل المصادر الموثّقة) يقول
"Look for a liquidity sweep... AFTER the session opens" - السحب ممكن
يصير في أي وقت **خلال** نافذة الجلسة كاملة (2.5 ساعة لـNY AM، نفسها
لـNY PM)، لا بالضبط لحظة الافتتاح. هذا التضييق الزائد قلّص العدد بشكل
غير واقعي (6 فقط بشهر).

الحل: نفحص **كل شمعة 15m ضمن نافذة الجلسة الكاملة** (10-12 شمعة لكل
جلسة بدل شمعة واحدة)، ونسجّل **أول لحظة سحب مؤكد جديد** يظهر بأي شمعة
ضمن تلك النافذة (لا نكرر تسجيل نفس السحب أكثر من مرة لكل جلسة واحدة -
هذا يطابق حرفياً كيف يعمل تاجر حقيقي: يراقب الجلسة كاملة وينتبه أول ما
يصير السحب، لا يفحص لحظة واحدة بس ويهمل الباقي).

النوافذ (موثّقة فعلياً للكريبتو - ictkillzone.com):
  NY_AM: 08:30-11:00 NY (الأقوى - تداخل NQ/ES)
  NY_PM: 13:30-16:00 NY (ثانوية)
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from ict_sessions import compute_overnight_range, ts_to_ny

brain = BrainCore()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

ny_dates = sorted(set(ts_to_ny(ts).date() for ts in full_data["timestamps"]))
print(f"عدد الأيام الفريدة (NY calendar): {len(ny_dates)}\n")

candidates = []

# نوافذ الجلسات الكاملة (لا لحظة افتتاح واحدة فقط) - (label, start_h, start_m, end_h, end_m)
SESSION_WINDOWS = [
    ("NY_AM_KILLZONE", 8, 30, 11, 0),
    ("NY_PM_KILLZONE", 13, 30, 16, 0),
]

for day in ny_dates:
    for session_label, sh, sm, eh, em in SESSION_WINDOWS:
        tz = ts_to_ny(full_data["timestamps"][0]).tzinfo
        session_start_ny = datetime.datetime.combine(day, datetime.time(sh, sm), tzinfo=tz)
        session_end_ny = datetime.datetime.combine(day, datetime.time(eh, em), tzinfo=tz)
        session_start_ts = int(session_start_ny.timestamp() * 1000)
        session_end_ts = int(session_end_ny.timestamp() * 1000)

        # كل الشموع ضمن نافذة هذه الجلسة تحديداً
        session_indices = [i for i, ts in enumerate(full_data["timestamps"])
                            if session_start_ts <= ts < session_end_ts]
        if not session_indices:
            continue

        found_for_this_session = False  # لا نسجّل أكثر من نقطة واحدة لكل جلسة (أول سحب يظهر يكفي)

        for idx in session_indices:
            if found_for_this_session or idx < 150:
                continue

            window_data = {
                "opens": full_data["opens"][:idx+1], "highs": full_data["highs"][:idx+1],
                "lows": full_data["lows"][:idx+1], "closes": full_data["closes"][:idx+1],
                "timestamps": full_data["timestamps"][:idx+1],
            }
            cur_ts = full_data["timestamps"][idx]

            try:
                anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
            except Exception:
                continue
            daily_bias = anchor.get("anchor_direction")
            if daily_bias not in ("BULLISH", "BEARISH"):
                continue

            try:
                overnight = compute_overnight_range(window_data, cur_ts)
            except Exception:
                continue
            if not overnight.get("found"):
                continue

            range_high, range_low = overnight["range_high"], overnight["range_low"]
            # ⚠️ نفحص فقط هل السحب حصل تحديداً بهذه الشمعة (لا يتكرر
            # الإبلاغ عن نفس سحب قديم في كل شمعة لاحقة بنفس الجلسة)
            sweep_low = classify_sweep_or_run(window_data, range_low, level_is_high=False, check_from_idx=idx)
            sweep_high = classify_sweep_or_run(window_data, range_high, level_is_high=True, check_from_idx=idx)

            genuine_sweep_found = None
            if sweep_low.get("found") and sweep_low.get("classification") == "GENUINE_REVERSAL_SWEEP" and sweep_low.get("candle_index_from_end") == (idx - len(full_data["closes"][:idx+1])):
                if daily_bias == "BULLISH":
                    genuine_sweep_found = ("SSL_SWEPT_LOW", sweep_low)
            if sweep_high.get("found") and sweep_high.get("classification") == "GENUINE_REVERSAL_SWEEP" and sweep_high.get("candle_index_from_end") == (idx - len(full_data["closes"][:idx+1])):
                if daily_bias == "BEARISH":
                    genuine_sweep_found = ("BSL_SWEPT_HIGH", sweep_high)

            if genuine_sweep_found:
                sweep_type, sweep_info = genuine_sweep_found
                dt = datetime.datetime.fromtimestamp(cur_ts/1000, tz=datetime.timezone.utc)
                candidates.append({
                    "index": idx, "timestamp": cur_ts, "datetime_utc": dt.isoformat(),
                    "ny_session_trigger": session_label,
                    "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
                    "overnight_range_high": range_high, "overnight_range_low": range_low,
                    "sweep_type": sweep_type,
                })
                found_for_this_session = True

print(f"=== إجمالي النقاط المرشحة (مسح الجلسة الكاملة NY AM + NY PM): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_utc']} ({c['ny_session_trigger']})  bias={c['mechanical_bias']}({c['bias_strength']})  sweep={c['sweep_type']}")

with open("/tmp/last_month_michael_candidates_v3.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
