# -*- coding: utf-8 -*-
"""
scan_last_month_setups_v2.py
════════════════════════════════════════════════════════════════════
إعادة تصميم كاملة (بطلب صريح من المستخدم: "بدك تشتغل متل ما مايكل
بيشتغل - كيف مايكل أول ما يبلش يفتح الشارت عَ شو بيدور أول شي لحتى
يعرف إنو في صفقة محتملة هون تستاهل يقعد يحللها").

⚠️ لماذا النسخة الأولى فشلت: كانت تعيد حساب "هل يوجد PENDING_SETUP"
عند كل ساعة بمعزل - وبما أن PENDING_SETUP يسمح لشرط LTF أن يبقى معلّقاً
دائماً، أي لحظة تقريباً "تبدو مرشحة" (598 من 700 نقطة!) - غير واقعي
إطلاقاً وليس كيف يعمل مايكل فعلياً.

التسلسل الصحيح لمايكل (من [TOP_DOWN_WORKFLOW] بالدستور):
  1. Daily Bias أولاً - مستقر (يتغيّر مرة كل يوم/يومين تقريباً، ليس
     كل ساعة) - "هل اليوم بيميل صعوداً أو هبوطاً؟"
  2. ثم يبحث فقط عن **لحظة تريغر جديدة حقيقية** ضمن هذا الانحياز -
     ليس "هل توجد خطة نظرية ممكنة الآن؟" بل "هل صار شيء جديد الآن
     يستحق الانتباه؟":
       - سحب سيولة حقيقي جديد (GENUINE_REVERSAL_SWEEP) لم يكن موجوداً
         بالشمعة السابقة - Model B trigger
       - كسر هيكلي جديد (BOS/CHoCH) لم يكن مؤكداً بالشمعة السابقة -
         Model A/C/F trigger
       - دخول تازة لنافذة Kill Zone/Silver Bullet - Model D/E trigger
  3. فقط عند هذا "التريغر الجديد" (لا كل شمعة) يستحق التحليل الكامل.

هذا يقلّص العدد من 598 (غير واقعي) لعدد صغير معقول (نقاط تحوّل حقيقية
فعلاً)، تماماً كواقع تداول مايكل - "2-5 إشارات عالية الجودة يومياً"
كما ينص الدستور نفسه (قسم 1.8 MODE 1: LIVE ANALYSIS).
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, detect_mss, classify_sweep_or_run
from ict_sessions import classify_session, EXECUTABLE_SESSIONS

brain = BrainCore()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

triggers = []
prev_session = None
prev_sweep_found_at = set()  # لتفادي تكرار نفس السحب كإشارة جديدة كل شمعة

MIN_LOOKBACK = 150
STEP = 1  # الآن نفحص كل شمعة (لازم لرصد "التريغر الجديد" بدقة)، لكن الفلترة الصارمة ستقلل الناتج فعلياً

for i in range(MIN_LOOKBACK, n, STEP):
    window_data = {
        "opens": full_data["opens"][:i+1],
        "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1],
        "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    ts = full_data["timestamps"][i]

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=150)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue

    # ═══ التريغر 1: سحب سيولة حقيقي جديد بالشمعة الحالية بالذات ═══
    try:
        mss = detect_mss(window_data, swing_window=2)
        breaks = mss.get("breaks_found", [])
    except Exception:
        breaks = []
    last_break = breaks[-1] if breaks else None
    is_new_break = last_break and last_break["break_candle_index_from_end"] == -1  # الكسر حصل بالضبط بهذه الشمعة (الأحدث)
    break_matches_bias = last_break and last_break["direction"] == daily_bias

    # ═══ التريغر 2: هل الشمعة الحالية بالذات هي شمعة سحب سيولة حقيقي (الفتيل يلمس، الإغلاق يرجع) ═══
    # نفحص فقط أقرب سوينغ معاكس لاتجاه الانحياز
    is_new_genuine_sweep = False
    try:
        h = window_data["highs"]; l = window_data["lows"]
        sw = 2
        if daily_bias == "BULLISH":
            swing_lows_idx = [j for j in range(sw, i - sw) if l[j] == min(l[j-sw:j+sw+1])]
            if swing_lows_idx:
                level = l[swing_lows_idx[-1]]
                res = classify_sweep_or_run(window_data, level, level_is_high=False, check_from_idx=i)
                is_new_genuine_sweep = res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") == -1
        else:
            swing_highs_idx = [j for j in range(sw, i - sw) if h[j] == max(h[j-sw:j+sw+1])]
            if swing_highs_idx:
                level = h[swing_highs_idx[-1]]
                res = classify_sweep_or_run(window_data, level, level_is_high=True, check_from_idx=i)
                is_new_genuine_sweep = res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") == -1
    except Exception:
        pass

    # ═══ التريغر 3: دخول تازة لنافذة تنفيذ (Kill Zone) لم تكن فعّالة بالشمعة السابقة ═══
    try:
        cur_session = classify_session(ts)["session"]
        prev_session_info = classify_session(full_data["timestamps"][i-1])["session"] if i > 0 else None
        new_kz_entry = (cur_session in EXECUTABLE_SESSIONS) and (prev_session_info != cur_session)
    except Exception:
        new_kz_entry = False

    trigger_type = None
    if is_new_break and break_matches_bias:
        trigger_type = "NEW_STRUCTURAL_BREAK"
    elif is_new_genuine_sweep:
        trigger_type = "NEW_GENUINE_SWEEP"
    elif new_kz_entry:
        trigger_type = "NEW_KILLZONE_ENTRY"

    if trigger_type:
        dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
        triggers.append({
            "index": i, "timestamp": ts, "datetime_utc": dt.isoformat(),
            "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
            "trigger_type": trigger_type,
        })

print(f"=== إجمالي لحظات التريغر الحقيقية المكتشفة: {len(triggers)} ===\n")
for t in triggers:
    print(f"  [{t['index']}] {t['datetime_utc']}  bias={t['mechanical_bias']}({t['bias_strength']})  trigger={t['trigger_type']}")

with open("/tmp/last_month_triggers.json", "w") as f:
    json.dump(triggers, f, indent=2, default=str)
