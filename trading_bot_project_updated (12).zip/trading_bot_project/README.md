# 🤖 بوت تداول ICT/SMC — Nemotron 3 Ultra (عبر OpenRouter)

## البنية الحية الفعلية (23 ملف بايثون بالجذر)

المشروع له **نقطتا دخول حقيقيتان**:

### 1) `nemotron_backtest_driver.py` — الباك تيست الحقيقي (المسار الأساسي المُختبر بكل هذه الجلسات)
```
nemotron_backtest_driver.py
  └─ multi_pass_analysis.py   (محرك Top-Down 5 مراحل: Weekly→Daily→4H→1H→Entry)
       ├─ brain_core.py        (البنية التحتية: RiskManager, VerificationLayer, DataManager)
       ├─ authenticity_engine.py  (كل أدوات التحقق الرياضي المستقل)
       ├─ knowledge_sections.py   (تقسيم دستور المعرفة لحقن انتقائي حسب المرحلة)
       ├─ lesson_learning.py      (نظام "التعلّم من الدرس لا حفظ الصفقة")
       └─ nemotron_openrouter_client.py  (الاتصال الفعلي بـ Nemotron 3 Ultra)
```

### 2) `main.py` — الواجهة الحية العادية (يدعم Gemini/Groq/OpenRouter حسب `.env`)
```
main.py
  ├─ brain_core.py
  ├─ ai_client.py              (طبقة موحّدة متعددة المزوّدين)
  ├─ backtest_engine.py
  ├─ known_setups_finder.py    (اكتشاف صفقات تاريخية موضوعياً)
  ├─ market_scanner.py
  └─ signal_tracker.py, signal_repository.py, signal_schema.py
```

### ملفات مشتركة بين المسارين
`config.py`, `data_manager.py`, `technical_analyzer.py`, `risk_manager.py`,
`verification_layer.py`, `memory_system.py`, `learning_manager.py`,
`nemotron_knowledge_audit.py`.

---

## 📁 مجلد `data/` — بيانات حية فعلياً (لا شيء زائد)
| الملف | الاستخدام |
|---|---|
| `trading_knowledge.txt` | دستور المعرفة الكامل (~750K حرف، 26 قسم) |
| `memory.json` | سجل صفقات/أحداث خام (`memory_system.py`) |
| `lessons.json` | دروس مجرّدة مُتعلَّمة (`lesson_learning.py`) |
| `cf_ai_ok.json` | مفاتيح Cloudflare معروفة الصلاحية (`ai_client.py`) |

## 📁 مجلد `ict_source_material/` — مرجع خام (مذكور بتعليقات الكود)
مواد ICT الأصلية المستخدَمة كمرجع بحثي أثناء بناء `authenticity_engine.py`
و`multi_pass_analysis.py` (SMT Divergence، إلخ).

## 📁 مجلد `nemotron_training_logs/` — كل سجلات الجلسات والتوثيق
- `SESSION_LOG_2026-07-05.md` — السجل التفصيلي الكامل (18+ اكتشاف).
- `ARCHIVE_MASTER_SUMMARY_2026-07-06.md` — أرشيف شامل قابل لبدء جلسة جديدة منه.
- `human_trades_backtest_data/` — كل بيانات الصفقات البشرية ونتائج الاختبار،
  مقسّمة لمجلدات فرعية (`swing_point_fix_investigation/`,
  `raw_collection_batches/`) حسب الموضوع.

## 📁 مجلد `legacy/` — كود قديم/جانبي محفوظ (لا حذف نهائي، فقط أُبعد عن المسار الحي)
راجع `legacy/README.md` للتفصيل الكامل لكل ملف ولماذا انتقل.

---

## ⚠️ ملاحظة أمنية موروثة
ملف `.env` يحوي مفاتيح API فعلية. **لا تُشارك هذا المشروع علناً بدون حذفها
أولاً.**

## القيود الصارمة المفروضة على أي صفقة (غير قابلة للتفاوض)
- **R:R ≥ 3:1**
- **SL ≤ 2.5%** من سعر الدخول
راجع `[RISK_ENGINE]` بـ `data/trading_knowledge.txt` والفحوصات البرمجية
المقابلة بـ `multi_pass_analysis.py::_diagnose_trade_plan`.
