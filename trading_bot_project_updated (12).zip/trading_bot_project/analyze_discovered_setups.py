# -*- coding: utf-8 -*-
"""
analyze_discovered_setups.py
════════════════════════════════════════════════════════════════════
يحلل النقاط المكتشفة (من scan_last_month_michael_style_v7.py) بمحرك
multi_pass_analysis الكامل (5 مراحل، نداء API حقيقي لكل مرحلة) -
بيانات متاحة فقط حتى لحظة كل نقطة (end_ts = timestamp النقطة)، بلا
أي تسريب مستقبلي - نفس آلية run_human_trades_backtest تماماً.

فقط بعد اكتمال قرار البوت (BUY/SELL/HOLD)، نفحص المستقبل لحساب
النتيجة الفعلية (TP_HIT/SL_HIT) - لا قبل ذلك إطلاقاً.
"""
import sys, json, time, logging
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from multi_pass_analysis import MultiPassAnalysis
from human_trades_backtest import compute_trade_outcome

SYMBOL = "ETH/USDT"
TIMEFRAME = "5m"  # فريم تنفيذ (Entry TF) - نفس الفريم المستخدم بباقي الجلسة

with open("/tmp/last_month_final_unique.json") as f:
    all_candidates = json.load(f)

# نأخذ فقط أول N نقطة (batch) - مُمرَّرة كـ argv[1] (افتراضي: أول 5)
batch_size = int(sys.argv[1]) if len(sys.argv) > 1 else 5
start_idx = int(sys.argv[2]) if len(sys.argv) > 2 else 0
batch = all_candidates[start_idx:start_idx + batch_size]

brain = BrainCore()
mpa = MultiPassAnalysis(brain)

results = []
for i, cand in enumerate(batch):
    end_ts = cand["timestamp"]
    print(f"\n{'='*80}\n[{start_idx+i+1}/{len(all_candidates)}] تحليل النقطة: {cand['datetime_utc']} (bias مسبق={cand['mechanical_bias']})\n{'='*80}")

    try:
        entry_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, TIMEFRAME, end_ts, limit=300)
        entry_ind = {}
        try:
            entry_ind = brain.ta.compute_all(entry_data) if hasattr(brain, "ta") else {}
        except Exception:
            entry_ind = {}

        mtf_data = {"entry": entry_data}
        mtf_indicators = {"entry": entry_ind}

        t0 = time.time()
        analysis = mpa.run(SYMBOL, TIMEFRAME, mtf_data, mtf_indicators, is_backtest=True, end_ts=end_ts)
        elapsed = time.time() - t0

        signal = analysis.get("signal")
        entry = analysis.get("entry")
        sl = analysis.get("stop_loss")
        tp = analysis.get("tp")
        narrative = (analysis.get("narrative") or "")[:300]

        print(f"النتيجة: signal={signal} entry={entry} sl={sl} tp={tp} (استغرق {elapsed:.1f}s)")
        print(f"السرد: {narrative}")

        outcome = None
        if signal in ("BUY", "SELL", "BUY_LIMIT", "SELL_LIMIT") and all(
            isinstance(v, (int, float)) for v in (entry, sl, tp)
        ):
            is_short = signal in ("SELL", "SELL_LIMIT")
            outcome = compute_trade_outcome(brain, SYMBOL, end_ts, entry, sl, tp, is_short)
            print(f"النتيجة الفعلية (بعد التحليل فقط): {outcome.get('outcome')} pnl={outcome.get('pnl_pct')}")

        results.append({
            "candidate": cand, "signal": signal, "entry": entry, "sl": sl, "tp": tp,
            "narrative": narrative, "elapsed_sec": elapsed, "outcome": outcome,
            "full_analysis": {k: v for k, v in analysis.items() if k != "multi_pass_stage_log"},
        })
    except Exception as e:
        print(f"خطأ: {e}")
        results.append({"candidate": cand, "error": str(e)})

    # حفظ تراكمي بعد كل نقطة (يسمح بالاستئناف لو انقطع التشغيل)
    out_file = f"/tmp/discovered_setups_results_{start_idx}_{start_idx+len(batch)}.json"
    with open(out_file, "w") as f:
        json.dump(results, f, indent=2, default=str)

print(f"\n\n=== انتهى - {len(results)} نقطة محلَّلة، محفوظة بـ {out_file} ===")
