import sys, json
sys.path.insert(0, ".")
import logging
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from multi_pass_analysis import MultiPassAnalysis

brain = BrainCore()
mp = MultiPassAnalysis(brain)

trades = json.load(open("human_trades/all_human_trades_with_outcomes.json"))
trade = [t for t in trades if t["id"] == 7][0]
symbol = trade["symbol"]
end_ts = trade["publish_ts"]

timeframe = "5m"
entry_data = brain.data_manager.fetch_ohlcv_up_to(symbol, timeframe, end_ts, limit=300)
entry_ind = brain.ta.compute_all(entry_data)

mtf_data = {"entry": entry_data}
mtf_indicators = {"entry": entry_ind}

result = mp.run(symbol, timeframe, mtf_data, mtf_indicators, is_backtest=True, end_ts=end_ts)

with open("/tmp/trade7_full_result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False, default=str)

print("=== FINAL ===")
print(result.get("signal"), result.get("bias"))
print()
stage_log = result.get("multi_pass_stage_log", {})
for stage in ("weekly", "daily", "h4", "h15"):
    print(f"=== {stage.upper()} ===")
    print(json.dumps(stage_log.get(stage, {}), indent=2, ensure_ascii=False)[:2000])
    print()
