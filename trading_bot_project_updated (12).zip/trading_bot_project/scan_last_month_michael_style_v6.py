# -*- coding: utf-8 -*-
"""
scan_last_month_michael_style_v6.py
════════════════════════════════════════════════════════════════════
تصحيح سادس ونهائي (بطلب صريح: "شو شروط تحقق صفقة الICT حسب مايكل -
بتدور ع أول شرط أو شرطين... هدول بيلتقو بالسوق فبيستاهل نحلل لنشوف
كمالة الصفقة لوين رايحة").

⚠️ الفجوة الحقيقية المُكتشفة بكل المحاولات السابقة: كنا نبحث إما عن
"كل شروط النموذج الكامل تحقّقت" (نادر جداً - 4-14 بالشهر) أو "أي سحب
لأي سوينغ محلي عشوائي" (كثير جداً جداً - 380-598). الفجوة الحقيقية:
لم نميّز بين سوينغ "مهم فعلاً" (Major/Moderate بمعيار Topographic
Prominence - نفس أداة detect_significant_swings المستخدمة أصلاً
بمحرك وزن الأدلة اليوم) وسوينغ "محلي عشوائي" (أي نتوء صغير بنافذة
2 شمعة، بغض النظر عن أهميته الحقيقية).

المعيار الصحيح (أول شرطين فقط - "يستاهل نقعد نحلل"، لا القصة كاملة):
  1. انحياز يومي حتمي واضح (BULLISH/BEARISH، من compute_mechanical_
     bias_anchor - نفس أداة المشروع).
  2. سحب سيولة حقيقي (GENUINE_REVERSAL_SWEEP) لسوينغ **مهم فعلاً**
     (MAJOR أو MODERATE حسب detect_significant_swings - لا أي سوينغ
     محلي عشوائي) بعكس اتجاه الانحياز، يحصل الآن تحديداً (لا حصل
     سابقاً - نتأكد إنها المرة الأولى لهذا السوينغ بالذات).

هذا بالضبط يطابق كيف يفكر مايكل فعلياً (من البحث الموثّق سابقاً):
"Look for a liquidity sweep of the previous range high or low" -
لكن "the previous range" يعني مستوى ذو أهمية حقيقية (سوينغ رئيسي)،
لا أي تعرّج صغير - نفس فلسفة قسم 3.5 بدستورنا (Minor vs Major Swings).
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

candidates = []
already_reported_swing_price = set()  # لتفادي الإبلاغ عن نفس السوينغ المسحوب مرتين

MIN_LOOKBACK = 150

for i in range(MIN_LOOKBACK, n):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue

    # ⚠️ الشرط الثاني: سحب حقيقي لسوينغ MAJOR/MODERATE فقط (لا أي
    # سوينغ محلي عشوائي) - نستخدم detect_significant_swings (نفس
    # أداة محرك وزن الأدلة اليوم) لتحديد المرشحين الجديين فقط
    try:
        sig = ae.detect_significant_swings(window_data, swing_window=2, lookback_candles=150)
    except Exception:
        continue

    genuine_sweep_found = None
    if daily_bias == "BULLISH":
        # نبحث سحب سيولة سفلي (SSL) لأهم قاع حديث (المرشح الأقرب زمنياً من المهمين)
        important_lows = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        if important_lows:
            candidate = important_lows[-1]  # الأحدث زمنياً من المهمين
            level_price = candidate["price"]
            if level_price not in already_reported_swing_price:
                res = classify_sweep_or_run(window_data, level_price, level_is_high=False, check_from_idx=i)
                n_window = len(window_data["closes"])
                if (res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP"
                        and res.get("candle_index_from_end") == (i - n_window)):
                    genuine_sweep_found = ("SSL_SWEPT_LOW", level_price, candidate["tier"])
    else:
        important_highs = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        if important_highs:
            candidate = important_highs[-1]
            level_price = candidate["price"]
            if level_price not in already_reported_swing_price:
                res = classify_sweep_or_run(window_data, level_price, level_is_high=True, check_from_idx=i)
                n_window = len(window_data["closes"])
                if (res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP"
                        and res.get("candle_index_from_end") == (i - n_window)):
                    genuine_sweep_found = ("BSL_SWEPT_HIGH", level_price, candidate["tier"])

    if genuine_sweep_found:
        sweep_type, level_price, tier = genuine_sweep_found
        already_reported_swing_price.add(level_price)
        ts = full_data["timestamps"][i]
        dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
        candidates.append({
            "index": i, "timestamp": ts, "datetime_utc": dt.isoformat(),
            "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
            "sweep_type": sweep_type, "swept_level_price": level_price, "swept_level_tier": tier,
        })

print(f"=== إجمالي النقاط المرشحة (أول شرطين فقط: bias + سحب حقيقي لسوينغ MAJOR/MODERATE): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_utc']}  bias={c['mechanical_bias']}({c['bias_strength']})  sweep={c['sweep_type']} level={c['swept_level_price']:.2f}({c['swept_level_tier']})")

with open("/tmp/last_month_michael_candidates_v6.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
