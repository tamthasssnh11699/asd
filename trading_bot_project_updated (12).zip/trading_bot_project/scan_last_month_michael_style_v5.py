# -*- coding: utf-8 -*-
"""
scan_last_month_michael_style_v5.py
════════════════════════════════════════════════════════════════════
تصحيح خامس ونهائي (بطلب صريح: "وسّع مصادر السيولة المفحوصة، مو بس
overnight range"): بدل بناء منطق سحب منفصل، نستخدم **بالضبط نفس
الأداة الحقيقية المستخدمة أصلاً بالبوت الحي** - evaluate_model_b()
من ict_entry_checklist_engine.py - والتي تفحص **أي سوينغ حقيقي**
(لا فقط نطاق الليل) كمرشح سيولة للسحب، تماماً كما يفعل البوت الفعلي
عند تحليل أي صفقة حقيقية طوال هذه الجلسة.

هذا يضمن التطابق الكامل: أي نقطة "مرشحة" هنا هي بالضبط نقطة كان
البوت سيعتبرها Model B مؤهلة لو حُلِّلت مباشرة - لا معيار مستقل مخترع.

⚠️ صدق منهجي: لا فحص "هل تحرك السعر فعلاً بعدها" - المعيار الوحيد هو
evaluate_model_b (نفس أداة المشروع الحقيقية) يعطي status READY أو
PENDING_SETUP لأول مرة عند نقطة زمنية معينة (لا يتكرر الإبلاغ لكل
شمعة تالية طالما نفس السحب قائماً - نسجّل فقط "أول ظهور" لكل نمط).
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor
from ict_entry_checklist_engine import evaluate_model_b

brain = BrainCore()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

candidates = []
last_reported_sweep_idx = {"BULLISH": None, "BEARISH": None}  # لتفادي تكرار نفس السحب كل شمعة تالية
MIN_LOOKBACK = 150
STEP = 1  # نفحص كل شمعة (لازم لضبط "أول ظهور" بدقة زمنية)

for i in range(MIN_LOOKBACK, n, STEP):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue

    try:
        result_b = evaluate_model_b(window_data, daily_bias)
    except Exception:
        continue

    if result_b.get("status") not in ("READY", "PENDING_SETUP"):
        continue

    # نستخرج مؤشر شمعة السحب المُستخدَم فعلياً (evidence_anchor_idx إن وُجد بالخطة)
    plan = result_b.get("plan")
    sweep_idx = plan.get("evidence_anchor_idx") if plan else None
    if sweep_idx is None:
        continue

    # لا نُبلّغ عن نفس السحب مرتين (لو ظل قائماً عدة شموع متتالية)
    if last_reported_sweep_idx[daily_bias] == sweep_idx:
        continue
    last_reported_sweep_idx[daily_bias] = sweep_idx

    ts = full_data["timestamps"][i]
    dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
    candidates.append({
        "index": i, "timestamp": ts, "datetime_utc": dt.isoformat(),
        "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
        "model_status": result_b.get("status"),
        "sweep_evidence_anchor_idx": sweep_idx,
    })

print(f"=== إجمالي النقاط المرشحة (Model B الحقيقي - أي سوينغ حقيقي، لا فقط overnight range): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_utc']}  bias={c['mechanical_bias']}({c['bias_strength']})  status={c['model_status']}")

with open("/tmp/last_month_michael_candidates_v5.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
