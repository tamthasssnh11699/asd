import sys, json
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import classify_sweep_or_run, detect_mss

brain = BrainCore()
trades = json.load(open("human_trades/all_human_trades_with_outcomes.json"))
trade = [t for t in trades if t["id"] == 7][0]
symbol = trade["symbol"]
end_ts = trade["publish_ts"]

daily_data = brain.data_manager.fetch_ohlcv_up_to(symbol, "1d", end_ts, limit=90)
n = len(daily_data["closes"])
lows = daily_data["lows"]
closes = daily_data["closes"]

print("=== فحص منطقة 59,000-61,000 (هل فيها سحوبات متكررة = استنزاف؟) ===")
for i in range(n):
    if 58000 <= lows[i] <= 62000:
        print(f"  idx_from_end={i-n:3d}  low={lows[i]:.1f}  close={closes[i]:.1f}")

print()
print("=== نص ملاحظة البشري الأصلية ===")
print(trade.get("notes"))
print("SL البشري:", trade.get("sl"), " (تحت أي مستوى؟)")
