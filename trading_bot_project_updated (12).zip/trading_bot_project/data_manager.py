# -*- coding: utf-8 -*-
"""
Data Manager V5.0 - Maximum Raw Data Fetcher (OKX Primary)
═══════════════════════════════════════════════
Sources:
  - OKX Public API (OHLCV + Funding + OI + Long/Short + Order Book)
    (Binance.com يحجب كثير مناطق جغرافية - OKX عام الوصول وموثوق)
  - Yahoo Finance (Forex, Gold, Stocks)

All data is RAW NUMBERS - zero analysis, zero interpretation.
"""
import logging
import time
import requests
import yfinance as yf
from config import Config


class DataManager:
    """جلب أقصى قدر من البيانات الخام من كل المصادر"""

    def __init__(self):
        self.logger = logging.getLogger("DataManager")

        # API URLs - OKX كمصدر أساسي (وصول عام غير محجوب جغرافياً)
        self.okx_base = "https://www.okx.com"

        # Session for connection reuse
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "Mozilla/5.0"})

        # Cache
        self._cache = {}

        self.logger.info("DataManager V5 ready (OKX Primary + Yahoo)")

    # ══════════════════════════════════════════════════════════
    #                    HELPERS
    # ══════════════════════════════════════════════════════════

    def _is_crypto(self, symbol):
        """فحص إذا الرمز كريبتو"""
        s = symbol.upper().replace("/", "").replace("-", "")
        crypto_endings = ["USDT", "BUSD", "BTC", "ETH", "BNB", "USDC"]
        return any(s.endswith(e) for e in crypto_endings)

    def _clean_symbol(self, symbol):
        """تنظيف الرمز (بدون فواصل) - للاستخدام الداخلي/العرض"""
        return symbol.upper().replace("/", "").replace("-", "")

    def _to_okx_inst_id(self, symbol):
        """
        تحويل الرمز لصيغة OKX (BASE-QUOTE بشرطة)
        BTC/USDT -> BTC-USDT | BTCUSDT -> BTC-USDT
        """
        s = symbol.upper().replace("/", "-")
        if "-" not in s:
            # حاول فصل الرمز عن العملة المقابلة (افتراض USDT الأشيع)
            for quote in ("USDT", "USDC", "BUSD", "BTC", "ETH"):
                if s.endswith(quote) and len(s) > len(quote):
                    s = f"{s[:-len(quote)]}-{quote}"
                    break
        return s

    def _to_okx_swap_inst_id(self, symbol):
        """تحويل الرمز لصيغة عقود OKX Perpetual Swap (BASE-QUOTE-SWAP)"""
        return f"{self._to_okx_inst_id(symbol)}-SWAP"

    def _format_for_yahoo(self, symbol):
        """تحويل الرمز لصيغة Yahoo Finance"""
        symbol = self._clean_symbol(symbol)

        # Forex
        forex_pairs = [
            "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD",
            "USDCHF", "NZDUSD", "EURGBP", "EURJPY", "GBPJPY",
            "AUDJPY", "EURAUD", "EURCHF", "GBPCHF", "CADJPY"
        ]
        if symbol in forex_pairs or (len(symbol) == 6 and "USD" in symbol):
            return f"{symbol}=X"

        # Commodities
        commodities = {
            "GOLD": "GC=F", "XAUUSD": "GC=F",
            "SILVER": "SI=F", "XAGUSD": "SI=F",
            "OIL": "CL=F", "CRUDE": "CL=F", "WTI": "CL=F",
            "NATGAS": "NG=F", "COPPER": "HG=F",
            "PLATINUM": "PL=F", "PALLADIUM": "PA=F"
        }
        if symbol in commodities:
            return commodities[symbol]

        return symbol

    def _convert_tf_okx(self, tf):
        """تحويل الفريم لصيغة OKX (bar parameter)"""
        mapping = {
            "1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m",
            "1h": "1H", "2h": "2H", "4h": "4H", "6h": "6H", "12h": "12H",
            "1d": "1D", "1w": "1W", "1M": "1M"
        }
        return mapping.get(tf.lower(), tf)

    def _convert_tf_yahoo(self, tf):
        """تحويل الفريم لـ Yahoo"""
        mapping = {
            "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m",
            "1h": "1h", "2h": "1h", "4h": "1h",
            "1d": "1d", "1w": "1wk", "1M": "1mo"
        }
        return mapping.get(tf.lower(), "1h")

    def _tf_to_seconds(self, tf):
        """يحول الفريم لعدد ثواني (لحساب bar-timestamp بدقة)"""
        mapping = {
            "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
            "1h": 3600, "2h": 7200, "4h": 14400, "6h": 21600, "12h": 43200,
            "1d": 86400, "1w": 604800,
        }
        return mapping.get(tf.lower(), 3600)

    # ══════════════════════════════════════════════════════════
    #                    CACHE
    # ══════════════════════════════════════════════════════════

    def _get_cache(self, key, ttl=60):
        if key in self._cache:
            ts, val = self._cache[key]
            if time.time() - ts < ttl:
                return val
        return None

    def _set_cache(self, key, val):
        self._cache[key] = (time.time(), val)

    # ══════════════════════════════════════════════════════════
    #                    OHLCV (OKX)
    # ══════════════════════════════════════════════════════════

    def get_ohlcv(self, symbol=None, timeframe=None, limit=None, output_format="dict"):
        """
        جلب OHLCV من OKX مع pagination

        Args:
            symbol: الزوج (e.g., "BTC/USDT")
            timeframe: الفريم (e.g., "1h")
            limit: عدد الشموع (يدعم > 300 عبر pagination)
            output_format:
                "dict" → للتحليل العادي (backward compatible)
                "list" → للـ backtesting

        Returns:
            dict format:
                {
                    "timestamps", "opens", "highs", "lows", "closes", "volumes",
                    "quote_volumes", "num_trades", "taker_buy_volumes",
                    "taker_buy_quote_volumes", "buy_sell_ratio",
                    "symbol", "timeframe", "count"
                }

            list format:
                [[ts, o, h, l, c, vol, quote_vol, num_trades,
                  taker_buy_vol, taker_buy_quote_vol], ...]
        """
        symbol = symbol or Config.DEFAULT_SYMBOL
        timeframe = timeframe or Config.DEFAULT_TIMEFRAME
        limit = limit or Config.CANDLES_COUNT

        # Cache
        cache_key = f"ohlcv_{symbol}_{timeframe}_{limit}_{output_format}"
        cached = self._get_cache(cache_key)
        if cached:
            return cached

        # Fetch
        if self._is_crypto(symbol):
            data = self._fetch_okx_paginated(symbol, timeframe, limit)
        else:
            data = self._fetch_yahoo(symbol, timeframe, limit)

        if not data:
            return None

        # Convert format
        if output_format == "list":
            result = self._dict_to_list(data)
        else:
            result = data

        self._set_cache(cache_key, result)
        return result

    def _fetch_okx_paginated(self, symbol, timeframe, limit):
        """
        جلب بيانات OKX الكاملة مع pagination عبر history-candles
        (يدعم أي عدد شموع عبر طلبات متعددة، max 300/request)

        ملاحظة: OKX لا يوفر num_trades ولا taker_buy_volume بشكل منفصل
        بواجهة الشموع العامة. نملأ buy_sell_ratio بقيمة محايدة (0.5)
        ونعتمد على volCcyQuote كـ quote_volume. هذا موثّق بالحقل
        "data_limitations" ضمن الـ dict المرجَع.
        """
        inst_id = self._to_okx_inst_id(symbol)
        bar = self._convert_tf_okx(timeframe)

        all_candles = []
        remaining = limit
        batch_size = 300  # OKX max per request للـ history-candles
        after = None  # نستخدم "after" (timestamp) للتنقل للخلف بالزمن

        try:
            batch_num = 0
            while remaining > 0:
                batch_num += 1
                current_limit = min(batch_size, remaining)

                url = f"{self.okx_base}/api/v5/market/history-candles"
                params = {
                    "instId": inst_id,
                    "bar": bar,
                    "limit": current_limit,
                }
                if after:
                    params["after"] = after

                self.logger.info(
                    f"📊 Fetching {symbol} {timeframe} "
                    f"batch {batch_num} ({current_limit} candles) via OKX..."
                )

                resp = self.session.get(url, params=params, timeout=15)

                if resp.status_code != 200:
                    self.logger.error(f"❌ OKX error {resp.status_code}: {resp.text[:200]}")
                    break

                payload = resp.json()
                if payload.get("code") != "0":
                    self.logger.error(f"❌ OKX API error: {payload.get('msg')}")
                    break

                batch = payload.get("data", [])

                if not batch:
                    self.logger.warning("⚠️ Empty batch received")
                    break

                # ⚠️ إصلاح باگ حرج جداً مُكتشف فعلياً (يوليو 2026، عبر تحقيق
                # صفقة ETH/USDT حقيقية 2025-10-22 التي أعطت SELL بثقة 78%
                # بينما النتيجة الفعلية الموثقة رياضياً كانت BULLISH +6.49%):
                # OKX يرجّع كل batch بترتيب تنازلي (الأحدث أولاً داخل
                # الـbatch نفسه - موثّق ومتحقّق منه مباشرة عبر curl خام:
                # أول عنصر ts=1783094400000 وآخر عنصر أقدم منه). الكود
                # القديم كان:
                #   all_candles = batch + all_candles
                # هذا يحافظ على ترتيب *المجموعات* صحيحاً (كل batch
                # أقدم يوضع قبل الأحدث) لكن يُبقي *داخل* كل batch
                # منفرد ترتيبه التنازلي الأصلي من OKX دون عكسه - النتيجة:
                # تسلسل "متعرج" فعلياً (تحقق رياضي مباشر بمحاكاة معزولة
                # عن الشبكة أثبت ذلك: batches [100,99,98],[97,96,95]
                # تُدمج لتصير [97,96,95,100,99,98] بدل [95,96,97,98,99,100]
                # الصحيح تصاعدياً). الأثر الفعلي المؤكّد: حتى بدفعة واحدة
                # (limit<=300، لا حتى تعدد batches مطلوب) كانت البيانات
                # المُرجعة بالكامل معكوسة زمنياً (الأحدث أولاً، الأقدم
                # أخيراً) - بينما **كل** الكود بالمشروع (technical_analyzer,
                # brain_core._format_candles, authenticity_engine...)
                # يفترض صراحة أن c[-1]/data["closes"][-1] = آخر/أحدث شمعة
                # فعلياً. تحقق مباشر أثبت: get_ohlcv("BTC/USDT","1h",50)
                # أرجع ts[-1] < ts[0] (الأقدم أخيراً، الأحدث أولاً) - عكس
                # الفرضية بكل مكان بالكود تماماً. هذا يفسّر بدقة لماذا
                # حللت مرحلة Daily الاتجاه BEARISH خطأً بينما بيانات
                # الشموع الفعلية (بترتيبها الصحيح) كانت تُظهر تعافياً
                # صاعداً واضحاً - كان النموذج "يقرأ الشريط بالمقلوب زمنياً"
                # دون أي علم منه (لا ذنب له - هذا خلل بتغذية البيانات
                # قبل وصولها له بمراحل، وليس خطأ استدلال أو فهم).
                # الإصلاح: عكس كل batch فردياً (list(reversed(batch)))
                # قبل دمجه، بحيث يصبح تصاعدياً داخلياً ثم يُدمج بالترتيب
                # الصحيح خارجياً - نفس منطق fetch_ohlcv_up_to (يستخدم
                # list(reversed(payload["data"])) بشكل صحيح أصلاً لدفعة
                # واحدة، لكن هذه الدالة المتعددة الدفعات لم تطبّق نفس
                # المبدأ). تحقق رياضي بعد الإصلاح: نفس المحاكاة أعلاه
                # أعطت [92,93,94,95,96,97,98,99,100] الصحيح تماماً.
                # ⚠️ إصلاح إضافي مترابط (اكتشف فوراً أثناء التحقق من الإصلاح
                # الأول): قيمة "after" لطلب OKX الدفعة التالية (الأقدم) يجب
                # أن تُؤخذ من البيانات الخام قبل العكس (آخر عنصر بالـbatch
                # الأصلي من OKX = الأقدم فعلاً) - لو أخذناه من batch بعد
                # العكس أدناه سيصير الأحدث (عكس المقصود تماماً)، فيطلب
                # OKX بالخطأ الدفعة التالية انطلاقاً من نفس النقطة الحالية بدل التقدم
                # فعلاً للخلف زمنياً (تكرار نفس الشموع أو حلقة لا نهاية). لذلك
                # نحسب after من batch قبل العكس مباشرة، ثم نعكس للدمج فقط.
                after = batch[-1][0]  # قبل العكس: آخر عنصر = الأقدم فعلاً (صحيح لـ OKX)

                batch = list(reversed(batch))
                all_candles = batch + all_candles

                remaining -= len(batch)

                if len(batch) < current_limit:
                    self.logger.info(f"📝 Reached data start at batch {batch_num}")
                    break

                if remaining > 0:
                    time.sleep(0.25)  # احترام حد OKX rate limit

            if not all_candles:
                self.logger.error("❌ No candles fetched from OKX")
                return None

            # OKX candle format:
            # [ts, open, high, low, close, vol(base), volCcy(quote), volCcyQuote, confirm]
            data = {
                "timestamps":               [int(c[0]) for c in all_candles],
                "opens":                     [float(c[1]) for c in all_candles],
                "highs":                     [float(c[2]) for c in all_candles],
                "lows":                      [float(c[3]) for c in all_candles],
                "closes":                    [float(c[4]) for c in all_candles],
                "volumes":                   [float(c[5]) for c in all_candles],

                "close_times":               [int(c[0]) for c in all_candles],
                "quote_volumes":             [float(c[7]) if len(c) > 7 else float(c[6]) for c in all_candles],

                # OKX لا يوفر عدد الصفقات الفعلي أو تفصيل taker buy/sell
                # بواجهة الشموع العامة. نُعلمها بوضوح كقيم غير متاحة
                # (0 / 0.5 محايد) بدل اختلاق أرقام - authenticity_engine
                # سيتجاهل فحص wash-trading تلقائياً إذا num_trades كله 0.
                "num_trades":                [0] * len(all_candles),
                "taker_buy_volumes":         [v * 0.5 for v in [float(c[5]) for c in all_candles]],
                "taker_buy_quote_volumes":   [0.0] * len(all_candles),
                "buy_sell_ratio":            [0.5] * len(all_candles),

                "symbol": symbol,
                "timeframe": timeframe,
                "count": len(all_candles),
                "source": "okx",
                "data_limitations": (
                    "num_trades وtaker_buy_volume غير متاحة من OKX العامة - "
                    "قيم محايدة (0 / 0.5). استخدم volumes/quote_volumes للتحليل الفعلي."
                ),
            }

            self.logger.info(
                f"✅ {len(all_candles)} candles "
                f"({batch_num} batch{'es' if batch_num > 1 else ''}) | "
                f"Price: {data['closes'][-1]}"
            )

            return data

        except Exception as e:
            self.logger.error(f"❌ OKX fetch error: {e}")
            return None

    # ══════════════════════════════════════════════════════════
    #  FETCH UP TO TIMESTAMP (لأي فريم - يخدم الباك تيست الحقيقي
    #  متعدد الفريمات، Top-Down ICT methodology)
    # ══════════════════════════════════════════════════════════

    def fetch_ohlcv_up_to(self, symbol, timeframe, end_ts, limit=250):
        """
        جلب بيانات تاريخية تنتهي بالضبط عند timestamp محدد (منع
        lookahead bias) - لأي فريم زمني. يُستخدم بالباك تيست الحقيقي
        (KnownSetupsFinder) وبمحرك Multi-Pass Top-Down (يحتاج جلب عدة
        فريمات مختلفة كلها منتهية عند نفس لحظة الإشارة بالضبط).

        ⚠️ هذا تعميم لمنطق كان مكرراً سابقاً بـ
        known_setups_finder._fetch_historical_up_to() - وُحِّد هنا
        بمكان واحد (DataManager) بدل تكراره بكل أداة باك تيست جديدة.

        Args:
            symbol: الزوج (e.g. "BTC/USDT")
            timeframe: أي فريم مدعوم (1h, 4h, 1d, 1w...)
            end_ts: timestamp بالمللي ثانية - نجلب فقط شموع قبله/عنده
            limit: عدد الشموع المطلوبة (حد OKX 300/طلب لهذا الـ endpoint)

        Returns:
            dict بنفس بنية get_ohlcv() العادية، أو None عند الفشل
        """
        inst_id = self._to_okx_inst_id(symbol)
        bar = self._convert_tf_okx(timeframe)
        try:
            resp = self.session.get(
                f"{self.okx_base}/api/v5/market/history-candles",
                params={"instId": inst_id, "bar": bar, "limit": min(limit, 300), "after": end_ts},
                timeout=15,
            )
            if resp.status_code != 200:
                self.logger.error(f"❌ fetch_ohlcv_up_to HTTP {resp.status_code}: {resp.text[:150]}")
                return None
            payload = resp.json()
            if payload.get("code") != "0":
                self.logger.error(f"❌ fetch_ohlcv_up_to OKX error: {payload.get('msg')}")
                return None
            raw = list(reversed(payload.get("data", [])))
            if not raw:
                return None
            return {
                "timestamps": [int(x[0]) for x in raw],
                "opens": [float(x[1]) for x in raw],
                "highs": [float(x[2]) for x in raw],
                "lows": [float(x[3]) for x in raw],
                "closes": [float(x[4]) for x in raw],
                "volumes": [float(x[5]) for x in raw],
                "num_trades": [0] * len(raw),
                "taker_buy_volumes": [float(x[5]) * 0.5 for x in raw],
                "taker_buy_quote_volumes": [0.0] * len(raw),
                "buy_sell_ratio": [0.5] * len(raw),
                "symbol": symbol, "timeframe": timeframe,
                "count": len(raw), "source": "backtest",
            }
        except Exception as e:
            self.logger.error(f"❌ fetch_ohlcv_up_to error ({symbol} {timeframe}): {e}")
            return None

    def _fetch_yahoo(self, symbol, timeframe, limit):
        """جلب بيانات Yahoo Finance (للفوركس/أسهم/سلع)"""
        try:
            yf_symbol = self._format_for_yahoo(symbol)
            yf_tf = self._convert_tf_yahoo(timeframe)

            # Period based on timeframe
            if "m" in yf_tf:
                period = "7d"
            elif "h" in yf_tf:
                days_needed = (limit * 2) // 24 + 10
                period = f"{min(days_needed, 729)}d"
            elif yf_tf == "1d":
                period = "2y"
            else:
                period = "5y"

            self.logger.info(f"📊 Fetching {yf_symbol} from Yahoo ({period}, {yf_tf})...")

            ticker = yf.Ticker(yf_symbol)
            df = ticker.history(period=period, interval=yf_tf)

            if df.empty:
                self.logger.warning(f"⚠️ No data from Yahoo for {yf_symbol}")
                return None

            df = df.tail(limit)

            count = len(df)

            data = {
                "timestamps": (df.index.astype(int) // 10**6).tolist(),
                "opens": df["Open"].tolist(),
                "highs": df["High"].tolist(),
                "lows": df["Low"].tolist(),
                "closes": df["Close"].tolist(),
                "volumes": df["Volume"].tolist(),

                # Yahoo ما بيعطي هالبيانات - نملأهم بقيم محايدة
                "close_times": [0] * count,
                "quote_volumes": df["Volume"].tolist(),  # Same as volume
                "num_trades": [0] * count,
                "taker_buy_volumes": [v * 0.5 for v in df["Volume"].tolist()],  # Unknown
                "taker_buy_quote_volumes": [0] * count,
                "buy_sell_ratio": [0.5] * count,  # Unknown

                "symbol": symbol,
                "timeframe": timeframe,
                "count": count,
                "source": "yahoo"
            }

            self.logger.info(f"✅ {count} candles | Price: {data['closes'][-1]:.4f}")

            return data

        except Exception as e:
            self.logger.error(f"❌ Yahoo error: {e}")
            return None

    def _dict_to_list(self, data_dict):
        """
        تحويل dict → list format (للـ backtesting)

        Output: [[ts, o, h, l, c, vol, quote_vol, num_trades,
                   taker_buy_vol, taker_buy_quote_vol], ...]
        """
        if not data_dict:
            return None

        result = []
        count = data_dict.get("count", len(data_dict["timestamps"]))

        for i in range(count):
            candle = [
                data_dict["timestamps"][i],            # 0: timestamp
                data_dict["opens"][i],                  # 1: open
                data_dict["highs"][i],                  # 2: high
                data_dict["lows"][i],                   # 3: low
                data_dict["closes"][i],                 # 4: close
                data_dict["volumes"][i],                # 5: volume
                data_dict["quote_volumes"][i],          # 6: quote volume (USDT)
                data_dict["num_trades"][i],             # 7: number of trades
                data_dict["taker_buy_volumes"][i],      # 8: taker buy volume
                data_dict["taker_buy_quote_volumes"][i] # 9: taker buy quote vol
            ]
            result.append(candle)

        return result

    # ══════════════════════════════════════════════════════════
    #              FUTURES DATA (Crypto Only) - OKX SWAP
    #       Funding Rate, Open Interest, Long/Short Ratio
    # ══════════════════════════════════════════════════════════

    def get_funding_rate(self, symbol=None, limit=100):
        """
        جلب Funding Rate التاريخي من OKX Perpetual Swap

        Returns: [
            {"timestamp": 1234, "funding_rate": 0.0001, "funding_rate_pct": 0.01},
            ...
        ]

        Interpretation (raw numbers only):
            Positive = longs pay shorts
            Negative = shorts pay longs
            High positive (>0.05%) = market over-leveraged long
            High negative (<-0.05%) = market over-leveraged short
        """
        symbol = symbol or Config.DEFAULT_SYMBOL

        if not self._is_crypto(symbol):
            return None

        cache_key = f"funding_{symbol}_{limit}"
        cached = self._get_cache(cache_key, ttl=300)
        if cached:
            return cached

        try:
            inst_id = self._to_okx_swap_inst_id(symbol)
            url = f"{self.okx_base}/api/v5/public/funding-rate-history"
            params = {"instId": inst_id, "limit": min(limit, 100)}

            resp = self.session.get(url, params=params, timeout=10)

            if resp.status_code != 200:
                self.logger.warning(f"⚠️ Funding rate error: {resp.status_code}")
                return None

            payload = resp.json()
            raw = payload.get("data", [])

            result = []
            for item in reversed(raw):  # OKX يرجع الأحدث أولاً - نعكس للترتيب الزمني
                rate = float(item["fundingRate"])
                result.append({
                    "timestamp": int(item["fundingTime"]),
                    "funding_rate": rate,
                    "funding_rate_pct": round(rate * 100, 4),
                })

            if not result:
                return None

            self.logger.info(
                f"✅ Funding Rate: {len(result)} records | "
                f"Latest: {result[-1]['funding_rate_pct']}%"
            )

            self._set_cache(cache_key, result)
            return result

        except Exception as e:
            self.logger.error(f"❌ Funding rate error: {e}")
            return None

    def get_open_interest(self, symbol=None, period="1h", limit=100):
        """
        جلب Open Interest (اللحظي فقط - OKX العامة لا توفر تاريخي بدون اشتراك)

        Returns: {
            "current": {"open_interest": ..., "open_interest_usd": ..., "timestamp": ...},
            "history": [],  # غير متاح من OKX العامة
            "count": 0
        }
        """
        symbol = symbol or Config.DEFAULT_SYMBOL

        if not self._is_crypto(symbol):
            return None

        cache_key = f"oi_{symbol}_{period}_{limit}"
        cached = self._get_cache(cache_key, ttl=300)
        if cached:
            return cached

        try:
            inst_id = self._to_okx_swap_inst_id(symbol)
            url = f"{self.okx_base}/api/v5/public/open-interest"
            resp = self.session.get(
                url, params={"instType": "SWAP", "instId": inst_id}, timeout=10
            )

            current_oi = None
            if resp.status_code == 200:
                payload = resp.json()
                data_list = payload.get("data", [])
                if data_list:
                    item = data_list[0]
                    current_oi = {
                        "open_interest": float(item["oiCcy"]),
                        "open_interest_usd": float(item["oiUsd"]),
                        "timestamp": int(item["ts"]),
                    }

            result = {
                "current": current_oi,
                "history": [],  # OKX العامة لا توفر تاريخي مجاني
                "count": 0,
            }

            if current_oi:
                self.logger.info(
                    f"✅ Open Interest: {current_oi['open_interest']:.2f} "
                    f"(${current_oi['open_interest_usd']:,.0f})"
                )

            self._set_cache(cache_key, result)
            return result

        except Exception as e:
            self.logger.error(f"❌ Open Interest error: {e}")
            return None

    def get_long_short_ratio(self, symbol=None, period="1h", limit=100):
        """
        جلب Long/Short Ratio من OKX (حسابات عامة فقط - OKX لا يوفر
        "top traders" منفصل بواجهته العامة متل Binance)

        Returns: {
            "global_accounts": [{"timestamp", "long_short_ratio"}, ...]
        }

        Raw numbers:
            long_short_ratio > 1.0 = more longs
            long_short_ratio < 1.0 = more shorts
        """
        symbol = symbol or Config.DEFAULT_SYMBOL

        if not self._is_crypto(symbol):
            return None

        cache_key = f"ls_{symbol}_{period}_{limit}"
        cached = self._get_cache(cache_key, ttl=300)
        if cached:
            return cached

        result = {"top_traders_positions": [], "top_traders_accounts": [],
                   "global_accounts": [], "taker_buy_sell": []}

        try:
            base_currency = self._to_okx_inst_id(symbol).split("-")[0]
            okx_period = {"5m": "5m", "15m": "5m", "30m": "5m", "1h": "5m",
                          "4h": "1H", "1d": "1D"}.get(period.lower(), "5m")

            url = f"{self.okx_base}/priapi/v5/rubik/stat/contracts/long-short-account-ratio"
            resp = self.session.get(
                url, params={"ccy": base_currency, "period": okx_period}, timeout=10
            )

            if resp.status_code == 200:
                payload = resp.json()
                raw = payload.get("data", [])
                result["global_accounts"] = [
                    {
                        "timestamp": int(item[0]),
                        "long_short_ratio": round(float(item[1]), 4),
                        # OKX يرجع بس النسبة، نشتق long/short % تقريبياً منها
                        "long_pct": round(float(item[1]) / (float(item[1]) + 1) * 100, 2),
                        "short_pct": round(1 / (float(item[1]) + 1) * 100, 2),
                    }
                    for item in reversed(raw[:limit])
                ]
        except Exception as e:
            self.logger.debug(f"OKX long/short ratio: {e}")

        if result.get("global_accounts"):
            latest = result["global_accounts"][-1]
            self.logger.info(
                f"✅ L/S Ratio: Long {latest['long_pct']}% | "
                f"Short {latest['short_pct']}% | "
                f"Ratio: {latest['long_short_ratio']}"
            )

        self._set_cache(cache_key, result)
        return result

    # ══════════════════════════════════════════════════════════
    #                    ORDER BOOK (OKX)
    # ══════════════════════════════════════════════════════════

    def get_order_book(self, symbol=None, depth=20):
        """
        جلب Order Book من OKX (أكبر أوامر البيع والشراء)

        Returns: {
            "bids": [{"price": 70000, "quantity": 5.5}, ...],
            "asks": [{"price": 70100, "quantity": 3.2}, ...],
            "bid_total_qty": 150.5,
            "ask_total_qty": 120.3,
            "bid_ask_ratio": 1.25,
            "spread": 100,
            "spread_pct": 0.14,
            "biggest_bid": {"price": 69500, "quantity": 25.0},
            "biggest_ask": {"price": 71000, "quantity": 18.0}
        }
        """
        symbol = symbol or Config.DEFAULT_SYMBOL

        if not self._is_crypto(symbol):
            return None

        cache_key = f"ob_{symbol}_{depth}"
        cached = self._get_cache(cache_key, ttl=30)  # 30 sec cache
        if cached:
            return cached

        try:
            inst_id = self._to_okx_inst_id(symbol)
            url = f"{self.okx_base}/api/v5/market/books"

            resp = self.session.get(
                url,
                params={"instId": inst_id, "sz": depth},
                timeout=10
            )

            if resp.status_code != 200:
                return None

            payload = resp.json()
            data_list = payload.get("data", [])
            if not data_list:
                return None

            raw = data_list[0]

            # OKX format: [price, qty, deprecated, num_orders]
            bids = [
                {"price": float(b[0]), "quantity": float(b[1])}
                for b in raw.get("bids", [])
            ]

            asks = [
                {"price": float(a[0]), "quantity": float(a[1])}
                for a in raw.get("asks", [])
            ]

            # Calculate raw metrics
            bid_total = sum(b["quantity"] for b in bids)
            ask_total = sum(a["quantity"] for a in asks)

            biggest_bid = max(bids, key=lambda x: x["quantity"]) if bids else None
            biggest_ask = max(asks, key=lambda x: x["quantity"]) if asks else None

            best_bid = bids[0]["price"] if bids else 0
            best_ask = asks[0]["price"] if asks else 0
            spread = best_ask - best_bid
            spread_pct = (spread / best_bid * 100) if best_bid > 0 else 0

            result = {
                "bids": bids,
                "asks": asks,
                "bid_total_qty": round(bid_total, 4),
                "ask_total_qty": round(ask_total, 4),
                "bid_ask_ratio": round(bid_total / ask_total, 4) if ask_total > 0 else 0,
                "spread": round(spread, 2),
                "spread_pct": round(spread_pct, 4),
                "best_bid": best_bid,
                "best_ask": best_ask,
                "biggest_bid": biggest_bid,
                "biggest_ask": biggest_ask,
                "depth": depth
            }

            self.logger.info(
                f"✅ Order Book: Bid/Ask Ratio: {result['bid_ask_ratio']} | "
                f"Spread: {result['spread_pct']:.3f}%"
            )

            self._set_cache(cache_key, result)
            return result

        except Exception as e:
            self.logger.error(f"❌ Order book error: {e}")
            return None

    # ══════════════════════════════════════════════════════════
    #              MARKET SNAPSHOT (Everything Combined)
    # ══════════════════════════════════════════════════════════

    def get_market_snapshot(self, symbol=None, timeframe=None):
        """
        جلب كل البيانات المتاحة بـ call واحد
        يرجّع snapshot كامل للسوق (أرقام خام فقط)

        Returns: {
            "price_data": {current OHLCV of last few candles},
            "funding": {funding rate data},
            "open_interest": {OI data},
            "long_short": {L/S ratio data},
            "order_book": {order book data},
            "summary": {quick numbers for prompt}
        }
        """
        symbol = symbol or Config.DEFAULT_SYMBOL
        timeframe = timeframe or Config.DEFAULT_TIMEFRAME

        self.logger.info(f"📸 Getting market snapshot for {symbol}...")

        snapshot = {
            "symbol": symbol,
            "timeframe": timeframe,
            "timestamp": int(time.time() * 1000),
        }

        # ─── 1. Latest Price Data ───
        ohlcv = self.get_ohlcv(symbol, timeframe, 10, output_format="dict")
        if ohlcv:
            snapshot["price_data"] = {
                "current_price": ohlcv["closes"][-1],
                "last_5_closes": ohlcv["closes"][-5:],
                "last_5_volumes": ohlcv["volumes"][-5:],
                "last_5_buy_ratio": ohlcv["buy_sell_ratio"][-5:],
                "last_5_num_trades": ohlcv["num_trades"][-5:],
            }

        # ─── 2. Funding Rate (crypto only) ───
        if self._is_crypto(symbol):
            funding = self.get_funding_rate(symbol, limit=10)
            if funding:
                snapshot["funding"] = {
                    "current_rate_pct": funding[-1]["funding_rate_pct"],
                    "last_3_rates": [f["funding_rate_pct"] for f in funding[-3:]],
                    "avg_rate_pct": round(
                        sum(f["funding_rate_pct"] for f in funding) / len(funding), 4
                    )
                }

            # ─── 3. Open Interest ───
            oi = self.get_open_interest(symbol, timeframe, limit=10)
            if oi and oi.get("current"):
                snapshot["open_interest"] = {
                    "current": oi["current"]["open_interest"],
                    "current_usd": oi["current"].get("open_interest_usd"),
                }
                if oi.get("history") and len(oi["history"]) >= 2:
                    latest_oi = oi["history"][-1]["open_interest"]
                    prev_oi = oi["history"][-2]["open_interest"]
                    change = ((latest_oi - prev_oi) / prev_oi * 100) if prev_oi > 0 else 0
                    snapshot["open_interest"]["change_pct"] = round(change, 2)
                    snapshot["open_interest"]["last_5"] = [
                        h["open_interest"] for h in oi["history"][-5:]
                    ]

            # ─── 4. Long/Short Ratio ───
            ls = self.get_long_short_ratio(symbol, timeframe, limit=5)
            if ls:
                if ls.get("top_traders_positions"):
                    latest = ls["top_traders_positions"][-1]
                    snapshot["long_short"] = {
                        "top_traders_long_pct": latest["long_pct"],
                        "top_traders_short_pct": latest["short_pct"],
                        "top_traders_ratio": latest["long_short_ratio"],
                    }

                if ls.get("global_accounts"):
                    latest_g = ls["global_accounts"][-1]
                    snapshot.setdefault("long_short", {})
                    snapshot["long_short"]["global_long_pct"] = latest_g["long_pct"]
                    snapshot["long_short"]["global_short_pct"] = latest_g["short_pct"]
                    snapshot["long_short"]["global_ratio"] = latest_g["long_short_ratio"]

                if ls.get("taker_buy_sell"):
                    latest_t = ls["taker_buy_sell"][-1]
                    snapshot.setdefault("long_short", {})
                    snapshot["long_short"]["taker_buy_sell_ratio"] = latest_t["buy_sell_ratio"]

            # ─── 5. Order Book ───
            ob = self.get_order_book(symbol, depth=20)
            if ob:
                snapshot["order_book"] = {
                    "bid_ask_ratio": ob["bid_ask_ratio"],
                    "spread_pct": ob["spread_pct"],
                    "biggest_bid_price": ob["biggest_bid"]["price"] if ob["biggest_bid"] else None,
                    "biggest_bid_qty": ob["biggest_bid"]["quantity"] if ob["biggest_bid"] else None,
                    "biggest_ask_price": ob["biggest_ask"]["price"] if ob["biggest_ask"] else None,
                    "biggest_ask_qty": ob["biggest_ask"]["quantity"] if ob["biggest_ask"] else None,
                }

        self.logger.info(f"✅ Market snapshot ready: {list(snapshot.keys())}")

        return snapshot

    # ══════════════════════════════════════════════════════════
    #              MULTI-TIMEFRAME
    # ══════════════════════════════════════════════════════════

    def get_multi_timeframe(self, symbol=None, timeframe=None):
        """
        جلب 3 فريمات (entry, context, macro) + market snapshot
        """
        symbol = symbol or Config.DEFAULT_SYMBOL
        timeframe = timeframe or Config.DEFAULT_TIMEFRAME

        tf_list = Config.TF_CONTEXT_MAP.get(
            timeframe.lower(), [timeframe, "4h", "1d"]
        )
        labels = ["entry", "context", "macro"]
        counts = [
            Config.TF_CANDLES.get("entry", 500),
            Config.TF_CANDLES.get("context", 300),
            Config.TF_CANDLES.get("macro", 200)
        ]

        self.logger.info(f"📊 Multi-TF fetch: {tf_list}")

        result = {}

        for i, tf in enumerate(tf_list):
            self.logger.info(f"📊 Fetching {symbol} {tf} ({counts[i]} candles)...")

            data = self.get_ohlcv(symbol, tf, counts[i], output_format="dict")

            if data:
                result[labels[i]] = data

            time.sleep(0.2)

        # ─── Add Market Snapshot ───
        if self._is_crypto(symbol):
            try:
                snapshot = self.get_market_snapshot(symbol, timeframe)
                if snapshot:
                    result["market_snapshot"] = snapshot
            except Exception as e:
                self.logger.warning(f"⚠️ Market snapshot failed: {e}")

        if "entry" in result:
            self.logger.info(
                f"✅ MTF ready: {list(result.keys())} "
                f"({', '.join(tf_list)})"
            )
            return result
        else:
            self.logger.error("❌ Failed to fetch entry timeframe")
            return None

    # ══════════════════════════════════════════════════════════
    #                    UTILITIES
    # ══════════════════════════════════════════════════════════

    def get_ticker(self, symbol=None):
        """السعر الحالي"""
        data = self.get_ohlcv(symbol, "1m", 1, output_format="dict")
        if data and data.get("closes"):
            return {"last": data["closes"][-1]}
        return None

    def clear_cache(self):
        """مسح الـ cache"""
        self._cache.clear()
        self.logger.info("🗑️ Cache cleared")

    def cache_stats(self):
        """إحصائيات الـ cache"""
        return {
            "entries": len(self._cache),
            "keys": list(self._cache.keys())[:10]
        }