import sys, json
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import classify_sweep_or_run, detect_mss
from ict_sessions import compute_overnight_range, classify_session

brain = BrainCore()
trades = json.load(open("human_trades/all_human_trades_with_outcomes.json"))
trade = [t for t in trades if t["id"] == 7][0]
symbol = trade["symbol"]
end_ts = trade["publish_ts"]

h15_data = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", end_ts, limit=200)

# النطاق الليلي
overnight = compute_overnight_range(h15_data, end_ts)
print("Overnight range:", overnight)

print()
print("وقت النشر (NY):", classify_session(end_ts))

# فحص: هل صار سحب سيولة حقيقي (GENUINE_REVERSAL_SWEEP) لأي قاع سوينغ حديث؟
n = len(h15_data["closes"])
lows = h15_data["lows"]
highs = h15_data["highs"]
swing_window = 2
swing_lows_idx = [i for i in range(swing_window, n - swing_window)
                   if lows[i] == min(lows[i - swing_window:i + swing_window + 1])]
print()
print("آخر 5 قيعان سوينغ حقيقية على 15m:")
for sidx in swing_lows_idx[-5:]:
    level = lows[sidx]
    res = classify_sweep_or_run(h15_data, level, level_is_high=False, check_from_idx=sidx + 1)
    print(f"  swing_low={level:.1f} @ idx_from_end={sidx-n}  ->  {res}")
