import sys, json
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import detect_mss, classify_sweep_or_run, compute_displacement, compute_mechanical_bias_anchor

brain = BrainCore()
trades = json.load(open("human_trades/all_human_trades_with_outcomes.json"))
trade = [t for t in trades if t["id"] == 7][0]
symbol = trade["symbol"]
end_ts = trade["publish_ts"]

# فحص فريم Daily مباشرة (رياضي بحت، بلا AI) عند نفس لحظة النشر
daily_data = brain.data_manager.fetch_ohlcv_up_to(symbol, "1d", end_ts, limit=90)
print("=== آخر 10 شموع يومية قبل النشر (رياضياً بحت) ===")
n = len(daily_data["closes"])
for i in range(max(0, n-10), n):
    print(f"  idx_from_end={i-n:3d}  O={daily_data['opens'][i]:.1f} H={daily_data['highs'][i]:.1f} "
          f"L={daily_data['lows'][i]:.1f} C={daily_data['closes'][i]:.1f}")

print()
print("=== مرساة الانحياز الميكانيكية (Daily) ===")
anchor = compute_mechanical_bias_anchor(daily_data)
print(json.dumps(anchor, indent=2, ensure_ascii=False))

print()
print("=== آخر الكسور الهيكلية (Daily) ===")
mss = detect_mss(daily_data)
for b in mss["breaks_found"][-6:]:
    print(f"  {b['direction']} broke {b['broken_level']} @ break_idx={b['break_candle_index_from_end']}  "
          f"displacement={b['displacement_confirmed']}  prior_sweep={b['prior_sweep']}")

# فحص فريم 15m أيضاً
h15_data = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", end_ts, limit=200)
print()
print("=== آخر 15 شمعة 15m قبل النشر ===")
n15 = len(h15_data["closes"])
for i in range(max(0, n15-15), n15):
    print(f"  idx_from_end={i-n15:3d}  O={h15_data['opens'][i]:.1f} H={h15_data['highs'][i]:.1f} "
          f"L={h15_data['lows'][i]:.1f} C={h15_data['closes'][i]:.1f}")
