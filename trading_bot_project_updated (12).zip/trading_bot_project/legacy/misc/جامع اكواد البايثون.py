import os
from pathlib import Path
from datetime import datetime

def collect_python_files():
    """جمع كل ملفات .py من فولدر ووضعها في ملف txt واحد"""
    
    # اختر الفولدر - يمكنك تغيير المسار
    folder_path = input("📂 أدخل مسار الفولدر (أو اضغط Enter للفولدر الحالي): ").strip()
    
    if not folder_path:
        folder_path = "."  # الفولدر الحالي
    
    # التحقق من وجود الفولدر
    if not os.path.exists(folder_path):
        print("❌ الفولدر غير موجود!")
        return
    
    # البحث عن كل ملفات .py
    py_files = list(Path(folder_path).glob("**/*.py"))  # يشمل الفولدرات الفرعية
    
    if not py_files:
        print("❌ لا يوجد ملفات .py في هذا الفولدر!")
        return
    
    print(f"\n✅ تم العثور على {len(py_files)} ملف Python")
    
    # اسم ملف الخرج
    output_file = f"all_codes_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    
    # جمع الأكواد
    with open(output_file, "w", encoding="utf-8") as out:
        
        out.write("=" * 60 + "\n")
        out.write("📦 جميع أكواد Python المجمعة\n")
        out.write(f"📅 التاريخ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        out.write(f"📁 عدد الملفات: {len(py_files)}\n")
        out.write("=" * 60 + "\n\n")
        
        for i, py_file in enumerate(py_files, 1):
            file_name = py_file.name
            relative_path = py_file.relative_to(folder_path)
            
            print(f"   📄 [{i}/{len(py_files)}] {file_name}")
            
            # كتابة رأس لكل ملف
            out.write("\n" + "═" * 60 + "\n")
            out.write(f"📄 ملف رقم: {i}\n")
            out.write(f"📝 اسم الملف: {file_name}\n")
            out.write(f"📍 المسار: {relative_path}\n")
            out.write("═" * 60 + "\n\n")
            
            # قراءة محتوى الملف
            try:
                with open(py_file, "r", encoding="utf-8") as f:
                    content = f.read()
                out.write(content)
            except Exception as e:
                out.write(f"⚠️ خطأ في قراءة الملف: {e}\n")
            
            out.write("\n\n")
        
        # نهاية الملف
        out.write("=" * 60 + "\n")
        out.write("✅ انتهى التجميع\n")
        out.write("=" * 60 + "\n")
    
    print(f"\n🎉 تم بنجاح! الملف: {output_file}")
    print(f"📊 تم جمع {len(py_files)} ملف")
    
    # فتح الملف تلقائياً (اختياري)
    open_file = input("\n🔓 هل تريد فتح الملف؟ (y/n): ").strip().lower()
    if open_file == "y":
        os.startfile(output_file) if os.name == 'nt' else os.system(f"open '{output_file}'")


if __name__ == "__main__":
    print("\n" + "🐍" * 20)
    print("   جامع أكواد Python   ")
    print("🐍" * 20 + "\n")
    
    collect_python_files()
    
    input("\n⏎ اضغط Enter للخروج...")
