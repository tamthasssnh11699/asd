#!/usr/bin/env python3
"""
مَسْرِد - دمج جميع ملفات المشروع في ملف نصي واحد منظم
Project Merger - Combines all project files into one organized text file
"""

import os
import sys
from pathlib import Path
from datetime import datetime

# ===============================
# الإعدادات - Settings
# ===============================

# المجلد الرئيسي للمشروع (غيّر المسار حسب مشروعك)
PROJECT_ROOT = Path(r".")

# المجلدات التي يتم تجاهلها (بما فيها محتوياتها)
IGNORE_DIRS = {
    '.git', '__pycache__', '.pytest_cache', 
    'node_modules', 'build', 'dist', 'target',
    '.venv', 'venv', 'env', '.env',
    '.next', '.output', '.turbo', '.cache',
    '.ruff_cache', '.mypy_cache', '.arena',
    'coverage', '.tox', '.nox', '.parcel-cache',
    '.idea', '.vscode'
}

# الملفات التي يتم تجاهلها تماماً
IGNORE_FILES = {
    '.DS_Store', 'Thumbs.db'
}

# امتدادات الملفات المراد تضمينها
TARGET_EXTENSIONS = {'.py', '.md', '.json', '.txt'}

# ===============================
# الكود الأساسي - Core Code
# ===============================

def should_ignore(path: Path) -> bool:
    """فحص إذا كان المسار يجب تجاهله"""
    name = path.name
    
    # تجاهل المجلدات
    if path.is_dir() and name in IGNORE_DIRS:
        return True
    
    # تجاهل الملفات
    if path.is_file() and name in IGNORE_FILES:
        return True
    
    return False

def get_file_category(ext: str) -> str:
    """تصنيف الملفات حسب النوع"""
    categories = {
        'python': ['.py'],
        'documentation': ['.md', '.txt', '.rst'],
        'config': ['.json', '.yaml', '.yml', '.toml', '.ini', '.cfg', '.conf'],
        'web': ['.html', '.css', '.scss', '.sass', '.less'],
        'javascript': ['.js', '.jsx', '.ts', '.tsx', '.vue', '.svelte'],
        'database': ['.sql'],
        'shell': ['.sh', '.bash', '.zsh', '.fish'],
        'docker': ['Dockerfile', '.dockerfile', '.dockerignore'],
        'git': ['.gitignore', '.gitattributes'],
        'other': []
    }
    
    for category, extensions in categories.items():
        if ext in extensions or ext.lower() in extensions:
            return category
    
    return 'other'

def read_file_safe(filepath: Path, max_size_mb: int = 50) -> str | None:
    """قراءة الملف مع معالجة الأخطاء"""
    try:
        size_mb = filepath.stat().st_size / (1024 * 1024)
        if size_mb > max_size_mb:
            return f"[ملف كبير جداً: {size_mb:.1f} MB - تم التخطي]\n\n"
        
        # محاولة القراءة كـ UTF-8
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            # تحقق إذا الملف فيه محتوى
            if not content.strip():
                return "[(ملف فارغ)]\n\n"
            return content
            
    except UnicodeDecodeError:
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                if not content.strip():
                    return "[(ملف فارغ أو ثنائي)]\n\n"
                return f"[تحذير: الملف فيه أحرف مشفرة - تم عرض ما يمكن قرائته]\n{content}"
        except Exception:
            return "[(ملف ثنائي - لا يمكن عرضه ك نص)]\n\n"
    except PermissionError:
        return "[(لا يوجد صلاحية لقراءة الملف)]\n\n"
    except Exception as e:
        return f"[خطأ في القراءة: {str(e)}]\n\n"

def generate_output_filename() -> str:
    """إنشاء اسم ملف الإخراج"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    project_name = PROJECT_ROOT.name or "project"
    return f"{project_name}_merged_{timestamp}.txt"

def scan_project():
    """فحص المشروع وجمع الملفات"""
    files_info = []
    skipped_files = []  # للتتبع
    
    for filepath in PROJECT_ROOT.rglob('*'):
        if filepath.is_dir():
            # تجاهل المجلدات المخفية والمجلدات في القائمة
            if filepath.name.startswith('.') or filepath.name in IGNORE_DIRS:
                continue
            continue
        
        if filepath.is_file():
            # تجاهل الملفات المحجوبة
            if filepath.name in IGNORE_FILES:
                skipped_files.append((filepath, "في قائمة التجاهل"))
                continue
            
            ext = filepath.suffix.lower()
            
            # ✅ تضمين فقط إذا الامتداد مطلوب
            if ext in TARGET_EXTENSIONS:
                rel_path = filepath.relative_to(PROJECT_ROOT)
                category = get_file_category(ext)
                files_info.append({
                    'path': filepath,
                    'relative_path': rel_path,
                    'category': category,
                    'extension': ext
                })
            else:
                skipped_files.append((filepath, f"امتداد غير مطلوب: {ext}"))
    
    # عرض الملفات اللي تم تخطيها (للمساعدة في Debug)
    if skipped_files:
        print(f"\n⚠️  تم تخطي {len(skipped_files)} ملف:")
        for f, reason in skipped_files[:10]:  # عرض أول 10
            print(f"   - {f.name} → {reason}")
        if len(skipped_files) > 10:
            print(f"   ... و {len(skipped_files) - 10} ملفات أخرى")
    
    return files_info

def format_file_content(file_info: dict, content: str, file_number: int) -> str:
    """تنسيق محتوى الملف الواحد"""
    rel_path = str(file_info['relative_path'])
    category = file_info['category']
    
    separator = "=" * 80
    header = f"{separator}\n"
    header += f"📄 الملف رقم: {file_number}\n"
    header += f"📁 المسار: {rel_path}\n"
    header += f"📂 الفئة: {category}\n"
    header += f"{separator}\n"
    
    return f"{header}{content}\n\n"

def generate_output(files_info: list, output_filename: str) -> str:
    """إنشاء الملف النصي النهائي"""
    # تقسيم الملفات حسب الفئة
    categorized = {}
    for f in files_info:
        cat = f['category']
        if cat not in categorized:
            categorized[cat] = []
        categorized[cat].append(f)
    
    # إنشاء المحتوى
    output = []
    
    # العنوان الرئيسي
    title = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                         مَسْرِد المشروع الموحّد                                  ║
║                         Project Consolidated File                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    output.append(title)
    output.append(f"📅 تاريخ التصدير: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    output.append(f"📂 المجلد الرئيسي: {PROJECT_ROOT.absolute()}")
    output.append(f"📊 إجمالي الملفات: {len(files_info)}")
    output.append(f"📁 عدد الفئات: {len(categorized)}")
    output.append("")
    
    # جدول الفئات
    output.append("=" * 80)
    output.append("📋 ملخص الملفات حسب الفئة:")
    output.append("=" * 80)
    for cat, files in sorted(categorized.items()):
        output.append(f"  • {cat.upper()}: {len(files)} ملفات")
    output.append("")
    
    # قائمة كاملة بالملفات
    output.append("=" * 80)
    output.append("📜 قائمة جميع الملفات:")
    output.append("=" * 80)
    for i, f in enumerate(files_info, 1):
        output.append(f"  {i:3}. {f['relative_path']}")
    output.append("")
    
    # محتوى الملفات
    output.append("\n")
    output.append("█" * 80)
    output.append("█                    محتوى الملفات - Files Content                       █")
    output.append("█" * 80)
    output.append("\n")
    
    file_number = 0
    for category in sorted(categorized.keys()):
        output.append(f"\n{'─' * 80}\n")
        output.append(f"📂═══ {category.upper()} ═══\n")
        output.append(f"{'─' * 80}\n")
        
        for f in sorted(categorized[category], key=lambda x: str(x['relative_path'])):
            file_number += 1
            content = read_file_safe(f['path'])
            if content:
                output.append(format_file_content(f, content, file_number))
    
    return '\n'.join(output)

def main():
    """الدالة الرئيسية"""
    print("=" * 60)
    print("🔍 جاري فحص المشروع...")
    print("=" * 60)
    
    if not PROJECT_ROOT.exists():
        print(f"❌ خطأ: المجلد '{PROJECT_ROOT}' غير موجود!")
        sys.exit(1)
    
    #_scan المشروع
    files_info = scan_project()
    
    if not files_info:
        print("⚠️  لم يتم العثور على ملفات!")
        sys.exit(0)
    
    # عرض الفئات
    categorized = {}
    for f in files_info:
        cat = f['category']
        if cat not in categorized:
            categorized[cat] = []
        categorized[cat].append(f)
    
    print(f"\n📂 الملفات حسب الفئة:")
    for cat, files in sorted(categorized.items()):
        print(f"   • {cat.upper()}: {len(files)} ملفات")
    
    print(f"\n✅ سيتم تضمين: {len(files_info)} ملف")
    
    output_filename = generate_output_filename()
    print(f"\n📝 جاري إنشاء الملف: {output_filename}")
    
    content = generate_output(files_info, output_filename)
    
    with open(output_filename, 'w', encoding='utf-8') as f:
        f.write(content)
    
    file_size = Path(output_filename).stat().st_size / 1024  # KB
    
    print(f"\n{'=' * 60}")
    print(f"✅ تم بنجاح!")
    print(f"   📄 الملف: {output_filename}")
    print(f"   📊 الحجم: {file_size:.1f} KB")
    print(f"   📁 الملفات المدمجة: {len(files_info)}")
    print(f"{'=' * 60}")

if __name__ == "__main__":
    main()