# 📦 `legacy/` — كود مؤرشف (لم يُحذف، فقط أُبعد عن المسار الحي)

كل ملف هون **تحقّقنا فعلياً** (بفحص AST كامل لكل الـimports، بما فيها
المتأخرة جوّا الدوال) أنه **غير مستورد من أي نقطة دخول حقيقية**
(`nemotron_backtest_driver.py` أو `main.py`). لا حذف نهائي - فقط
تنظيم، لأن بعض هذه الملفات لها قيمة مرجعية تاريخية أو مستقبلية محتملة.

## `desktop_gui/` — واجهات سطح مكتب/شات قديمة
- `kotrader.py` — تطبيق سطح مكتب كامل (Tkinter) لواجهة قديمة اسمها Kotrader.
- `main_gui.py`, `chat_interface.py`, `trading_bot.py` — واجهات بديلة قديمة،
  استُبدلت فعلياً بـ`main.py` الحالي (تعليق داخل `trading_bot.py` نفسه
  يوثّق أنه "كود ميت بالكامل" منذ إعادة هيكلة سابقة).

## `superseded_engines/` — محركات استُبدلت بـ`multi_pass_analysis.py`
`confluence_engine.py`, `pattern_detector.py`, `reasoning_engine.py`,
`knowledge_graph.py`, `ml_engine.py`, `nlp_processor.py`,
`signal_generator.py` — كلها أدوات مبكرة بمشوار المشروع، وظيفتها
(تجميع confluence، كشف أنماط، تحليل تنبؤي...) أصبحت جزءاً من منهجية
Top-Down الأشمل بـ`multi_pass_analysis.py` الحالي.

## `media_analyzers/` — محللات وسائط (placeholder، غير مرتبطة بمنهجية ICT)
`video_analyzer.py`, `vision_analyzer.py`, `youtube_analyzer.py`,
`pdf_reader.py`, `news_analyzer.py` — أدوات أولية (بعضها بلا تنفيذ فعلي،
مجرد استدعاء AI عام) لتحليل فيديو/صورة/يوتيوب/PDF/أخبار، لا علاقة مباشرة
لها بتحليل الشموع بمنهجية ICT/SMC.

## `experimental_tests/` — أدوات باك تيست واختبار تاريخية
سكربتات قائمة بذاتها (تُشغَّل مباشرة، لا تُستورد من مكان آخر):
- `reading_comprehension_test.py` — اختبار "هل البوت يقرأ البيانات صح
  أصلاً؟" (منفصل عن سؤال "هل القرار النهائي صحيح؟").
- `model_comparison_backtest.py` — مقارنة أداء مزوّدي AI مختلفين.
- `known_trades_backtest.py`, `consistency_test.py` — أدوات باك تيست
  مبكرة، استُبدلت بـ`nemotron_backtest_driver.py` الأشمل.
- `run_fake_test.py`, `run_generalization_test.py`, `synth_data.py`,
  `synth_fake_pattern.py` — اختبار "الفهم مقابل الحفظ" ببيانات اصطناعية
  100% (رمز/أسعار وهمية كلياً) للتأكد أن البوت يطبّق القاعدة المنطقية
  لا يحفظ نمط أسعار BTC/ETH فقط. **ملاحظة مهمة**: هذا الاختبار مختلف
  جوهرياً عن الباك تيست الأساسي — الباك تيست الأساسي يستخدم فقط صفقات
  بشرية حقيقية موثقة (ممنوع توليد صفقات رياضياً)، بينما هذا الاختبار
  غرضه مختلف تماماً (فحص التعميم المنطقي ببيانات وهمية معلنة كذلك،
  لا انتحال صفة صفقة حقيقية).
- `test_api.py` — فحص اتصال API بسيط.
- `generalization_test_results/` — نتائج JSON من اختبارات الفهم مقابل
  الحفظ (منقولة من مجلد `tests_generalization/` المكرر سابقاً).

## `old_test_results/` — ملفات نتائج/بيانات مؤقتة قديمة
`fake_pattern_result.json`, `generalization_result.json`,
`memory_snapshot_old.json` (كانت بمجلد اسمه `config/` بشكل مربك تماماً
— لا علاقة له بـ`config.py` الفعلي)، و`backtest_setups.json` (من `data/`،
غير مستخدم من أي كود حي).

## `misc/` — ملفات متفرقة
- `README_old_multiAI_version.md` — توثيق قديم جداً (يذكر Gemini/Groq/
  SambaNova كموديلات أساسية، قبل الانتقال الكامل لـNemotron 3 Ultra
  عبر OpenRouter).
- `PROJECT_SUMMARY.md` — ملخص مشروع من جلسات أقدم (استُبدل فعلياً
  بـ`nemotron_training_logs/ARCHIVE_MASTER_SUMMARY_2026-07-06.md`).
- `nik_2022_mentorship.txt` — نسخة مختلفة (md5 مختلف) عن الملف المطابق
  بـ`ict_source_material/` — احُتفظ بها احتياطاً لعدم التأكد من الفرق.
- `merge_project_files (2).py`, `جامع اكواد البايثون.py` — أدوات مساعدة
  متفرقة (تجميع ملفات كود لغرض إداري)، غير مرتبطة بمنطق التحليل.

---

## ⚠️ ملفات حُذفت نهائياً (لا أرشفة) — تكرار حرفي 100% مؤكد بـ md5sum
- `docs/trading_knowledge.txt` (نسخة **قديمة** من `data/trading_knowledge.txt`
  الفعلي — خطر حقيقي لو انفتحت بالغلط بدل الملف الصحيح).
- `docs/.env.example.txt`, `docs/.env.txt`, `docs/gitignore.txt`,
  `docs/requirements.txt` — نسخ حرفية من ملفات الجذر الفعلية.
- `docs/ICT_BOOKS_EXTRACTION_SUMMARY.md` وملفات `gatietrades_*.txt`
  و`ict_material_reference.txt` — مطابقة حرفياً (md5 متطابق) لنسخة
  `ict_source_material/` المحتفَظ بها كمرجع وحيد.
- كل ملفات `tests_generalization/*.py` — مطابقة حرفياً (md5 متطابق)
  لنسخة `legacy/experimental_tests/` المحتفَظ بها.

## تحقق السلامة بعد كل هذا التنظيم
تم التحقق (فعلياً، لا افتراضاً) عبر:
1. فحص AST كامل لكل استيراد (بما فيه المتأخر جوّا الدوال) من نقطتي
   الدخول الحقيقيتين (`nemotron_backtest_driver.py`, `main.py`).
2. استيراد فعلي حي لكل الوحدات الـ18 الأساسية — نجح بلا أي خطأ.
3. تشغيل فعلي لـ`MultiPassAnalysis` و`lesson_learning` بعد التنظيم —
   كل الدوال والقدرات (بما فيها الدروس المحفوظة من جلسات سابقة) سليمة
   تماماً كما كانت قبل التنظيم.
