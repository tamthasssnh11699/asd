# -*- coding: utf-8 -*-
import logging
import json
from ai_client import AIClient


class SignalGenerator:
    def __init__(self):
        self.logger = logging.getLogger("SignalGenerator")
        self.ai = AIClient()

    def generate(self, technical, patterns=None,
                 news=None, memory_context=None):

        prompt = f"""بناءً على التحليلات التالية، أعطني توصية تداول:

التحليل الفني:
{json.dumps(technical, ensure_ascii=False, default=str)[:3000]}

الأنماط:
{json.dumps(patterns, ensure_ascii=False, default=str)[:1000] if patterns else 'لا يوجد'}

سياق الذاكرة:
{memory_context or 'لا يوجد سياق سابق'}

أعطني JSON بالشكل:
{{
  "signal":"BUY/SELL/HOLD",
  "entry": سعر,
  "stop_loss": سعر,
  "take_profit_1": سعر,
  "take_profit_2": سعر,
  "take_profit_3": سعر,
  "confidence": 0-100,
  "risk_reward":"1:X.X",
  "reasoning":"شرح مفصل",
  "risks":["..."],
  "invalidation":"..."
}}"""

        return self.ai.query_json(prompt)