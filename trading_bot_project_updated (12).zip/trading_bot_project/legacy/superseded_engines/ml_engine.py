# -*- coding: utf-8 -*-
"""MLEngine: محرك التعلم الآلي المتقدم - يستخدم AIClient الموحّد (بدون مفاتيح مكشوفة)"""
import logging
from ai_client import AIClient


class MLEngine:
    def __init__(self):
        self.logger = logging.getLogger("MLEngine")
        self.ai = AIClient()
        self.logger.info("MLEngine initialized (via unified AIClient).")

    def predict(self, data):
        prompt = (
            "تنبأ بالسعر، صنف حالة السوق، اكشف الأنماط البصرية، "
            f"واكتشف الحالات الغريبة من البيانات التالية: {data}\n"
            "أجب بصيغة JSON فقط."
        )
        return self.ai.query_json(prompt, max_tokens=1024)