# -*- coding: utf-8 -*-
"""
ReasoningEngine: محرك الاستنتاج الذكي
- استنتاج محلي (forward/backward/abductive/analogical) عبر KnowledgeGraph
- استنتاج بالـ AI (عبر AIClient الموحّد) للحالات المعقّدة
"""
import logging
from ai_client import AIClient


class ReasoningEngine:
    """محرك استنتاج متقدم: forward/backward/abductive/probabilistic/counterfactual"""

    def __init__(self, knowledge_graph=None):
        self.logger = logging.getLogger("ReasoningEngine")
        self.kg = knowledge_graph
        self.ai = AIClient()
        self.logger.info("ReasoningEngine initialized.")

    # ── AI-backed reasoning ──
    def ai_reason(self, concepts):
        prompt = f"حلل واستنتج من المفاهيم التداولية التالية: {concepts}"
        return self.ai.query(prompt, max_tokens=512)

    def ai_backward_reason(self, outcome):
        prompt = f"ما هي الأسباب التي أدت إلى النتيجة التداولية التالية: {outcome}؟"
        return self.ai.query(prompt, max_tokens=512)

    def ai_abductive_reason(self, situation):
        prompt = f"ما هو أفضل تفسير ممكن للوضع التداولي التالي: {situation}؟"
        return self.ai.query(prompt, max_tokens=512)

    def ai_counterfactual(self, scenario):
        prompt = f"ماذا لو حدث السيناريو التداولي التالي: {scenario}؟"
        return self.ai.query(prompt, max_tokens=512)

    def explain(self, signal):
        """شرح قرار التداول بكلمات بسيطة - يستخدم AI لو متاح، وإلا شرح مباشر."""
        try:
            prompt = f"اشرح قرار التداول التالي بكلمات بسيطة ومختصرة: {signal}"
            return self.ai.query(prompt, max_tokens=300)
        except Exception:
            return f"قرار التداول مبني على: {signal}"

    # ── Local graph-based reasoning (يحتاج KnowledgeGraph) ──
    def reason(self, concepts):
        """استنتاج ذكي: تحليل الأسباب، التشابهات، الاستعارات، ربط المفاهيم."""
        if not self.kg:
            return self.ai_reason(concepts)

        results = []
        for c in concepts:
            name = c.get("name", c) if isinstance(c, dict) else c
            related = self.kg.find_related(name)
            causes = self.backward_reason(name)
            analogies = self.analogical_reason(name)
            metaphors = self.semantic_metaphor(name)
            results.append({
                "concept": name,
                "related": related,
                "causes": causes,
                "analogies": analogies,
                "metaphors": metaphors,
            })
        return results

    def analogical_reason(self, concept_name):
        """التفكير بالتشابه: ربط مواقف مشابهة."""
        if not self.kg or self.kg.graph is None:
            return []
        analogies = []
        for node in self.kg.graph.nodes:
            if concept_name != node and concept_name in self.kg.graph.nodes[node].get("شرح", ""):
                analogies.append(node)
        return analogies

    def semantic_metaphor(self, concept_name):
        """فهم الاستعارات والتعبيرات التداولية."""
        if not self.kg or self.kg.graph is None:
            return []
        return [
            node for node in self.kg.graph.nodes
            if "تصحيح مؤقت" in self.kg.graph.nodes[node].get("شرح", "")
        ]

    def backward_reason(self, outcome):
        """backward chaining: من النتيجة يرجع للأسباب."""
        if not self.kg or self.kg.graph is None:
            return self.ai_backward_reason(outcome)
        causes = []
        for node in self.kg.graph.nodes:
            for succ in self.kg.graph.successors(node):
                if succ == outcome:
                    causes.append(node)
        return causes

    def abductive_reason(self, situation):
        """أفضل تفسير ممكن (abductive reasoning)."""
        if not self.kg or self.kg.graph is None:
            return self.ai_abductive_reason(situation)
        return [
            node for node in self.kg.graph.nodes
            if situation in self.kg.graph.nodes[node].get("شرح", "")
        ]

    def probabilistic_reason(self, concept_name):
        """reasoning with probabilities."""
        if self.kg and self.kg.graph is not None and concept_name in self.kg.graph:
            confidence = self.kg.graph.nodes[concept_name].get("ثقة", 0.5)
            return {"concept": concept_name, "probability": confidence}
        return {"concept": concept_name, "probability": 0.0}

    def counterfactual(self, scenario):
        """ماذا لو (counterfactual thinking)."""
        if not self.kg or self.kg.graph is None:
            return [self.ai_counterfactual(scenario)]
        return [
            f"لو استخدمنا {node} بدل {scenario}"
            for node in self.kg.graph.nodes
            if scenario in self.kg.graph.nodes[node].get("شرح", "")
        ]