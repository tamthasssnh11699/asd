# -*- coding: utf-8 -*-
import logging
from ai_client import AIClient


class ChatInterface:
    def __init__(self):
        self.logger = logging.getLogger("ChatInterface")
        self.ai = AIClient()
        self.history = []

    def chat(self, user_message):
        self.history.append({"role": "user", "content": user_message})

        # إرسال آخر 10 رسائل كسياق
        context = "\n".join(
            f"{'المستخدم' if m['role']=='user' else 'البوت'}: {m['content']}"
            for m in self.history[-10:]
        )
        prompt = f"""المحادثة:\n{context}\n\nأجب كبوت تداول ذكي ومفيد."""
        reply = self.ai.query(prompt)

        self.history.append({"role": "assistant", "content": reply})
        return reply