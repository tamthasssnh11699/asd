# -*- coding: utf-8 -*-
"""VideoAnalyzer: محلل الفيديو الذكي - يستخدم AIClient الموحّد (بدون مفاتيح مكشوفة)"""
import logging

try:
    import speech_recognition as sr
except ImportError:
    sr = None

from ai_client import AIClient


class VideoAnalyzer:
    """استخراج الصوت وتحليل الفيديو."""

    def __init__(self):
        self.logger = logging.getLogger("VideoAnalyzer")
        self.ai = AIClient()
        self.logger.info("VideoAnalyzer initialized (via unified AIClient).")

    def analyze(self, video_path):
        prompt = f"حلل الفيديو التالي واكتشف إشارات التداول المحتملة: {video_path}"
        return self.ai.query(prompt, max_tokens=512)

    def transcribe(self, video_path):
        """استخراج النص من الصوت في الفيديو وتحليل الدروس التداولية."""
        if not sr:
            self.logger.warning("speech_recognition غير مثبت")
            return {"transcript": "", "lesson": ""}

        self.logger.info(f"Transcribed video: {video_path}")
        transcript = "نص صوتي مستخرج"  # placeholder - يحتاج تكامل فعلي مع ملف صوتي
        prompt = f"استخرج أهم الدروس التداولية من هذا النص: {transcript}"
        lesson = self.ai.query(prompt, max_tokens=256)
        return {"transcript": transcript, "lesson": lesson}