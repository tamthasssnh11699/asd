# -*- coding: utf-8 -*-
"""
consistency_test - أداة قياس استقرار قرار الـ AI الفعلي
════════════════════════════════════════════════════════════════════
يجاوب على السؤال المباشر: "لو حللت نفس الصفقة (نفس البيانات بالضبط)
أكثر من مرة ورا بعض، هل بيعطي نفس الإشارة تقريباً، أو نتائج عشوائية
متضاربة؟"

هذا مختلف عن signal_schema.py (يلي يحل عدم استقرار *شكل* الإخراج) -
هذه الأداة تقيس استقرار *محتوى* القرار نفسه (BUY/SELL/HOLD، ومدى
الثقة)، وهو سؤال لا يمكن الإجابة عليه إلا بالتجربة الفعلية المتكررة.

طبيعة النماذج اللغوية: حتى مع temperature منخفض (0.2 بإعداداتنا)،
يوجد قدر من العشوائية الطبيعية. السؤال المهم عملياً ليس "هل النتيجة
متطابقة حرفياً؟" (لن تكون أبداً) بل "هل الإشارة (BUY/SELL/HOLD) ثابتة،
وهل الثقة تتذبذب بحدود معقولة (±10-15%) أو بشكل فوضوي (مرة 30% ومرة
85%)؟" الأول يدل على تحليل مستقر ومبني على منطق ثابت. الثاني يدل على
عشوائية حقيقية يجب معالجتها (تقليل temperature أكثر، أو عدم الوثوق
بنتيجة تحليل واحد لوحدها).
"""
import logging
import time
import statistics
from collections import Counter


class ConsistencyTester:

    def __init__(self, brain_core):
        self.brain = brain_core
        self.logger = logging.getLogger("ConsistencyTester")

    def run(self, symbol=None, timeframe=None, custom_data=None, runs=5, delay_seconds=20):
        """
        يشغّل نفس التحليل (نفس البيانات بالضبط) عدة مرات متتالية،
        ويحلل مدى استقرار signal/confidence بين المحاولات.

        Args:
            custom_data: لو محدد، يُستخدم نفس الـ dict بكل مرة (بيانات
                         ثابتة 100% - أفضل طريقة لعزل عشوائية النموذج
                         عن عشوائية تغيّر السوق الحقيقي بين الطلبات)
            runs: عدد مرات التكرار (5 افتراضياً - أكثر = دقة أعلى لكن
                  تكلفة/وقت أكبر)

        Returns:
            dict: تقرير كامل عن الاستقرار (signals, confidences,
                  stability_verdict, recommendation)
        """
        if not custom_data:
            self.logger.warning(
                "⚠️ بدون custom_data ثابتة، أي تغيّر بالنتيجة قد يعود "
                "لتغيّر السوق الفعلي بين الطلبات وليس لعشوائية النموذج. "
                "يُفضّل تمرير custom_data من full_analysis سابق."
            )

        signals = []
        confidences = []
        narratives = []
        archetypes = []
        entries = []

        for i in range(runs):
            self.logger.info(f"🔄 Consistency test run {i+1}/{runs}...")
            # نستخدم use_cache=False ضمنياً عبر تعطيل الكاش المشترك
            # مؤقتاً حتى لا نحصل على نفس الرد المخزّن حرفياً في كل مرة
            self.brain.ai.clear_cache()

            if i > 0 and delay_seconds > 0:
                # تأخير بين المحاولات لتجنب Rate Limit على الحصة
                # المجانية (خصوصاً مع تحليل ثقيل يستهلك 150K+ توكن/طلب)
                self.logger.info(f"⏳ انتظار {delay_seconds}s لتجنب Rate Limit...")
                time.sleep(delay_seconds)

            result = self.brain.full_analysis(
                symbol=symbol, timeframe=timeframe, custom_data=custom_data
            )

            ai = result.get("ai_analysis", {})
            if not isinstance(ai, dict) or "error" in ai:
                self.logger.warning(f"⚠️ Run {i+1} failed: {ai}")
                continue

            signals.append(ai.get("signal", "UNKNOWN"))
            conf = ai.get("confidence")
            if isinstance(conf, (int, float)):
                confidences.append(conf)
            narratives.append(ai.get("narrative", ""))
            archetypes.append(ai.get("archetype", ""))
            entries.append(ai.get("entry"))

        return self._analyze_stability(signals, confidences, narratives, archetypes)

    def _analyze_stability(self, signals, confidences, narratives, archetypes):
        if not signals:
            return {"verdict": "NO_VALID_RUNS", "issues": ["كل المحاولات فشلت"]}

        signal_counts = Counter(signals)
        most_common_signal, most_common_count = signal_counts.most_common(1)[0]
        signal_agreement_pct = round(most_common_count / len(signals) * 100, 1)

        confidence_stats = {}
        if confidences:
            confidence_stats = {
                "mean": round(statistics.mean(confidences), 1),
                "stdev": round(statistics.stdev(confidences), 1) if len(confidences) > 1 else 0,
                "min": min(confidences),
                "max": max(confidences),
                "range": max(confidences) - min(confidences),
            }

        # معايير الحكم على الاستقرار
        issues = []
        if signal_agreement_pct < 100:
            issues.append(
                f"⚠️ الإشارة (BUY/SELL/HOLD) لم تكن ثابتة! "
                f"توزيع: {dict(signal_counts)} - هذا يعني عدم استقرار حقيقي "
                f"بالقرار، وليس فقط بالشكل."
            )

        if confidence_stats and confidence_stats["range"] > 20:
            issues.append(
                f"⚠️ تذبذب كبير بالثقة: من {confidence_stats['min']}% إلى "
                f"{confidence_stats['max']}% (مدى {confidence_stats['range']} نقطة). "
                f"هذا يشير لعشوائية أعلى من المتوقع - فكّر بتخفيض TEMPERATURE "
                f"بملف .env أو عدم الاعتماد على تحليل واحد بمفرده للقرارات المهمة."
            )
        elif confidence_stats and confidence_stats["range"] > 10:
            issues.append(
                f"ℹ️ تذبذب معتدل بالثقة (مدى {confidence_stats['range']} نقطة) - "
                f"طبيعي لنموذج لغوي، لكن راقبه إذا تكرر بمدى أوسع."
            )

        if signal_agreement_pct == 100 and (not confidence_stats or confidence_stats["range"] <= 10):
            verdict = "STABLE"
        elif signal_agreement_pct >= 80:
            verdict = "MOSTLY_STABLE"
        else:
            verdict = "UNSTABLE"

        return {
            "verdict": verdict,
            "total_runs": len(signals),
            "signal_distribution": dict(signal_counts),
            "signal_agreement_pct": signal_agreement_pct,
            "confidence_stats": confidence_stats,
            "unique_archetypes": list(set(a for a in archetypes if a)),
            "issues": issues,
            "recommendation": self._get_recommendation(verdict, issues),
        }

    def _get_recommendation(self, verdict, issues):
        if verdict == "STABLE":
            return "✅ النتائج مستقرة - القرار يمكن الوثوق به من ناحية الاستقرار."
        elif verdict == "MOSTLY_STABLE":
            return (
                "⚠️ استقرار جزئي - القرار الغالب موثوق نسبياً، لكن يُفضّل "
                "تشغيل تحليل إضافي عند الشك قبل اتخاذ قرار فعلي."
            )
        else:
            return (
                "❌ عدم استقرار حقيقي - لا تثق بنتيجة تحليل واحد لهذا الإعداد. "
                "الأسباب المحتملة: (1) البيانات نفسها غامضة فعلاً وعلى الحد "
                "الفاصل بين احتمالين، (2) TEMPERATURE مرتفع جداً بملف .env، "
                "(3) الدستور يحتوي تعليمات متضاربة بهذا السيناريو تحديداً. "
                "راجع الـ narratives المختلفة لفهم أين اختلف التفكير."
            )