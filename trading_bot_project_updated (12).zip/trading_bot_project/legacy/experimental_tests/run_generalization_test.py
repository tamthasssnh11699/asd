# -*- coding: utf-8 -*-
"""
اختبار التعميم الفعلي: هل البوت "يفهم" نمط ICT أو "يحفظ" أرقام BTC/ETH؟
════════════════════════════════════════════════════════════════════
نعطي البوت بيانات اصطناعية بالكامل (رمز SYNTH/USDT، أسعار غريبة ~33-48،
لم يرها بأي بيانات حقيقية سابقة)، لكن مبنية رياضياً لتحقيق شروط نمط ICT
كلاسيكي معروف (Judas Swing / Turtle Soup - سحب سيولة ثم اندفاع انعكاسي).

إذا البوت "فهم القاعدة" (سحب سيولة + اندفاع = احتمال انعكاس، بغض النظر
عن الأرقام المحددة)، يجب أن يتعرف على البنية المنطقية. إذا "حفظ" فقط
نطاقات أسعار BTC/ETH المألوفة، يجب أن يفشل أو يرتبك مع أرقام غريبة كلياً.
"""
import sys, json, time
sys.path.insert(0, '.')
sys.path.insert(0, 'tests_generalization')
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(message)s')

from synth_data import generate_bullish_reversal_setup
from brain_core import BrainCore
from reading_comprehension_test import ReadingComprehensionTest

data, ground_truth = generate_bullish_reversal_setup()

print("=== البيانات الاصطناعية المُولّدة ===")
print(f"رمز وهمي: {data['symbol']} | عدد الشموع: {data['count']} | نطاق السعر: {min(data['lows']):.2f}-{max(data['highs']):.2f}")
print()
print("=== النمط المُصمَّم عمداً (Ground Truth - لن يُعطى للـAI إطلاقاً) ===")
print(json.dumps(ground_truth, indent=2, ensure_ascii=False))

brain = BrainCore()
rc = ReadingComprehensionTest(brain)

print("\n" + "="*70)
print("تشغيل ReadingComprehensionTest على بيانات اصطناعية 100%")
print("="*70)
t0 = time.time()
result = rc.run(data["symbol"], data["timeframe"], data)
elapsed = time.time() - t0
print(f"الوقت: {round(elapsed,1)}s")

with open("tests_generalization/generalization_result.json", "w", encoding="utf-8") as f:
    json.dump({"ground_truth": ground_truth, "result": result}, f, indent=2, ensure_ascii=False, default=str)

if "error" in result:
    print("خطأ:", result["error"])
else:
    print("\n=== bot_response (ماذا رأى البوت في بيانات غريبة عليه كلياً) ===")
    print(json.dumps(result["bot_response"], indent=2, ensure_ascii=False))
    print("\n=== المقارنة الرياضية ===")
    print(json.dumps(result["comparison"], indent=2, ensure_ascii=False))

print("\n=== DONE ===")