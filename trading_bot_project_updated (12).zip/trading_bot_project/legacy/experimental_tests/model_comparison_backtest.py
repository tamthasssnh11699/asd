# -*- coding: utf-8 -*-
"""
ModelComparisonBacktest - مقارنة موضوعية حقيقية بين كل النماذج المتاحة
════════════════════════════════════════════════════════════════════
يجاوب على السؤال: "مين أقرب للصح فعلياً وبدون هلوسة، بمقارنة موحّدة
على نفس الصفقات التاريخية الحقيقية؟"

الفرق الجوهري عن الاختبار السابق (كان فيه عيب منهجي):
  الاختبار السابق استخدم سيناريو مُصطنع "سهل" (اتجاه صاعد واضح بلا
  غموض) فنجحت فيه كل النماذج بسهولة - هذا لا يميز فعلياً بين نموذج
  "يفهم" ونموذج "يقلّد نمط النص". هذا الملف يصحح ذلك عبر:

  1. استخدام نفس البيانات التاريخية الحقيقية الموضوعية (من
     known_setups_finder.py، بعد إصلاح lookahead bias) - ليست بيانات
     مُصطنعة، بل شموع BTC حقيقية بنتيجة فعلية معروفة سلفاً
  2. استخدام نفس الـ prompt بالضبط (BrainCore._build_prompt - نفس
     الدستور الكامل 617K حرف، نفس المؤشرات الفنية المحسوبة) لكل نموذج
     - مقارنة عادلة 100%، لا فروقات ناتجة عن اختلاف الصياغة
  3. فحص صريح للهلوسة (audit_signal_prices) على رد كل نموذج - هل
     الأسعار المذكورة موجودة فعلاً بمدى البيانات المُرسلة؟
  4. تسجيل زمن الاستجابة (السرعة) لكل نموذج كمعيار عملي إضافي
  5. مقارنة القرار النهائي (BUY/SELL/HOLD) بالنتيجة الفعلية الموثقة
     رياضياً (bias_match / signal_match)

⚠️ صدق منهجي: عينة صغيرة (بضع صفقات) لا تثبت تفوقاً إحصائياً قاطعاً -
هذا اختبار استكشافي جاد يعطي مؤشرات حقيقية، وليس دراسة أكاديمية كاملة.
للحصول على ثقة إحصائية عالية، يلزم تكرار الاختبار على عشرات/مئات
الصفقات عبر backtest_engine.py الرسمي.
"""
import logging
import time

from ai_client import AIClient
from authenticity_engine import AuthenticityEngine
from verification_layer import VerificationLayer


class ModelComparisonBacktest:

    def __init__(self, brain_core, setups_finder):
        self.brain = brain_core
        self.finder = setups_finder
        self.ai = AIClient()
        self.ae = AuthenticityEngine()
        self.verifier = VerificationLayer()
        self.logger = logging.getLogger("ModelComparisonBacktest")

    def run(self, setups, providers_to_test, delay_between=5):
        """
        يشغّل كل مزود محدد على كل صفقة، باستخدام نفس الـ prompt بالضبط
        (نفس الدستور + نفس المؤشرات)، ويقارن النتائج بشكل موضوعي.

        Args:
            setups: قائمة صفقات من KnownSetupsFinder.find_setups_multi_timeframe()
            providers_to_test: قائمة أسماء مزودين معرّفين بـ AIClient
                (مثال: ["gemini", "groq", "siliconflow"])
                ⚠️ ملاحظة: Mistral أُزيل نهائياً من المشروع (بطيء جداً
                عملياً رغم دقته العالية) - لا يُستخدم بعد الآن حتى لو
                ذُكر بنتائج سابقة كانت جزءاً من الاختبار قبل استبعاده.
            delay_between: تأخير بالثواني بين كل نداء (لتجنب rate limits)

        Returns:
            dict: تقرير كامل لكل مزود عبر كل الصفقات + ملخص نهائي مرتب
        """
        all_results = {p: [] for p in providers_to_test}

        for setup_idx, setup in enumerate(setups):
            self.logger.info(
                f"📊 صفقة {setup_idx+1}/{len(setups)}: {setup['symbol']} "
                f"{setup['signal_date_readable']} (فعلياً: {setup['direction']})"
            )

            # نجلب البيانات مرة واحدة فقط - نفس البيانات بالضبط لكل مزود
            historical_data = self.finder._fetch_historical_up_to(
                setup["symbol"], setup["timeframe"], setup["signal_timestamp"]
            )
            if not historical_data:
                self.logger.warning(f"⚠️ فشل جلب بيانات الصفقة {setup_idx+1} - تخطي")
                continue

            # نبني الـ prompt مرة واحدة فقط (نفس الدستور + نفس المؤشرات
            # لكل مزود - هذا ما يضمن عدالة المقارنة)
            mtf_data = {"entry": historical_data}
            mtf_indicators = {}
            try:
                ind = self.brain.ta.compute_all(historical_data)
                if ind:
                    mtf_indicators["entry"] = ind
            except Exception as e:
                self.logger.warning(f"⚠️ فشل حساب المؤشرات: {e}")
                continue

            if "entry" not in mtf_indicators:
                self.logger.warning("⚠️ بيانات غير كافية لحساب المؤشرات - تخطي")
                continue

            knowledge, k_tokens = self.brain._load_knowledge()
            learned = self.brain._build_learned_context()
            performance = self.brain._build_performance_context()

            prompt = self.brain._build_prompt(
                setup["symbol"], setup["timeframe"],
                mtf_data, mtf_indicators, knowledge, learned, performance,
                market_snapshot=None, authenticity_report=None,
            )

            expected_bias = "BULLISH" if setup["direction"] == "BULLISH" else "BEARISH"
            expected_signal = "BUY" if setup["direction"] == "BULLISH" else "SELL"

            for provider_name in providers_to_test:
                if provider_name not in self.ai.providers:
                    continue

                self.logger.info(f"  🔄 اختبار {provider_name}...")
                start = time.time()

                try:
                    saved_order = self.ai.provider_order
                    self.ai.provider_order = [provider_name]
                    raw_result = self.ai.query_json(prompt, use_cache=False)
                    self.ai.provider_order = saved_order
                    elapsed = time.time() - start
                except Exception as e:
                    self.logger.warning(f"  ❌ {provider_name} فشل: {e}")
                    all_results[provider_name].append({
                        "setup_index": setup_idx,
                        "signal_date": setup["signal_date_readable"],
                        "error": str(e),
                    })
                    time.sleep(delay_between)
                    continue

                if not isinstance(raw_result, dict) or "error" in raw_result:
                    all_results[provider_name].append({
                        "setup_index": setup_idx,
                        "signal_date": setup["signal_date_readable"],
                        "error": raw_result.get("error", "invalid response") if isinstance(raw_result, dict) else "non-dict response",
                        "elapsed_seconds": round(elapsed, 1),
                    })
                    time.sleep(delay_between)
                    continue

                # ═══ فحص الهلوسة الصريح (audit) ═══
                price_audit = self.ae.audit_signal_prices(raw_result, historical_data)

                # ═══ فحص التحقق الشامل (verification score) ═══
                verification = self.verifier.verify(raw_result, mtf_data)

                bot_bias = raw_result.get("bias", "UNKNOWN")
                bot_signal = raw_result.get("signal", "UNKNOWN")
                bot_confidence = raw_result.get("confidence", 0)

                all_results[provider_name].append({
                    "setup_index": setup_idx,
                    "signal_date": setup["signal_date_readable"],
                    "expected_bias": expected_bias,
                    "expected_signal": expected_signal,
                    "actual_move_pct": setup["actual_move_pct"],
                    "bot_bias": bot_bias,
                    "bot_signal": bot_signal,
                    "bot_confidence": bot_confidence,
                    "bias_match": bot_bias == expected_bias,
                    "signal_match": bot_signal == expected_signal,
                    "hallucination_free": price_audit.get("valid", True),
                    "hallucination_issues": price_audit.get("issues", []),
                    "verification_score": verification.get("score_pct"),
                    "elapsed_seconds": round(elapsed, 1),
                    "narrative_snippet": str(raw_result.get("narrative", ""))[:150],
                })

                time.sleep(delay_between)

        return self._build_summary(all_results)

    def _build_summary(self, all_results):
        """يبني ملخصاً نهائياً مرتباً حسب الدقة + السرعة + الخلو من الهلوسة"""
        summary = {}

        for provider_name, results in all_results.items():
            valid_results = [r for r in results if "error" not in r]
            total = len(results)
            valid = len(valid_results)

            if valid == 0:
                summary[provider_name] = {
                    "total_tested": total,
                    "valid_responses": 0,
                    "verdict": "FAILED_ALL",
                }
                continue

            signal_matches = sum(1 for r in valid_results if r["signal_match"])
            bias_matches = sum(1 for r in valid_results if r["bias_match"])
            hallucination_free_count = sum(1 for r in valid_results if r["hallucination_free"])
            avg_confidence = sum(r["bot_confidence"] for r in valid_results if isinstance(r["bot_confidence"], (int, float))) / valid
            avg_verification = sum(r["verification_score"] for r in valid_results if isinstance(r.get("verification_score"), (int, float))) / valid if valid else 0
            avg_speed = sum(r["elapsed_seconds"] for r in valid_results) / valid

            summary[provider_name] = {
                "total_tested": total,
                "valid_responses": valid,
                "signal_match_pct": round(signal_matches / valid * 100, 1),
                "bias_match_pct": round(bias_matches / valid * 100, 1),
                "hallucination_free_pct": round(hallucination_free_count / valid * 100, 1),
                "avg_confidence": round(avg_confidence, 1),
                "avg_verification_score": round(avg_verification, 1),
                "avg_speed_seconds": round(avg_speed, 1),
                "details": results,
            }

        # ترتيب نهائي: أولوية لعدم الهلوسة، ثم دقة الإشارة، ثم السرعة
        ranked = sorted(
            [(k, v) for k, v in summary.items() if v.get("valid_responses", 0) > 0],
            key=lambda x: (
                x[1]["hallucination_free_pct"],
                x[1]["signal_match_pct"],
                x[1]["avg_verification_score"],
                -x[1]["avg_speed_seconds"],
            ),
            reverse=True,
        )

        return {
            "per_provider": summary,
            "ranking": [name for name, _ in ranked],
        }