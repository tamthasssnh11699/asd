# -*- coding: utf-8 -*-
"""
ReadingComprehensionTest - اختبار "هل البوت أساساً بيقرأ البيانات صح؟"
════════════════════════════════════════════════════════════════════
طلب المستخدم المباشر: "بيهمني اكتر شي انو يكون عم يحلل صح اصلا - عم
يقرا البيانات صح - عم يعرف مصطلحات التداول... يكون عارف يقراهن وعارف
يستخرجهن من البيانات من الاساس. بعدين ماتبقى امورو سهله."

لماذا هذا الملف موجود ومختلف عن الباك تيست العادي:
  كل أدوات الباك تيست السابقة (known_setups_finder, model_comparison,
  multi_pass) تفحص "هل القرار النهائي BUY/SELL صحيح؟" - هذا سؤال
  مهم لكنه ليس السؤال الأهم. لو البوت أخطأ بقراءة أساسية (ظن قمة
  مزيفة قمة حقيقية، فوّت BOS واضحاً، خلط بين Order Block صاعد وهابط)
  لكنه صادف القرار النهائي الصحيح بالصدفة (تحيز اتجاه عام مثلاً)،
  هذا "نجاح" مضلل - يخفي فهماً مكسوراً بالأساس.

  هذا الملف يفحص طبقة أعمق وأسبق: **هل يستطيع البوت استخراج الحقائق
  الهيكلية الأساسية بنفسه من أرقام OHLC الخام**، بمعزل تام عن أي
  قرار تداولي نهائي:
    1. أين القمم المتأرجحة (swing highs) الحقيقية؟ وأين القيعان؟
    2. أي مستوى تعرّض لكسر سيولة (Liquidity Sweep) حقيقي (انعكس)
       مقابل كسر كاذب/استمراري (Run) لم ينعكس؟
    3. أين آخر BOS (Break of Structure) حقيقي، وما اتجاهه، وهل
       صمد أو فشل؟
    4. ما اتجاه الهيكل العام (HH/HL صاعد أم LH/LL هابط أم عشوائي)؟

  كل واحدة من هذه الحقائق **قابلة للتحقق رياضياً 100%** عبر أدوات
  موجودة أصلاً بالمشروع (AuthenticityEngine, TechnicalAnalyzer) -
  هذا الملف يقارن ادعاء البوت اللغوي بهذه الحسابات المستقلة، ويعطي
  نسبة "دقة قراءة أساسية" منفصلة تماماً عن نسبة "دقة القرار النهائي".
"""
import logging
import numpy as np

from signal_schema import normalize_signal_dict

logger = logging.getLogger("ReadingComprehensionTest")


def get_reading_schema():
    """Schema صارم يفرض على النموذج استخراج حقائق أساسية فقط - لا قرار تداولي إطلاقاً"""
    return {
        "type": "OBJECT",
        "properties": {
            "swing_highs_identified": {
                "type": "ARRAY",
                "description": "كل القمم المتأرجحة الواضحة التي تراها بالبيانات (index من النهاية، سالب، والسعر)",
                "items": {
                    "type": "OBJECT",
                    "properties": {
                        "index_from_end": {"type": "INTEGER"},
                        "price": {"type": "NUMBER"},
                    },
                    "required": ["index_from_end", "price"],
                },
            },
            "swing_lows_identified": {
                "type": "ARRAY",
                "description": "كل القيعان المتأرجحة الواضحة",
                "items": {
                    "type": "OBJECT",
                    "properties": {
                        "index_from_end": {"type": "INTEGER"},
                        "price": {"type": "NUMBER"},
                    },
                    "required": ["index_from_end", "price"],
                },
            },
            "market_structure": {
                "type": "STRING",
                "enum": ["HH_HL_BULLISH", "LH_LL_BEARISH", "RANGING_UNCLEAR"],
                "description": "الهيكل العام: قمم/قيعان أعلى (صاعد)، أو أقل (هابط)، أو عشوائي",
            },
            "most_recent_bos": {
                "type": "OBJECT",
                "properties": {
                    "found": {"type": "BOOLEAN"},
                    "direction": {"type": "STRING", "enum": ["UP", "DOWN", "NONE"]},
                    "broken_level_price": {"type": "NUMBER"},
                    "breaking_candle_index_from_end": {"type": "INTEGER"},
                    "did_it_hold": {
                        "type": "STRING",
                        "enum": ["HELD_GENUINE", "FAILED_RETRACED", "TOO_RECENT_TO_TELL"],
                    },
                },
                "required": ["found", "direction"],
            },
            "most_recent_liquidity_sweep": {
                "type": "OBJECT",
                "description": "آخر مرة انكسر فيها مستوى قمة/قاع سابق بفتيل ثم السعر تصرف بشكل معيّن",
                "properties": {
                    "found": {"type": "BOOLEAN"},
                    "swept_level_price": {"type": "NUMBER"},
                    "sweep_candle_index_from_end": {"type": "INTEGER"},
                    "classification": {
                        "type": "STRING",
                        "enum": [
                            "GENUINE_REVERSAL_SWEEP",
                            "FAKE_CONTINUATION_RUN",
                            "NO_CLEAR_SWEEP",
                        ],
                        "description": (
                            "GENUINE_REVERSAL_SWEEP: انعكس فعلياً بعد الكسر (فخ حقيقي). "
                            "FAKE_CONTINUATION_RUN: استمر بنفس الاتجاه (كسر سيولة عادي مو فخ). "
                            "NO_CLEAR_SWEEP: لا يوجد كسر واضح."
                        ),
                    },
                },
                "required": ["found"],
            },
            "last_candle_report": {
                "type": "OBJECT",
                "description": "انسخ بالضبط قيم آخر شمعة - فحص دقة قراءة أساسي بلا تفسير",
                "properties": {
                    "open": {"type": "NUMBER"}, "high": {"type": "NUMBER"},
                    "low": {"type": "NUMBER"}, "close": {"type": "NUMBER"},
                    "color": {"type": "STRING", "enum": ["BULLISH", "BEARISH"]},
                },
                "required": ["open", "high", "low", "close", "color"],
            },
        },
        "required": [
            "swing_highs_identified", "swing_lows_identified", "market_structure",
            "most_recent_bos", "most_recent_liquidity_sweep", "last_candle_report",
        ],
    }


READING_TEST_PROMPT_INSTRUCTION = """
{ohlc_section}

TASK - THIS IS A PURE DATA-READING TEST, NOT A TRADING DECISION:
Do NOT decide BUY/SELL/HOLD. Do NOT build a narrative or archetype.
Your ONLY job is to extract raw structural facts from the numbers above,
exactly as a trader would identify them on a chart before any analysis:

1. List every clear swing high and swing low you can identify (a swing
   high = a candle whose high is higher than the highs of the candles
   immediately surrounding it; swing low = mirror image). Use the
   candle index counted from the end (-1 = last candle, -2 = second
   to last, etc.) and the exact price.
   ⚠️ IMPORTANT DISTINCTION (a documented real failure showed this):
   a local bump is NOT automatically a *significant* swing. Before
   listing a swing high, check: is there a clearly higher high within
   roughly 10 candles before or after it? If so, that bump is just a
   minor wiggle on the way to/from the real significant swing - do
   NOT report it as a meaningful swing high, only the more prominent
   one nearby matters structurally. Apply the mirror-image check for
   swing lows (a clearly lower low nearby overshadows it). Only list
   swings that are genuinely prominent relative to their neighborhood,
   not every micro zig-zag the price made.

2. State the overall market structure: are swing highs/lows both
   rising (HH/HL = bullish), both falling (LH/LL = bearish), or
   unclear/ranging?

3. Identify the MOST RECENT Break of Structure (BOS) - scan candles
   -1 through -15 for a genuine displacement (large body, big range
   relative to nearby candles) that broke a prior swing high/low.
   State its direction, the exact level it broke, which candle broke
   it, and whether subsequent candles held above/below that level
   (genuine) or retraced back through it (failed).

4. Identify the MOST RECENT liquidity sweep - a candle that wicked
   beyond a prior swing high/low but did NOT sustain beyond it.
   Classify it: did price genuinely reverse after the sweep (a real
   trap - GENUINE_REVERSAL_SWEEP), or did it continue through in the
   same direction as the wick (not really a trap - FAKE_CONTINUATION_RUN)?

5. Report the exact OHLC of the very last candle, digit by digit -
   arithmetic only, no interpretation.

Output ONLY the JSON fields requested. This is purely about accurate
reading of what the numbers show - there is no "trade" to construct here.
"""


class ReadingComprehensionTest:
    """يفحص دقة استخراج الحقائق الهيكلية الأساسية من بيانات OHLC خام"""

    def __init__(self, brain_core):
        self.brain = brain_core
        self.ai = brain_core.ai
        self.ta = brain_core.ta
        self.authenticity = brain_core.authenticity
        self.logger = logging.getLogger("ReadingComprehensionTest")

    # ══════════════════════════════════════════════════════════
    #  الحقيقة الرياضية المستقلة (Ground Truth)
    # ══════════════════════════════════════════════════════════

    def _compute_ground_truth(self, data, swing_window=2, lookback_candles=15, swings_scan_window=60):
        """يحسب كل الحقائق الهيكلية رياضياً بحتاً - بلا أي AI"""
        h = np.array(data["highs"], dtype=float)
        l = np.array(data["lows"], dtype=float)
        c = np.array(data["closes"], dtype=float)
        o = np.array(data["opens"], dtype=float)

        # ── Market structure (نفس TechnicalAnalyzer.market_structure) ──
        structure = self.ta.market_structure(data["highs"], data["lows"])
        if "HH+HL" in structure:
            structure_norm = "HH_HL_BULLISH"
        elif "LH+LL" in structure:
            structure_norm = "LH_LL_BEARISH"
        else:
            structure_norm = "RANGING_UNCLEAR"

        # ── Most recent BOS (نفس AuthenticityEngine.detect_most_recent_bos) ──
        bos = self.authenticity.detect_most_recent_bos(data, lookback_candles=lookback_candles, swing_window=swing_window)

        # ── Last candle ──
        last_candle = {
            "open": round(float(o[-1]), 4), "high": round(float(h[-1]), 4),
            "low": round(float(l[-1]), 4), "close": round(float(c[-1]), 4),
            "color": "BULLISH" if c[-1] > o[-1] else "BEARISH",
        }

        # ⚠️ إصلاح خطأ منهجي حقيقي مُكتشف (يوليو 2026، بمقارنة Gemini
        # مقابل gemma-4-26b-a4b-it): النسخة القديمة كانت تقارن قمم/قيعان
        # البوت فقط مع "آخر 5 قمم/قيعان بالترتيب الزمني الخام" (حتى لو
        # كانت نتوءات محلية صغيرة جداً بلا أهمية استراتيجية). هذا أنتج
        # نتيجة "دقة قمم = 0%" مضلّلة لموديلين (gemma, llama-4-scout)
        # رغم أن القمم التي ذكراها كانت **موجودة فعلياً بالبيانات وبنفس
        # الموقع (index) الصحيح تماماً** - فقط كانت أقدم زمنياً من نافذة
        # "آخر 5" الضيقة، وهذا عيب بمقياس الاختبار نفسه لا بقراءة الموديل.
        #
        # الحل: نستخدم AuthenticityEngine.detect_significant_swings()
        # (نفس الدالة المُستخدمة فعلياً بخط الإنتاج الحي عبر
        # multi_pass_analysis._authenticity_block) كمرجع الحقيقة - تحسب
        # "الأهمية النسبية" (prominence) على كامل نافذة الشموع المعروضة
        # للموديل (لا فقط آخر 5)، وتستبعد آلياً النتوءات المحلية الصغيرة
        # التي تُلغيها قمة/قاع أكبر مجاور. بهذا، أي قمة يذكرها الموديل
        # (حتى لو أقدم زمنياً) تُقاس بمعيار "هل هي مهمة استراتيجياً؟"
        # بدل "هل هي من آخر 5 بالترتيب الزمني؟" - معيار أعدل وأدق.
        sig = self.authenticity.detect_significant_swings(
            data, swing_window=swing_window,
            lookback_candles=swings_scan_window, top_n=10,
        )

        return {
            "swing_highs": sig["significant_highs"],
            "swing_lows": sig["significant_lows"],
            "market_structure": structure_norm,
            "most_recent_bos": bos,
            "last_candle": last_candle,
            "minor_swings_filtered_count": sig.get("minor_swings_filtered_count", 0),
        }


    # ══════════════════════════════════════════════════════════
    #  المقارنة (ادعاء البوت مقابل الحقيقة الرياضية)
    # ══════════════════════════════════════════════════════════

    def _price_tolerance_match(self, claimed_price, actual_prices, tolerance_pct=0.5):
        """هل السعر المُدَّعى قريب (ضمن هامش صغير) من أي سعر بقائمة الحقيقة؟"""
        if not actual_prices:
            return False
        for actual in actual_prices:
            if actual == 0:
                continue
            if abs(claimed_price - actual) / abs(actual) * 100 <= tolerance_pct:
                return True
        return False

    def _unique_match_count(self, bot_items, actual_prices, tolerance_pct=0.5):
        """
        يحسب عدد العناصر الحقيقية الفريدة (لا التكرارات) التي طابقها
        البوت - وليس عدد إدخالات البوت المطابقة. ⚠️ إصلاح خطأ حقيقي
        مُكتشف: لو البوت ذكر إدخالين قريبين من نفس النقطة الحقيقية
        الوحيدة (مثال موثّق: 2878.18 و2886.67 - كلاهما ضمن هامش %0.5
        من نفس القاع الحقيقي)، يُحتسب مرة واحدة فقط، لا مرتين - يمنع
        recall تجاوز 1.0 (وهو مستحيل رياضياً بأي مقياس صحيح).

        خوارزمية مطابقة فريدة بسيطة (Greedy Bipartite Matching): لكل
        نقطة حقيقية غير مُستهلَكة بعد، نتحقق هل يوجد إدخال بوت (غير
        مُستهلَك) ضمن هامش التسامح منها - إن وُجد نستهلك كليهما.
        """
        remaining_actuals = list(actual_prices)
        used_bot_indices = set()
        matched = 0
        for actual in remaining_actuals:
            if actual == 0:
                continue
            for idx, item in enumerate(bot_items):
                if idx in used_bot_indices:
                    continue
                price = item.get("price") if isinstance(item, dict) else None
                if not isinstance(price, (int, float)):
                    continue
                if abs(price - actual) / abs(actual) * 100 <= tolerance_pct:
                    used_bot_indices.add(idx)
                    matched += 1
                    break
        return matched

    def score_response(self, bot_response, ground_truth):
        """
        يقارن رد البوت بالحقيقة الرياضية، ويرجع تقريراً مفصلاً بنقاط
        منفصلة لكل مهارة (لا نتيجة واحدة مجمّعة - حتى نعرف بالضبط
        وين القراءة قوية ووين ضعيفة).
        """
        report = {"checks": [], "score_breakdown": {}}

        # ── 1) دقة قراءة الشمعة الأخيرة (الأهم - فحص حرفي بحت) ──
        bot_last = bot_response.get("last_candle_report", {})
        actual_last = ground_truth["last_candle"]
        candle_match = all(
            isinstance(bot_last.get(k), (int, float)) and
            abs(bot_last.get(k, 0) - actual_last[k]) / max(abs(actual_last[k]), 0.01) * 100 < 0.5
            for k in ("open", "high", "low", "close")
        ) and bot_last.get("color") == actual_last["color"]
        report["score_breakdown"]["last_candle_accuracy"] = candle_match
        report["checks"].append({
            "skill": "قراءة الشمعة الأخيرة (OHLC + اللون)",
            "bot_claimed": bot_last,
            "actual": actual_last,
            "correct": candle_match,
        })

        # ── 2) دقة الهيكل العام (HH/HL أو LH/LL) ──
        structure_match = bot_response.get("market_structure") == ground_truth["market_structure"]
        report["score_breakdown"]["market_structure_accuracy"] = structure_match
        report["checks"].append({
            "skill": "الهيكل العام (صاعد/هابط/عشوائي)",
            "bot_claimed": bot_response.get("market_structure"),
            "actual": ground_truth["market_structure"],
            "correct": structure_match,
        })

        # ── 3) دقة اتجاه آخر BOS ──
        bot_bos = bot_response.get("most_recent_bos", {})
        actual_bos = ground_truth["most_recent_bos"]
        if actual_bos.get("bos_found"):
            bos_direction_match = bot_bos.get("direction") == actual_bos.get("direction")
            bos_level_match = self._price_tolerance_match(
                bot_bos.get("broken_level_price", -999999),
                [actual_bos.get("broken_level")],
                tolerance_pct=1.0,
            ) if bot_bos.get("broken_level_price") is not None else False
        else:
            # لو رياضياً ما في BOS واضح، البوت الصحيح يجب يقول found=False
            bos_direction_match = not bot_bos.get("found", True)
            bos_level_match = None
        report["score_breakdown"]["bos_direction_accuracy"] = bos_direction_match
        report["checks"].append({
            "skill": "اتجاه آخر BOS (كسر هيكل)",
            "bot_claimed": bot_bos,
            "actual": actual_bos,
            "correct": bos_direction_match,
            "level_price_correct": bos_level_match,
        })

        # ── 4) دقة تحديد القمم/القيعان (تقاطع - كم قمة/قاع مذكورة صح) ──
        # ⚠️ إصلاح خطأ حقيقي مُكتشف بالاختبار الفعلي (يوليو 2026): المنطق
        # القديم كان يحسب "كم إدخال من البوت طابق أي عنصر حقيقي" - لو
        # البوت ذكر إدخالين مختلفين قريبين من نفس القاع الحقيقي الوحيد
        # (مثال حقيقي: 2878.18 و2886.67، الفرق بينهما 0.3% فقط ضمن هامش
        # التسامح 0.5%)، كلاهما يُحتسب "مطابقاً" لنفس العنصر الحقيقي -
        # فينتج recall=2.0 (أكبر من 1.0!) وهو مستحيل رياضياً ويكشف خللاً
        # منهجياً بالعدّ. الحل: مطابقة فريدة (كل عنصر حقيقي يُستهلك مرة
        # واحدة كحد أقصى) عبر _unique_match_count() أدناه.
        bot_highs = bot_response.get("swing_highs_identified", [])
        actual_high_prices = [s["price"] for s in ground_truth["swing_highs"]]
        matched_highs = self._unique_match_count(bot_highs, actual_high_prices)
        highs_precision = matched_highs / len(bot_highs) if bot_highs else 0
        highs_recall = matched_highs / len(actual_high_prices) if actual_high_prices else None

        bot_lows = bot_response.get("swing_lows_identified", [])
        actual_low_prices = [s["price"] for s in ground_truth["swing_lows"]]
        matched_lows = self._unique_match_count(bot_lows, actual_low_prices)
        lows_precision = matched_lows / len(bot_lows) if bot_lows else 0
        lows_recall = matched_lows / len(actual_low_prices) if actual_low_prices else None

        report["score_breakdown"]["swing_highs_precision"] = round(highs_precision, 2)
        report["score_breakdown"]["swing_highs_recall"] = round(highs_recall, 2) if highs_recall is not None else None
        report["score_breakdown"]["swing_lows_precision"] = round(lows_precision, 2)
        report["score_breakdown"]["swing_lows_recall"] = round(lows_recall, 2) if lows_recall is not None else None
        report["checks"].append({
            "skill": "تحديد القمم المتأرجحة (Swing Highs)",
            "bot_claimed_count": len(bot_highs),
            "actual_recent_count": len(actual_high_prices),
            "matched": matched_highs,
            "precision": round(highs_precision, 2),
        })
        report["checks"].append({
            "skill": "تحديد القيعان المتأرجحة (Swing Lows)",
            "bot_claimed_count": len(bot_lows),
            "actual_recent_count": len(actual_low_prices),
            "matched": matched_lows,
            "precision": round(lows_precision, 2),
        })

        # ── النتيجة الإجمالية (متوسط بسيط للمهارات الأساسية القابلة للقياس الثنائي) ──
        binary_scores = [
            report["score_breakdown"]["last_candle_accuracy"],
            report["score_breakdown"]["market_structure_accuracy"],
            report["score_breakdown"]["bos_direction_accuracy"],
        ]
        report["overall_binary_accuracy_pct"] = round(
            sum(1 for s in binary_scores if s) / len(binary_scores) * 100, 1
        )

        return report

    # ══════════════════════════════════════════════════════════
    #  تشغيل الاختبار الكامل
    # ══════════════════════════════════════════════════════════

    def run(self, symbol, timeframe, data):
        """
        يشغّل اختبار قراءة واحد على بيانات مُعطاة، ويرجع تقريراً
        كاملاً (رد البوت + الحقيقة الرياضية + المقارنة التفصيلية).
        """
        ground_truth = self._compute_ground_truth(data)

        ind = self.ta.compute_all(data)
        indicators_text = self.ta.compact_summary(ind) if ind else ""
        candles_text = self.brain._format_candles(data, min(60, data.get("count", 60)))

        ohlc_section = f"""
{'='*40}
MARKET: {symbol} ({timeframe}) - RAW DATA READING TEST
{'='*40}
{indicators_text}

Candles (the idx column below IS the index_from_end you must report -
copy it directly, -1=most recent/last candle, no mental conversion needed):
{candles_text}
"""
        prompt = READING_TEST_PROMPT_INSTRUCTION.format(ohlc_section=ohlc_section)

        try:
            bot_response = self.ai.query_json(
                prompt, response_schema=get_reading_schema(), use_cache=False
            )
            bot_response = normalize_signal_dict(bot_response)
        except Exception as e:
            return {"error": str(e), "ground_truth": ground_truth}

        if not isinstance(bot_response, dict) or "error" in bot_response:
            return {"error": bot_response, "ground_truth": ground_truth}

        comparison = self.score_response(bot_response, ground_truth)

        return {
            "symbol": symbol,
            "timeframe": timeframe,
            "bot_response": bot_response,
            "ground_truth": ground_truth,
            "comparison": comparison,
        }