import re

def rewrite_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    # Define the new robust target + state logic block
    new_logic = """
                valid_target = None
                ttype = ""
                
                recent_sweep_found = False
                n_15m = len(closed_15m['closes'])
                
                if bias == "BULLISH":
                    lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    lows = []
                    check_idx = n_15m - 1
                    for s in lows_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
                            if min_before < s['price']: continue
                        lows.append(s)
                    if lows:
                        lows.sort(key=lambda x: current_p - x['price'])
                        valid_target = lows[0]
                        ttype = "قاع سيولة (SSL)"
                        
                    # Check recent sweeps
                    for s in sig.get("all_lows_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                min_recent = min(closed_15m['lows'][check_start : n_15m])
                                if min_recent < s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                                            recent_sweep_found = True
                                            break
                        if recent_sweep_found: break
                else:
                    highs_raw = [s for s in sig.get("all_highs_tiered", []) if s['price'] > current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    highs = []
                    check_idx = n_15m - 1
                    for s in highs_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            max_before = max(closed_15m['highs'][s_idx+1 : check_idx])
                            if max_before > s['price']: continue
                        highs.append(s)
                    if highs:
                        highs.sort(key=lambda x: x['price'] - current_p)
                        valid_target = highs[0]
                        ttype = "قمة سيولة (BSL)"
                        
                    # Check recent sweeps
                    for s in sig.get("all_highs_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                max_recent = max(closed_15m['highs'][check_start : n_15m])
                                if max_recent > s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['highs'][i] > s['price'] and closed_15m['closes'][i] < s['price']:
                                            recent_sweep_found = True
                                            break
                        if recent_sweep_found: break

                # STATE MACHINE DECISION
                # We have 3 states: 
                # 1. Recent sweep happened -> We dive to 5m to find FVG/setup.
                # 2. No recent sweep, but valid target exists -> We wait for target to be hit.
                # 3. No recent sweep, no valid target -> "أراقب" (Watching, nothing to do).
"""
    # Just print the replacement code, I'll manually insert it to avoid regex issues.
    print(new_logic)
