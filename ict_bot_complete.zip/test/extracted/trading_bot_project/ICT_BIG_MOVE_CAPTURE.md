# 🏆 كيف مايكل يلتقط الحركات الكبيرة — بحث عميق

## الاكتشاف الأهم: مايكل يعمل **طبقتين من الصفقات بالتوازي!**

### المصادر:

**ICT Material Reference (Core Content):**
> "Take 50% of position off @ ~20-30 pips for 1% gain (Scalp).
>  **Remaining 1% portion will be held for the daily range.**"

> "Take 70% off when you can and **let the remaining run.**"

> "Higher Time Frame Stops — As price moves higher, bring stop to ~10 pips
>  below the **next fractal low once two near fractals form**"

**2022 Mentorship Notes:**
> "He **pyramids** his position. Ex: buys 3 contracts at initial entry,
>  if another buying opportunity presents itself (in a higher priced FVG)
>  before profit target, **he buys 2 more, then again one more.**"

> "if you see a longer term price swing set up (on the hourly for example)
>  **you should try to hold it out for the move.**"

> "While the market is moving in your favor, **continue to trust that move
>  and hold onto your trade.**"

**ICT Swing Trading Method (Core Content Day 21):**
> "Swing Trading Setup:
>  i. Quarterly Shift in Flows
>  ii. Old Highs & Lows
>  iii. SMT Divergence on Daily
>  iv. Market Structure
>  v. Swing Point Analysis
>  vi. Optimal Trade Entry
>  vii. Swing Projection for Profit Objectives
>  → entry on 5-min chart, **manage on 4-hour and/or 1-hour**"

## النظام الحقيقي لمايكل — **3 طبقات**:

### الطبقة 1: Scalp (70% من المركز)
```
- الدخول: على 5M/1M (FVG/OB بعد sweep+MSS)
- TP1: أقرب سيولة (20-30 pips / low hanging fruit)
- يُغلق 70% عند TP1
- المدة: دقائق إلى ساعات
```

### الطبقة 2: Day Trade (20% من المركز)
```
- نفس الدخول — يبقى مفتوح بعد TP1
- SL ينتقل لـBE
- TP2: الطرف المقابل من الـrange اليومي
- Trailing خلف fractal lows على 15M
- المدة: ساعات
```

### الطبقة 3: Runner / Swing (10% من المركز)
```
- نفس الدخول — يبقى مفتوح بعد TP2
- SL خلف fractal lows على 1H/4H
- TP3: Weekly draw on liquidity / Previous Week H/L
- "Higher Time Frame Stops: bring stop below NEXT fractal low
   once TWO near fractals form"
- المدة: أيام
```

## كيف يعمل الـPyramiding:
```
الدخول الأول: 3 contracts عند FVG
  ↓ السعر يتحرك بالاتجاه
الدخول الثاني: 2 contracts عند FVG جديدة (أعلى)
  ↓ السعر يكمل
الدخول الثالث: 1 contract عند FVG ثالثة (أعلى)
  ↓ 
Total: 6 contracts بمتوسط سعر جيد
```

**المصدر:** "if another buying opportunity presents itself (in a higher priced FVG) before profit target, he buys 2 more"

## كيف نطبق هاد بالبوت — **Dual Position System**:

### الحل العملي:
```python
# بدل صفقة واحدة بـ1% risk:
# نفتح صفقتين بالتوازي من نفس الـsetup:

Position A: "Scalp" (0.7% risk)
  - TP1: أقرب swing (low hanging fruit)
  - عند TP1: يُغلق بالكامل ← ربح مضمون
  - Trailing: لا — fixed target

Position B: "Runner" (0.3% risk)  
  - TP2: HTF Draw on Liquidity (الهدف الذهبي)
  - عند TP1 of Position A: SL ينتقل لـBE
  - Trailing: خلف 1H fractal lows (أبطأ بكثير من 5M!)
  - "bring stop below next fractal low once TWO fractals form"
  - المدة: ممكن أيام
  - هاد اللي بيلتقط الحركات الـ9R و12R و29R!

المجموع: 1% risk (نفس الإدارة المالية)
```

### لماذا هاد أذكى:
```
Position A: 
  - Win rate عالي (~80%)
  - ربح صغير ومضمون
  - يغطي الخسائر

Position B:
  - Win rate أقل (~40%)
  - لكن عندما تربح = ربح ضخم (5-30R!)
  - هاد اللي بيجيب الأرباح الحقيقية
  
مثال: يونيو 11
  Position A: +0.17% (1.72R × 0.7% risk) = ربح صغير مضمون
  Position B: لو التقط 50% من الـ29.79R = +4.47% (14.9R × 0.3% risk)!
  
  بدل +0.35% الحالي → +4.64% !!!
```

## شروط الـRunner (الـPosition B):
```
1. SL يبقى عند BE بعد TP1 لـPosition A
   → "Protective stop at Breakeven after taking profit on first half"

2. Trailing خلف fractal على 1H:
   → "bring stop to ~10 pips below the next fractal low 
      once TWO near fractals form"
   → يعني: ننتظر fractal + تأكيد (شمعتين على يمينه) قبل ما نحرك SL
   → هاد أبطأ بكثير من trailing على 5M!

3. الخروج:
   a. TP2 ضُرب (الذهبي!) → 🏆
   b. Fractal على 1H ينكسر بإغلاق → trailing exit
   c. Daily bias ينقلب → "If your ITH is broken, your idea was wrong"
   d. نهاية الأسبوع → "Keep perspective limited to 5-day time horizon"
```

## الـTrailing الذكي للـRunner — **Fractal-Based**:
```
المصدر: "Higher TF Stops: bring stop below NEXT fractal low 
         once TWO near fractals form"

الخوارزمية:
1. ابحث عن fractal low على 1H (low أدنى من الشمعتين على يمينه ويساره)
2. انتظر حتى يتشكل fractal ثاني (تأكيد)
3. فقط عندها: حرك SL تحت الـfractal الأول
4. كرر مع كل fractal جديد

لماذا هاد يعمل:
- Fractal على 1H = swing مهم (كل 4-8 ساعات)
- ننتظر 2 fractals = تأكيد مزدوج
- هاد أبطأ بـ10x من trailing على 5M
- يعطي الحركة الكبيرة وقت تتطور
```
