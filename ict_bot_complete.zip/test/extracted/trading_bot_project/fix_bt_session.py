import re
with open("algo_master.py", "r") as f:
    content = f.read()

# I see what I did. I changed the lookback in `get_ohlcv` from 1500 to 500 to save time.
# But wait, `start_idx = max(200, n - (days_back*96))`
# If days_back is 30, days_back*96 = 2880.
# If I fetch only 500 candles, n = 500.
# n - 2880 = 500 - 2880 = -2380.
# max(200, -2380) = 200.
# So it starts at index 200 and ends at 500. This is only 300 candles = about 3 days!
# NO WONDER it finds 0 signals! It's only looking at the last 3 days which were probably in the weekend or chop!
# To do a 30-day backtest, we MUST fetch at least 3000 candles!

# Fix the fetch limit:
content = content.replace('full_data = brain.data_manager.get_ohlcv(symbol, "15m", 500 + (days_back*96), output_format="dict")',
                          'full_data = brain.data_manager.get_ohlcv(symbol, "15m", 1500 + (days_back*96), output_format="dict")')

# Change step to 8 to be fast but accurate
content = content.replace('for i in range(start_idx, n, 12):', 'for i in range(start_idx, n, 8):')

with open("algo_master.py", "w") as f:
    f.write(content)
print("تم إصلاح خطأ جلب البيانات.")
