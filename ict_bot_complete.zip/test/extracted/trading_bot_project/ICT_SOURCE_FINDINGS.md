# 🔎 نتائج البحث العميق — ما قاله مايكل فعلاً مقابل ما في الكود

## 1. SWING HIGH/LOW — التعريف الرسمي
**المصدر:** ICT Mentorship Month 1 Notes (SlideShare), 2022 Mentorship Ep5
> "Swing High – Three candle pattern. The up candle."
> "Swing Low – Three candle pattern. The down candle."

**التعريف:** الشمعة الوسطى قمتها أعلى من الشمعة على يسارها ويمينها.
**الكود الحالي:** يستخدم `detect_significant_swings` مع topographic prominence وعتبات ATR. ❌

---

## 2. DISPLACEMENT — التعريف الرسمي
**المصدر:** ictkillzone.com, innercircletrader.net, FibAlgo
> "Body-to-range ratio above ~75% (small wicks)"
> "Candle significantly larger than the 3–5 preceding candles"
> "Institutional Candle — body is at least 60–70% of total range"
> "The displacement candle must be noticeably larger than 3–5 candles. Range should be at minimum 2x average recent candle, often 3–5x."

**أهم نقطة:** مايكل يقول displacement يجب أن يترك FVG خلفه. بلا FVG = ليس displacement حقيقي.
> "Without displacement, there is no valid FVG entry"
> "A candle that is similar in size to its neighbours moved price, but it did not displace it"

**الكود الحالي:** 1.5 ATR + 65% body ratio. لا يشترط FVG. لا يقارن بالشموع المحيطة. ❌

---

## 3. FVG — التعريف الرسمي
**المصدر:** innercircletrader.net, 2022 Mentorship Notes Ep2
> "Bullish FVG: low(candle3) > high(candle1)"
> "Bearish FVG: high(candle3) < low(candle1)"
> "CE = 50% midpoint"
> "Not every FVG is tradeable — must be bias-aligned, displacement-confirmed"

**الكود الحالي:** التكوين صحيح ✅. لكن `require_displacement=False` يُستخدم في أغلب الأماكن ❌. لا lifecycle ❌.

---

## 4. ORDER BLOCK — التعريف الرسمي (4 شروط)
**المصدر:** innercircletrader.net "ICT Order Block" guide
> "Four conditions must be true:"
> 1. "The second candle must grab the high/low of the previous candle"
> 2. "The second candle must close beyond the first candle — a clean engulf"
> 3. "An imbalance (FVG) prints on the lower timeframe inside or adjacent to the OB zone"
> 4. "An ICT Market Structure Shift confirms the intent"
> "Without all four, it is just a candle"

**أيضاً:** "The last opposing candle before a strong displacement move"
**أيضاً:** "The FVG is the IMBALANCE between three candles. The order block is the LAST opposing candle before the displacement that produced the FVG."

**الكود الحالي:** يفرض شرطين فقط (touch + engulf). FVG ليست شرطاً. MSS غير مطبقة. ❌

---

## 5. MSS — التعريف الرسمي (الفرق عن BOS)
**المصدر:** backtrex.com, innercircletrader.net
> "MSS mandatorily requires a preceding liquidity sweep"
> "CHoCH is a generic SMC concept. ICT MSS is more demanding: it requires a preceding sweep"
> "MSS without a preceding sweep is not a valid MSS in ICT methodology"
> "The sequence: liquidity sweep → failure to hold → MSS with displacement candle close"
> "BOS = continuation signal. MSS = reversal signal."

**2022 Mentorship Notes Ep3:**
> "These market structure shifts (MSS) are only significant if the price has first traded below sell-side liquidity or above buy-side liquidity."

**الكود الحالي:** `detect_mss` يكتشف كل close-through لكل swing. لا يميز MSS من BOS. لا يشترط sweep سابق. ❌

---

## 6. STOP LOSS — التعريف الرسمي
**المصدر:** 2022 Mentorship Notes
> "You put your stop above candle 1 or candle 2 [of the FVG]"
> "trailing stop losses: set below the previous down-closed candle/bullish order block's low"
> "SL below the OB bottom/FVG bottom that justified the entry"

**innercircletrader.net:**
> "10–20 pips beyond the OB extreme"
> "Beyond the wick of the swept extreme that preceded the MSS"

**الكود الحالي:** يبحث عن مرساة هيكلية عامة — المفهوم صحيح لكن الـswings غلط. ⚠️

---

## 7. TARGETS — التعريف الرسمي
**المصدر:** 2022 Mentorship Notes Ep2
> "We want to use the closest target (low-hanging fruit)"
> "targets below 50% (discount) — old lows, imbalances"
> "partials should also be taken below each low (sell side liquidity)"

**ICT Fibonacci Settings:**
> "-0.27 — short-term internal target"
> "-1.0 — 1x the leg target"
> "-2.0 — full standard deviation expansion"

**الكود الحالي:** يستخدم Fib -0.27 كهدف تنفيذي ✅ (لكن الأولوية يجب أن تكون لأقرب مستوى سيولة حقيقي)

---

## 8. DAILY BIAS — التعريف الرسمي
**المصدر:** 2022 Mentorship Notes Ep2
> "The majority of finding the draw on liquidity will be found in the daily timeframe analysis"
> "Looking for a likely move higher or lower based on the weekly candle — sets initial bias"
> "The market is drawing to 2 things: running to take out highs/lows or running to fill an imbalance"

**الكود الحالي:** Daily HH/HL فقط. Weekly غير مستخدم. Draw on Liquidity غير محسوب. ❌

---

## 9. TRADE MANAGEMENT
**المصدر:** 2022 Mentorship Notes
> "Once it fills an FVG, an ITL is created and should not be taken out"
> "trailing stop losses: set below the previous down-closed candle"
> "He pyramids his position"

**innercircletrader.net "ICT Fibonacci Levels":**
> "Taking partials at -1.0 and trailing the rest toward -2.0"

**الكود الحالي:** TP1 50% + BE + structural trailing — المفهوم قريب ✅. لكن 1.5R→BE غير موثق ❌.

---

## 10. أداة GitHub مفيدة
**`smartmoneyconcepts`** (pip install smartmoneyconcepts):
- `smc.fvg()` — FVG مع MitigatedIndex ✅
- `smc.ob()` — OB مع mitigation وbreaker detection ✅
- `smc.bos_choch()` — BOS/CHoCH detection ✅
- `smc.swing_highs_lows()` — Swing detection ✅
- `smc.liquidity()` — Liquidity pools ✅
- `smc.retracements()` — Premium/Discount/OTE ✅

**يمكن استخدامها كمرجع للمقارنة أو كـvalidation layer.**
