import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_USD = ACCOUNT_BALANCE * 0.01

full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 8000, output_format="dict")
n = len(full_data["closes"])
candidates = []
reported_days = set()

# استخراج الصفقات
for i in range(2000, n, 50): 
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
        daily_bias = anchor.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"): continue

        current_ts = window_data["timestamps"][-1]
        day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
        if day_str in reported_days: continue

        sig = ae.detect_significant_swings(window_data, swing_window=1, lookback_candles=100)
        
        important_levels = [s for s in sig.get("all_lows_tiered", [])] if daily_bias == "BULLISH" else [s for s in sig.get("all_highs_tiered", [])]
        for candidate in important_levels:
            res = classify_sweep_or_run(window_data, candidate["price"], level_is_high=(daily_bias=="BEARISH"), check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                reported_days.add(day_str)
                break
    except Exception: pass

candidates.sort(key=lambda c: c["timestamp"])
if len(candidates) > 15: candidates = candidates[-15:] # أخذ آخر 15 صفقة للمقارنة

# دالة التتبع الهيكلي الذكي (تحاكي عقل مايكل الحقيقي)
def simulate_smart_structure(data, entry, sl, is_short):
    risk = abs(sl - entry)
    if risk == 0: return 0, "ERROR"
    
    current_sl = sl
    in_trade = True
    be_activated = False
    
    # هيكل السوق المحلي للتتبع
    local_highs = []
    local_lows = []
    
    for i in range(5, len(data['closes'])):
        h = data['highs'][i]
        l = data['lows'][i]
        
        # 1. تحديث الـ Break-Even إذا ابتعدنا 1.5R (قاعدة أساسية لحماية رأس المال)
        if is_short and l < (entry - 1.5*risk) and not be_activated:
            current_sl = entry
            be_activated = True
        elif not is_short and h > (entry + 1.5*risk) and not be_activated:
            current_sl = entry
            be_activated = True

        # 2. هل انضرب الستوب الحالي؟
        if is_short and h >= current_sl:
            return (entry - current_sl) / risk, "DYNAMIC_SL_HIT"
        elif not is_short and l <= current_sl:
            return (current_sl - entry) / risk, "DYNAMIC_SL_HIT"
            
        # 3. قراءة الهيكل الحي (Dynamic Structural Trailing)
        # إذا شكل السوق قمة جديدة (للمقصرين) أو قاع جديد (للمشترين) ثم أكمل في اتجاهنا، نحرك الستوب خلفه.
        
        if is_short:
            # اكتشاف Swing High صغير (شمعة أعلى من الشمعة قبلها وبعدها)
            if data['highs'][i-1] > data['highs'][i-2] and data['highs'][i-1] > data['highs'][i]:
                swing_high = data['highs'][i-1]
                # للتأكد من أن هذا السوينغ حقيقي، يجب أن يكسر السعر القاع الذي تلاه
                if l < data['lows'][i-1] and swing_high < current_sl and be_activated:
                    # السعر شكل قمة هابطة جديدة وكسر قاعها! ممتاز، ننقل الستوب فوقها بـ Buffer صغير.
                    current_sl = swing_high + (risk * 0.1) 
        else:
            # اكتشاف Swing Low صغير
            if data['lows'][i-1] < data['lows'][i-2] and data['lows'][i-1] < data['lows'][i]:
                swing_low = data['lows'][i-1]
                if h > data['highs'][i-1] and swing_low > current_sl and be_activated:
                    # قاع صاعد جديد تشكل وتم تأكيده. ننقل الستوب تحته.
                    current_sl = swing_low - (risk * 0.1)

    # إذا انتهت البيانات ولم ينضرب الستوب
    final_price = data['closes'][-1]
    return (entry - final_price)/risk if is_short else (final_price - entry)/risk, "OPEN"

# دالة المحاكاة القديمة (الجامدة بـ TP1 = 3R)
def simulate_dumb_old_way(data, entry, sl, is_short):
    risk = abs(sl - entry)
    if risk == 0: return 0, "ERROR"
    tp_dumb = entry - 3*risk if is_short else entry + 3*risk
    
    for i in range(len(data['closes'])):
        h = data['highs'][i]
        l = data['lows'][i]
        
        if is_short:
            if h >= sl: return -1.0, "SL_HIT_OLD"
            if l <= tp_dumb: return 3.0, "TP_HIT_OLD"
        else:
            if l <= sl: return -1.0, "SL_HIT_OLD"
            if h >= tp_dumb: return 3.0, "TP_HIT_OLD"
            
    return 0, "OPEN_OLD"

print("="*100)
print(f"{'التاريخ':<12} | {'الاتجاه':<8} | {'النظام القديم الغبي (Fixed 3:1)':<30} | {'النظام الهيكلي الذكي (Market Structure)':<30}")
print("="*100)

total_old = 0
total_smart = 0

for cand in candidates:
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    for k in range(0, 4):
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                plan = res.get("chosen_model", {}).get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                
                if entry and sl:
                    is_short = (bias == "BEARISH")
                    # جلب بيانات المستقبل للمحاكاة
                    future_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts + 24*3600*1000, limit=288)
                    
                    # محاكاة القديم
                    rr_old, res_old = simulate_dumb_old_way(future_data, entry, sl, is_short)
                    # محاكاة الذكي
                    rr_smart, res_smart = simulate_smart_structure(future_data, entry, sl, is_short)
                    
                    total_old += rr_old
                    total_smart += rr_smart
                    
                    old_str = f"{rr_old:+.2f}R ({'ستوب❌' if rr_old == -1 else 'تارجت🎯' if rr_old > 0 else 'مفتوحة'})"
                    
                    smart_str = ""
                    if rr_smart == -1: smart_str = f"{rr_smart:+.2f}R (ستوب أصلي❌)"
                    elif rr_smart == 0: smart_str = f"{rr_smart:+.2f}R (تأمين تعادل🛡️)"
                    else: smart_str = f"{rr_smart:+.2f}R (قنص هيكلي متتبع🧠🎯)"
                    
                    print(f"{cand['datetime_utc'][:10]:<12} | {bias:<8} | {old_str:<30} | {smart_str:<30}")
                    break
        except Exception: pass

print("="*100)
print(f"النتيجة الإجمالية (R:R):    | {total_old:+.2f} R                               | {total_smart:+.2f} R")
print(f"الربح بحساب 100$ (1% Risk): | {total_old * RISK_USD:+.2f} $                              | {total_smart * RISK_USD:+.2f} $")
print("="*100)

