# -*- coding: utf-8 -*-
"""
ict_dual_position.py — نظام المركز المزدوج الذكي
═══════════════════════════════════════════════════
المصدر الرئيسي: ICT Core Content:
"Take 70% off when you can and let the remaining run"
"Higher TF Stops: bring stop below next fractal low once TWO fractals form"

الفكرة:
  من نفس الدخول الواحد، نفتح مركزين بعقليتين مختلفتين تماماً:
  
  Position A (الصياد): يصطاد ربح سريع ومضمون
  - يفكر بالدقائق
  - هدفه: أقرب سيولة
  - يخرج بسرعة = win rate عالي
  
  Position B (الراكب): يركب الموجة الكبيرة
  - يفكر بالساعات/الأيام
  - هدفه: Draw on Liquidity البعيد
  - يتحمل الارتدادات = ربح ضخم عندما ينجح
  
  المجموع = نفس الـ1% risk الكلي
"""
import numpy as np
from ict_math_engine import detect_ict_three_candle_swings, _atr


class SmartFractalTracker:
    """
    يتتبع fractals على فريم أعلى بذكاء.
    
    المصدر: "bring stop below next fractal low once TWO fractals form"
    
    مش كل low هو fractal. Fractal = low أدنى من الشمعتين على يمينه ويساره.
    ونحتاج 2 fractals مؤكدين قبل ما نحرك الستوب.
    
    هاد بيعطي الحركة وقت كافي تتطور — مش مثل trailing على كل شمعة.
    """
    
    def __init__(self):
        self.candle_buffer = []  # نجمع شموع ونبني fractals
        self.confirmed_fractals = []  # fractals مؤكدة
        self.pending_fractal = None  # fractal ينتظر التأكيد
    
    def add_candle(self, candle):
        """يضيف شمعة ويحدث الـfractals."""
        self.candle_buffer.append(candle)
        n = len(self.candle_buffer)
        
        # Fractal يحتاج 5 شموع minimum (2 يسار + 1 وسط + 2 يمين)
        if n < 5:
            return
        
        # نفحص الشمعة الوسطى (قبل شمعتين)
        mid = n - 3  # الشمعة اللي عندها شمعتين يمين وشمعتين يسار
        
        # Fractal Low: low أدنى من الأربع شموع حولها
        is_fractal_low = (
            self.candle_buffer[mid]['l'] < self.candle_buffer[mid-1]['l'] and
            self.candle_buffer[mid]['l'] < self.candle_buffer[mid-2]['l'] and
            self.candle_buffer[mid]['l'] < self.candle_buffer[mid+1]['l'] and
            self.candle_buffer[mid]['l'] < self.candle_buffer[mid+2]['l']
        )
        
        # Fractal High: high أعلى من الأربع شموع حولها
        is_fractal_high = (
            self.candle_buffer[mid]['h'] > self.candle_buffer[mid-1]['h'] and
            self.candle_buffer[mid]['h'] > self.candle_buffer[mid-2]['h'] and
            self.candle_buffer[mid]['h'] > self.candle_buffer[mid+1]['h'] and
            self.candle_buffer[mid]['h'] > self.candle_buffer[mid+2]['h']
        )
        
        if is_fractal_low:
            new_fractal = {'type': 'LOW', 'price': self.candle_buffer[mid]['l'], 'index': mid}
            # هل هاد fractal جديد أعلى من السابق؟ (Higher Low = structure سليم)
            if self.confirmed_fractals:
                last = self.confirmed_fractals[-1]
                if last['type'] == 'LOW' and new_fractal['price'] > last['price']:
                    new_fractal['is_hl'] = True  # Higher Low
                else:
                    new_fractal['is_hl'] = False
            self.confirmed_fractals.append(new_fractal)
        
        if is_fractal_high:
            new_fractal = {'type': 'HIGH', 'price': self.candle_buffer[mid]['h'], 'index': mid}
            if self.confirmed_fractals:
                last = self.confirmed_fractals[-1]
                if last['type'] == 'HIGH' and new_fractal['price'] < last['price']:
                    new_fractal['is_lh'] = True  # Lower High
                else:
                    new_fractal['is_lh'] = False
            self.confirmed_fractals.append(new_fractal)
    
    def get_trail_level(self, is_long, buffer=0):
        """
        يرجع مستوى الـtrailing الذكي.
        
        المصدر: "bring stop below next fractal low once TWO fractals form"
        
        Long: trail تحت آخر fractal low مؤكد (بعد 2 fractals)
        Short: trail فوق آخر fractal high مؤكد
        """
        if len(self.confirmed_fractals) < 2:
            return None  # ما كفاية fractals بعد
        
        if is_long:
            # نبحث عن آخر fractal low
            lows = [f for f in self.confirmed_fractals if f['type'] == 'LOW']
            if len(lows) >= 2:
                # "once TWO fractals form" — ناخد الواحد قبل الأخير
                # لأنو الأخير ممكن لسا ما اتأكد بالكامل
                return lows[-2]['price'] - buffer
        else:
            highs = [f for f in self.confirmed_fractals if f['type'] == 'HIGH']
            if len(highs) >= 2:
                return highs[-2]['price'] + buffer
        
        return None
    
    def is_structure_broken(self, is_long, current_close):
        """
        هل الـstructure انكسر؟ = القصة انتهت.
        
        المصدر: "If your ITH is broken... your idea was wrong"
        
        Long: إذا أغلق تحت آخر fractal low مؤكد
        Short: إذا أغلق فوق آخر fractal high مؤكد
        """
        if is_long:
            lows = [f for f in self.confirmed_fractals if f['type'] == 'LOW']
            if lows and current_close < lows[-1]['price']:
                return True
        else:
            highs = [f for f in self.confirmed_fractals if f['type'] == 'HIGH']
            if highs and current_close > highs[-1]['price']:
                return True
        return False


def manage_dual_position(candle_5m, candle_1h, state):
    """
    يدير المركز المزدوج شمعة بشمعة.
    
    state يحتوي:
      pos_a: {active, entry, sl, tp1, pnl, ...}  ← الصياد
      pos_b: {active, entry, sl, tp2, pnl, tracker, ...}  ← الراكب
    
    candle_5m: شمعة 5M (للصياد)
    candle_1h: شمعة 1H (للراكب — يُمرر كل 12 شمعة 5M)
    """
    h, l, c, o = candle_5m['h'], candle_5m['l'], candle_5m['c'], candle_5m.get('o', candle_5m['c'])
    is_short = state['is_short']
    events = []
    
    # ═══════════════════════════════════════
    # POSITION A: الصياد (scalp + day trade)
    # ═══════════════════════════════════════
    pa = state.get('pos_a', {})
    if pa.get('active'):
        
        # قبل TP1
        if not pa.get('tp1_hit'):
            # SL check
            if (is_short and h >= pa['sl']) or (not is_short and l <= pa['sl']):
                pa['active'] = False
                pa['pnl'] = -state['risk_pct_a']  # lose 0.7% of balance
                pa['exit_reason'] = 'SL_HIT'
                events.append('❌ A:SL')
            # TP1 check
            elif pa.get('tp1'):
                if (is_short and l <= pa['tp1']) or (not is_short and h >= pa['tp1']):
                    pa['tp1_hit'] = True
                    # PnL = (move / risk) × risk_allocation
                    move = abs(pa['tp1'] - pa['entry'])
                    risk_dist = state['risk']
                    rr = move / risk_dist if risk_dist > 0 else 0
                    pa['pnl'] = rr * state['risk_pct_a']  # risk_pct_a = 0.7%
                    pa['sl'] = pa['entry']  # BE
                    events.append('🎯 A:TP1')
        
        # بعد TP1 — trailing سريع على 5M (الصياد يخرج بسرعة)
        elif pa.get('tp1_hit'):
            if (is_short and h >= pa['sl']) or (not is_short and l <= pa['sl']):
                # إذا trailing عند BE = الربح هو TP1 فقط
                pa['active'] = False
                # Runner trailing — الربح يبقى TP1 فقط
                pa['pnl'] = pa.get('pnl', 0)
                pa['exit_reason'] = 'TRAIL'
                events.append('🧠 A:Trail')
            else:
                # Trailing سريع — كل شمعة اتجاهية بجسم >50%
                body = abs(c - o)
                rng = h - l
                if rng > 0 and body / rng > 0.5:
                    if not is_short and c > o:
                        new_sl = l - state.get('atr', 1) * 0.1
                        if new_sl > pa['sl']:
                            pa['sl'] = new_sl
                    elif is_short and c < o:
                        new_sl = h + state.get('atr', 1) * 0.1
                        if new_sl < pa['sl']:
                            pa['sl'] = new_sl
    
    # ═══════════════════════════════════════
    # POSITION B: الراكب (runner — الحركة الكبيرة)
    # ═══════════════════════════════════════
    pb = state.get('pos_b', {})
    if pb.get('active'):
        
        # تهيئة الـfractal tracker إذا ما موجود
        if 'tracker' not in pb:
            pb['tracker'] = SmartFractalTracker()
        
        # إضافة شمعة 1H للـtracker (إذا متوفرة)
        if candle_1h:
            pb['tracker'].add_candle(candle_1h)
        
        # قبل أي شي: هل Position A ضرب TP1؟
        # إذا نعم → SL ينتقل لـBE (حماية مجانية)
        if pa.get('tp1_hit') and not pb.get('be_set'):
            pb['sl'] = pb['entry']
            pb['be_set'] = True
            events.append('🛡️ B:BE (A hit TP1)')
        
        # SL check
        if (is_short and h >= pb['sl']) or (not is_short and l <= pb['sl']):
            pb['active'] = False
            if pb.get('be_set') and abs(pb['sl'] - pb['entry']) < state.get('atr', 1) * 0.1:
                pb['pnl'] = 0
                pb['exit_reason'] = 'BE'
                events.append('🛡️ B:BE exit')
            elif pb.get('be_set'):
                # Trailing exit with profit
                move = abs(pb['sl'] - pb['entry'])
                risk_dist = state['risk']
                rr = move / risk_dist if risk_dist > 0 else 0
                pb['pnl'] = rr * state['risk_pct_b']
                pb['exit_reason'] = 'TRAIL'
                events.append('🧠 B:Trail')
            else:
                pb['pnl'] = -state['risk_pct_b']  # lose 0.3%
                pb['exit_reason'] = 'SL_HIT'
                events.append('❌ B:SL')
        
        # TP2 check (الهدف الذهبي!)
        elif pb.get('tp2_price'):
            if (is_short and l <= pb['tp2_price']) or (not is_short and h >= pb['tp2_price']):
                pb['active'] = False
                move = abs(pb['tp2_price'] - pb['entry'])
                risk_dist = state['risk']
                rr = move / risk_dist if risk_dist > 0 else 0
                pb['pnl'] = rr * state['risk_pct_b']
                pb['exit_reason'] = 'TP2_GOLDEN'
                events.append('🏆 B:TP2 GOLDEN!')
        
        # Structure invalidation check
        elif pb.get('be_set') and pb['tracker'].is_structure_broken(not is_short, c):
            pb['active'] = False
            move = abs(pb['sl'] - pb['entry'])
            risk_dist = state['risk']
            rr = move / risk_dist if risk_dist > 0 else 0
            pb['pnl'] = rr * state['risk_pct_b']
            pb['exit_reason'] = 'STRUCTURE_BREAK'
            events.append('🧱 B:Structure broken')
        
        # Fractal-based trailing (فقط بعد BE)
        elif pb.get('be_set'):
            atr = state.get('atr', abs(pb['entry'] * 0.001))
            trail_level = pb['tracker'].get_trail_level(not is_short, buffer=atr * 0.3)
            
            if trail_level is not None:
                if not is_short and trail_level > pb['sl']:
                    old = pb['sl']
                    pb['sl'] = trail_level
                    if old != trail_level:
                        events.append(f'📈 B:Fractal trail→{trail_level:.0f}')
                elif is_short and trail_level < pb['sl']:
                    old = pb['sl']
                    pb['sl'] = trail_level
                    if old != trail_level:
                        events.append(f'📉 B:Fractal trail→{trail_level:.0f}')
    
    # ═══════════════════════════════════════
    # حالة الصفقة الكلية
    # ═══════════════════════════════════════
    both_closed = (not pa.get('active', False)) and (not pb.get('active', False))
    
    # حساب PnL الإجمالي
    if both_closed:
        total_pnl = (pa.get('pnl', 0) or 0) + (pb.get('pnl', 0) or 0)
        state['pnl_pct'] = total_pnl
        state['exit_reason_a'] = pa.get('exit_reason', '?')
        state['exit_reason_b'] = pb.get('exit_reason', '?')
    
    return events, both_closed
