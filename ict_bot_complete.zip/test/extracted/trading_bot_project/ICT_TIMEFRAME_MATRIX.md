# 🗺️ ICT Timeframe Matrix — كل فريم شو دوره بالضبط

## المصادر:
- michaeljhuddleston.org: ICT Core Content Month 2 Part 2
- innercircletrader.net: Complete ICT Trading Strategy 2022 + Daily Bias + Intraday Strategy
- tradingfinder.com: ICT 2022 Mentorship
- crypoptionhub.com: ICT Mentorship 2022 Guide
- tradingstrategyguides.com: Multi-Timeframe Analysis ICT

---

## التشبيه الرسمي من مايكل:
> **"Daily = الحي، 4H = الشارع، 15M = العنوان بالضبط"**
> — ICT Core Content Month 2

---

## 📊 الفريمات ودورها:

### 🏛️ Daily — القائد (الانحياز)
**الدور:** يحدد **اتجاه اليوم** — شمال ولا جنوب
**ما يفعله مايكل:**
- يقرأ order flow (HH/HL = bullish, LH/LL = bearish)
- يحدد Draw on Liquidity (أين يريد السعر أن يذهب)
- يحدد imbalances غير محشية (FVGs على Daily)
- يقرر: "اليوم بشتري ولا ببيع"
**القاعدة:** بدون Daily bias = لا صفقة!

**المصدر:** innercircletrader.net Daily Bias: "Without a correct daily bias, the rest of the ICT method does not work"

### 📐 4H — السياق (المناطق الكبرى)
**الدور:** يؤكد Daily ويحدد **المناطق المؤسساتية الكبرى**
**ما يفعله مايكل:**
- يؤكد أن 4H ما بيعارض Daily
- يحدد OBs وFVGs الكبيرة (مناطق يتوقع فيها رد فعل)
- يحدد Premium/Discount zones
- **TP2 (الهدف الذهبي) = مستويات من 4H أو Daily**

**المصدر:** "1-day and 4-hour for daily bias" — innercircletrader.net

### 🔍 1H — المنظار (النظرة الأوسع)
**الدور:** يعطي **perspective** — هل الحركة الحالية اندفاع ولا تصحيح
**ما يفعله مايكل:**
- يرسم خطوط السيولة الكبرى (PDH/PDL, PWH/PWL)
- يحدد dealing range
- يشوف هل السعر بـPremium ولا Discount

### 🎯 15M — كاشف السيولة (الإعداد)
**الدور:** يحدد **مستويات السيولة** اللي ستُسحب + يكشف FVGs + OBs
**ما يفعله مايكل:**
- يحدد Swing Highs/Lows (= مستويات السيولة)
- يكشف Sweep (سحب السيولة)
- يحدد FVGs وOBs كمناطق دخول محتملة
- **هذا الفريم اللي يكشف القصة** (sweep حصل ولا لا)

**المصدر:** "15-minute for liquidity and imbalances" — 2022 Strategy

### ⚡ 5M — التأكيد (MSS)
**الدور:** يؤكد **Market Structure Shift** بعد الـsweep
**ما يفعله مايكل:**
- ينتظر MSS (كسر swing بالاتجاه المعاكس للسحب)
- يكشف displacement (شمعة قوية تترك FVG)
- يحدد **نقطة الدخول** (FVG اللي تشكلت من الـdisplacement)
- يحدد **الستوب** (خلف الـswept extreme)
- **TP1 = مستويات سيولة على 5M/15M (low hanging fruit)**

**المصدر:** "5-minute for confirmation and execution" — 2022 Strategy

### 🔬 3M / 1M — الدقة (التنفيذ)
**الدور:** **تنفيذ الدخول بأدق نقطة ممكنة**
**ما يفعله مايكل:**
- يبحث عن FVG داخل الـFVG اللي على 5M
- يستخدم IOFED (حافة الـFVG) كأول entry
- يستخدم CE (50%) كـadd position
- يحدد SL أضيق (خلف MSS swing على 1M)

**المصدر:** "1-minute is the sharpest entry tool" — innercircletrader.net
**تحذير:** "I do not recommend it until you have at least a hundred logged 5-minute setups"

---

## 🔗 كيف يقاطعهم مع بعض (التسلسل الحقيقي):

### مايكل لا يعمل خطوة خطوة خطية — يعمل **طبقات متزامنة**:

```
┌─────────────────────────────────────────────┐
│ LAYER 1: BIAS (Daily + 4H) — يُحدد قبل الجلسة │
│   "اليوم صعودي" أو "اليوم هبوطي"            │
│   + أين الـDraw on Liquidity                │
│   + أين المناطق المؤسساتية (4H OBs/FVGs)    │
└──────────────┬──────────────────────────────┘
               │ ← يبقى ثابت طول اليوم
               ▼
┌─────────────────────────────────────────────┐
│ LAYER 2: STORY (15M) — يُراقب مستمراً       │
│   هل حصل Sweep؟ أين السيولة؟               │
│   هل تشكل FVG/OB جديد؟                    │
│   هذا الفريم يخبرك "القصة الحالية"          │
└──────────────┬──────────────────────────────┘
               │ ← عندما sweep يحصل
               ▼
┌─────────────────────────────────────────────┐
│ LAYER 3: TRIGGER (5M) — يُفعّل عند الحاجة   │
│   هل حصل MSS؟ هل في displacement؟          │
│   هل تشكل FVG من الـdisplacement؟           │
│   ← هون نقرر: "في setup ولا لا"            │
└──────────────┬──────────────────────────────┘
               │ ← عندما FVG تتشكل
               ▼
┌─────────────────────────────────────────────┐
│ LAYER 4: EXECUTION (5M/3M/1M) — لحظة واحدة  │
│   الدخول عند CE أو IOFED                   │
│   SL خلف swept extreme                     │
│   TP1 = أقرب سيولة على 5M/15M              │
│   TP2 = Draw on Liquidity من Daily/4H       │
└─────────────────────────────────────────────┘
```

### القاعدة الذهبية:
> **"When your 5-minute entry, 15-minute trigger, and Daily zone all point
>  in the same direction, you have the kind of confluence that defines a
>  genuinely low-risk, high-quality ICT trade setup."**
> — ICT Core Content Month 2

---

## 🎯 ماذا يعني هذا للبوت؟

### المشكلة الحالية:
البوت يعمل كل شي على **فريم واحد** (5M) مع aggregation بسيطة.
ما في "طبقات" — في خطوات خطية.

### الحل:
```python
# ليس هكذا:
bias = compute_bias(daily)       # خطوة 1
sweep = find_sweep(15m)          # خطوة 2  
mss = find_mss(5m)               # خطوة 3
entry = find_entry(5m)           # خطوة 4

# بل هكذا — طبقات متزامنة:
class ICTLayeredAnalysis:
    def __init__(self):
        self.bias_layer = BiasLayer()      # Daily+4H → يعمل مرة/يوم
        self.story_layer = StoryLayer()    # 15M → يعمل كل 15 دقيقة
        self.trigger_layer = TriggerLayer() # 5M → يعمل كل 5 دقائق
        self.exec_layer = ExecLayer()      # 1M → يعمل عند الحاجة
    
    def scan(self, all_data, now_ts):
        # كل الطبقات تعمل بالتوازي — مش بالتسلسل!
        bias = self.bias_layer.read(all_data['1d'], all_data['4h'])
        
        # 15M تقرأ القصة بسياق الـbias
        story = self.story_layer.read(all_data['15m'], bias)
        
        # 5M تبحث عن trigger بسياق القصة + الـbias
        trigger = self.trigger_layer.read(all_data['5m'], story, bias)
        
        # الدخول يحتاج كل الطبقات متفقة
        if trigger.ready and story.has_sweep and bias.is_clear:
            return self.exec_layer.build_plan(
                trigger, story, bias,
                tp1_from='5m/15m',    # low hanging fruit
                tp2_from='4h/daily',  # Draw on Liquidity
                sl_from='5m_swept_extreme',
            )
```

### SL و TP حسب الفريم:

```
┌────────────┬──────────────────────────────┐
│ Component  │ Which Timeframe?             │
├────────────┼──────────────────────────────┤
│ SL         │ 5M swept extreme + buffer    │
│ TP1        │ 5M/15M nearest liquidity     │
│ TP2        │ 4H/Daily Draw on Liquidity   │
│ Trailing   │ 15M structure (not 5M!)      │
│ Entry      │ 5M FVG CE or 1M IOFED       │
│ Bias       │ Daily + 4H confirmation      │
│ Sweep      │ 15M swing levels             │
│ MSS        │ 5M displacement + close      │
└────────────┴──────────────────────────────┘
```

**المفتاح:** الـtrailing على **15M** مش 5M!
هاد اللي كان يطلّعنا بدري — swings على 5M كثيرة وصغيرة.
Swings على 15M أكبر وأهم = trailing أبطأ = نلتقط أكثر.
