# This script will demonstrate the new logic that combines HTF context, sweep context, and current price action.
import sys
sys.path.insert(0, ".")
from data_manager import DataManager
from authenticity_engine import AuthenticityEngine
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run

dm = DataManager()
data_1d = dm.get_ohlcv("SOLUSDT", "1d", 100, output_format="dict")
bias = compute_mechanical_bias_anchor(data_1d, lookback=60)

data_15m = dm.get_ohlcv("SOLUSDT", "15m", 200, output_format="dict")
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}

ae = AuthenticityEngine()
sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)

# Check if a sweep RECENTLY happened and the bot is waiting for a setup.
# Find recent sweeps in the last 15 candles.
recent_sweeps = []
# For Bullish: check if recent lows swept a major level
# For Bearish: check if recent highs swept a major level

