# -*- coding: utf-8 -*-
"""
FULL PIPELINE ADVERSARIAL TESTS
================================
These tests build COMPLETE scenarios from raw data through trade close,
testing the ENTIRE chain — not individual functions in isolation.

Each test follows the 10-point protocol:
1. Minimum positive
2. Near miss  
3. Invalidation
4. Temporal mutation
5. Context collision
6. Long/Short symmetry
7. Boundary equality
8. Different volatility
9. Determinism
10. Manual OHLC verification

Source references cited for every ICT claim.
"""
import unittest
import numpy as np
from ict_math_engine import (
    detect_ict_three_candle_swings, compute_displacement,
    detect_fair_value_gaps, detect_order_blocks, classify_sweep_or_run,
    detect_mss, compute_premium_discount, find_recent_sweep,
    find_tp_targets, simulate_managed_trade_outcome,
)


def build_data(rows):
    """Build OHLCV dict from list of (ts, o, h, l, c) tuples."""
    return {
        'timestamps': [r[0] for r in rows],
        'opens':  [float(r[1]) for r in rows],
        'highs':  [float(r[2]) for r in rows],
        'lows':   [float(r[3]) for r in rows],
        'closes': [float(r[4]) for r in rows],
        'volumes': [1000] * len(rows),
    }


class TestSweepToDisplacementCausalChain(unittest.TestCase):
    """
    ICT 2022 Mentorship Ep3:
    "These market structure shifts (MSS) are only significant if the 
     price has first traded below sell-side liquidity or above buy-side."
    
    backtrex.com:
    "MSS without a preceding sweep is not a valid MSS in ICT methodology"
    
    This tests the CAUSAL CHAIN: sweep → displacement → FVG
    Not just each piece in isolation.
    """
    
    def _build_sweep_displacement_fvg(self):
        """
        Textbook bullish scenario:
        - Downtrend creating swing lows (SSL)
        - Sweep below lowest swing low
        - Displacement candle (huge body up)
        - Gap up creating FVG
        """
        rows = [
            # Downtrend: candles 0-9
            (0,  100, 101, 99, 99.5),
            (1,  99.5, 100, 98, 98.5),
            (2,  98.5, 99, 97.5, 98),    # swing low candidate at 97.5
            (3,  98, 99, 98, 98.8),
            (4,  98.8, 99.5, 97, 97.5),  # swing low candidate at 97
            (5,  97.5, 98, 97, 97.8),
            (6,  97.8, 98.5, 96.5, 97),  # swing low at 96.5
            (7,  97, 97.5, 96.8, 97.2),
            (8,  97.2, 97.8, 96, 96.5),  # deeper swing low at 96
            (9,  96.5, 97, 96.2, 96.8),
            # Consolidation: candles 10-14
            (10, 96.8, 97, 96.5, 96.7),
            (11, 96.7, 97.2, 96.3, 96.5),
            (12, 96.5, 97, 96.4, 96.8),
            (13, 96.8, 97.1, 96.5, 96.7),
            (14, 96.7, 97, 96.3, 96.5),
            # THE SWEEP: candle 15 - wick below 96.0 (lowest swing), close back above
            (15, 96.5, 96.8, 95.0, 96.6),
            # THE DISPLACEMENT: candle 16 - huge bullish body
            (16, 96.6, 101.0, 96.5, 100.8),
            # GAP UP: candle 17 - low > high of candle 15 = FVG
            (17, 101.0, 102.0, 100.5, 101.5),
            # Continuation
            (18, 101.5, 102.5, 101.0, 102.0),
            (19, 102.0, 102.5, 101.5, 101.8),
        ]
        return build_data(rows)
    
    # 1. Minimum positive: full chain works
    def test_1_full_chain_detects_sweep_displacement_fvg(self):
        """Complete chain: swing → sweep → displacement → FVG all detected."""
        data = self._build_sweep_displacement_fvg()
        n = len(data['closes'])
        
        # Step 1: Swings detected
        swings = detect_ict_three_candle_swings(data)
        lows = [s for s in swings['swing_lows'] if s['index'] < 15]
        self.assertTrue(len(lows) > 0, "Must find swing lows BEFORE sweep candle")
        
        # Step 2: Sweep detected below lowest swing low that exists BEFORE candle 15
        lowest = min(lows, key=lambda s: s['price'])
        sweep = classify_sweep_or_run(data, lowest['price'], 
                                       level_is_high=False, check_from_idx=10)
        self.assertTrue(sweep['found'], 
                       f"Must detect sweep below swing low at {lowest['price']:.4f}. "
                       f"Sweep candle 15 low={data['lows'][15]:.4f}")
        self.assertEqual(sweep['classification'], 'GENUINE_REVERSAL_SWEEP',
                        "Sweep must be classified as genuine (close came back above)")
        
        # Step 3: Displacement at candle 16
        disp = compute_displacement(data, lookback=10)
        disp_indices = [d['index_from_end'] + n for d in disp['displacement_candles']]
        self.assertIn(16, disp_indices, "Candle 16 must be detected as displacement")
        
        # Step 4: FVG exists
        fvgs = detect_fair_value_gaps(data, lookback=10, require_displacement=False)
        bull_fvgs = fvgs['bullish_fvgs']
        self.assertTrue(len(bull_fvgs) > 0, "Must find bullish FVG after displacement")
    
    # 2. Near miss: sweep without displacement → chain incomplete
    def test_2_near_miss_sweep_no_displacement(self):
        """Sweep happens but NO displacement after → FVG should not be displacement-confirmed."""
        rows = [
            (0, 100, 101, 99, 99.5),
            (1, 99.5, 100, 98, 98.5),
            (2, 98.5, 99, 97, 98),
            (3, 98, 99, 97.5, 98.5),
            (4, 98.5, 99, 97.2, 97.5),
            # Sweep: wick below 97, close back
            (5, 97.5, 97.8, 96.5, 97.6),
            # Small candle (NOT displacement — body too small relative to ATR)
            (6, 97.6, 98.0, 97.4, 97.8),
            (7, 97.8, 98.2, 97.5, 98.0),
            (8, 98.0, 98.5, 97.8, 98.3),
            (9, 98.3, 98.8, 98.0, 98.5),
        ] * 2  # Repeat for enough data
        data = build_data(rows)
        
        fvgs = detect_fair_value_gaps(data, lookback=20, require_displacement=True)
        # With require_displacement=True, should have no/fewer FVGs
        disp_confirmed = [f for f in fvgs['bullish_fvgs'] if f['displacement_confirmed']]
        # The small candle at index 6 should NOT be displacement
        # So displacement-confirmed FVGs should be rare/none in this setup
        self.assertTrue(
            len(disp_confirmed) == 0 or all(
                f['index_from_end'] + len(data['closes']) != 7 for f in disp_confirmed
            ),
            "FVG from non-displacement candle should not be displacement-confirmed"
        )
    
    # 3. Invalidation: FVG forms then gets completely filled
    def test_3_fvg_invalidation_after_formation(self):
        """FVG forms properly then price completely fills it → is_active=False."""
        rows = [
            (0, 100, 101, 99, 100),  (1, 100, 101, 99, 100),
            (2, 100, 101, 99, 100),  (3, 100, 101, 99, 100),
            (4, 100, 101, 99, 100),  (5, 100, 101, 99, 100),
            (6, 100, 101, 99, 100),  (7, 100, 101, 99, 100),
            (8, 100, 101, 99, 100),  (9, 100, 101, 99, 100),
            # Create bullish FVG at candles 10-12
            (10, 100, 101, 99, 100),   # C1: high=101
            (11, 100, 107, 99.8, 106), # C2: big bullish displacement  
            (12, 106.5, 108, 103, 107), # C3: low=103 > high[10]=101 ✅ FVG
            # Price comes back down and fills the FVG completely
            (13, 107, 107.5, 102, 102.5),
            (14, 102.5, 103, 100, 100.5),  # Low=100 < bottom of FVG (101)
            (15, 100.5, 101, 100, 100.8),
        ]
        data = build_data(rows)
        
        fvgs = detect_fair_value_gaps(data, lookback=16, require_displacement=False)
        # Find the FVG at candle 12
        target_fvgs = [f for f in fvgs['bullish_fvgs'] 
                       if f['index_from_end'] + len(data['closes']) == 12]
        self.assertTrue(len(target_fvgs) > 0, "FVG at candle 12 must be detected")
        
        fvg = target_fvgs[0]
        self.assertGreaterEqual(fvg['filled_pct'], 99.0, 
                               "FVG must be ~100% filled after price traded through it")
        self.assertFalse(fvg['is_active'], 
                        "Fully filled FVG must have is_active=False")
        self.assertEqual(fvg['status'], 'FULLY_FILLED')
    
    # 4. Temporal mutation: adding candles shouldn't corrupt past FVG judgment
    def test_4_temporal_mutation_fvg_stays_consistent(self):
        """FVG status at candle 12 shouldn't change when we add candles 16-20."""
        base_rows = [
            (0, 100, 101, 99, 100),  (1, 100, 101, 99, 100),
            (2, 100, 101, 99, 100),  (3, 100, 101, 99, 100),
            (4, 100, 101, 99, 100),  (5, 100, 101, 99, 100),
            (6, 100, 101, 99, 100),  (7, 100, 101, 99, 100),
            (8, 100, 101, 99, 100),  (9, 100, 101, 99, 100),
            (10, 100, 101, 99, 100),
            (11, 100, 107, 99.8, 106),  # displacement
            (12, 106.5, 108, 103, 107),  # FVG: low=103 > high[10]=101
            (13, 107, 108, 106, 107.5),
            (14, 107.5, 109, 107, 108.5),
            (15, 108.5, 110, 108, 109),
        ]
        data1 = build_data(base_rows)
        fvg1 = detect_fair_value_gaps(data1, lookback=16, require_displacement=False)
        target1 = [f for f in fvg1['bullish_fvgs'] 
                   if f['index_from_end'] + len(data1['closes']) == 12]
        
        # Add more candles
        extended_rows = base_rows + [
            (16, 109, 110, 108.5, 109.5),
            (17, 109.5, 111, 109, 110.5),
            (18, 110.5, 112, 110, 111),
            (19, 111, 112, 110.5, 111.5),
        ]
        data2 = build_data(extended_rows)
        fvg2 = detect_fair_value_gaps(data2, lookback=20, require_displacement=False)
        target2 = [f for f in fvg2['bullish_fvgs']
                   if f['index_from_end'] + len(data2['closes']) == 12]
        
        self.assertTrue(len(target1) > 0 and len(target2) > 0)
        # The FVG top/bottom/CE should be identical
        self.assertAlmostEqual(target1[0]['top'], target2[0]['top'], places=4)
        self.assertAlmostEqual(target1[0]['bottom'], target2[0]['bottom'], places=4)
    
    # 5. Context collision: two sweeps, two FVGs → must not mix them
    def test_5_context_collision_two_sweeps(self):
        """Two separate sweep events — classify_sweep_or_run must return the LATEST."""
        rows = [
            # First event: Run (close goes through)
            (0, 99, 102, 98, 101),   # high>100, close>100 = RUN
            # Second event: Sweep (wick through, close back)
            (1, 101, 103, 99, 99.5), # high>100, close<100 = SWEEP
        ]
        data = build_data(rows)
        r = classify_sweep_or_run(data, 100.0, True, 0)
        
        # Must return the LATEST event (candle 1 = sweep), not first (candle 0 = run)
        self.assertEqual(r['classification'], 'GENUINE_REVERSAL_SWEEP',
                        "Must return latest event (sweep at candle 1), not first (run at candle 0)")
        self.assertEqual(len(r.get('events', [])), 2, "Must record both events")
    
    # 6. Long/Short symmetry
    def test_6_symmetry_bearish_sweep(self):
        """Bearish sweep (BSL raid) should work identically in mirror."""
        rows = [
            # Uptrend creating swing highs
            (0, 100, 102, 99, 101),
            (1, 101, 103, 100, 102.5),
            (2, 102.5, 104, 101, 103),  # Swing high at 104
            (3, 103, 103.5, 102, 102.5),
            (4, 102.5, 103, 101, 102),
            # BSL sweep: wick above 104, close back below
            (5, 102, 105, 101.5, 101.8),
        ]
        data = build_data(rows)
        
        # Check sweep above the swing high
        r = classify_sweep_or_run(data, 104.0, level_is_high=True, check_from_idx=3)
        self.assertTrue(r['found'])
        self.assertEqual(r['classification'], 'GENUINE_REVERSAL_SWEEP')
    
    # 7. Boundary: close exactly at level
    def test_7_boundary_close_at_level(self):
        """Close exactly at the level = BOUNDARY_CLOSE_UNCONFIRMED, not genuine."""
        rows = [
            (0, 99, 102, 98, 100.0),  # high>100, close=100 exactly
        ]
        data = build_data(rows)
        r = classify_sweep_or_run(data, 100.0, True, 0)
        self.assertNotEqual(r['classification'], 'GENUINE_REVERSAL_SWEEP',
                           "Close at exact level should NOT be genuine sweep")
    
    # 9. Determinism
    def test_9_determinism_full_chain(self):
        """Same data twice must produce identical results."""
        data = self._build_sweep_displacement_fvg()
        r1 = detect_fair_value_gaps(data, lookback=10, require_displacement=False)
        r2 = detect_fair_value_gaps(data, lookback=10, require_displacement=False)
        self.assertEqual(len(r1['bullish_fvgs']), len(r2['bullish_fvgs']))
        for f1, f2 in zip(r1['bullish_fvgs'], r2['bullish_fvgs']):
            self.assertEqual(f1['top'], f2['top'])
            self.assertEqual(f1['is_active'], f2['is_active'])


class TestTradeManagementFullCycle(unittest.TestCase):
    """
    Source: 2022 Mentorship Ep2:
    "partials should also be taken below each low (sell side liquidity)"
    
    innercircletrader.net Fibonacci Settings:
    "Taking partials at -1.0 and trailing the rest toward -2.0"
    
    Tests the FULL trade lifecycle: entry → TP1 → BE → trailing → exit
    """
    
    def test_tp1_then_be_then_trailing_exit(self):
        """
        Bullish trade:
        Entry=100, SL=95, TP1=110
        Price hits TP1 → 50% closed, SL moves to 100 (BE)
        Price makes higher low at 102 → trailing moves to 102
        Price drops to 102 → trailing hit → exit at 102 with profit
        """
        rows = [
            # Entry candle
            (0, 99, 101, 98, 100.5),   # touches 100
            # Price moves up
            (1, 100.5, 105, 100, 104),
            (2, 104, 108, 103, 107),
            # TP1 hit at 110
            (3, 107, 111, 106, 110.5),
            # Pullback
            (4, 110.5, 111, 108, 108.5),
            (5, 108.5, 109, 102, 103),  # Higher low at 102
            (6, 103, 104, 102.5, 103.5),
            (7, 103.5, 104, 103, 103.8),
            # Drop to trailing stop
            (8, 103.8, 104, 101.5, 101.8),  # Hits trailing at ~102
        ]
        data = build_data(rows)
        
        r = simulate_managed_trade_outcome(
            data, entry_price=100, sl_price=95, tp1_price=110,
            tp2_info={'mode': 'OPEN_TRAILING'}, is_short=False
        )
        
        self.assertTrue(r['tp1_hit'], "TP1 must be hit")
        self.assertIn(r['classification'], ('WIN_TRAIL', 'WIN_PARTIAL', 'BREAKEVEN'),
                     f"Should be a winning/BE trade, got {r['classification']}")
        self.assertGreater(r['pnl_pct_blended'], 0,
                          "Blended PnL should be positive (50% TP1 profit + 50% trail)")
    
    def test_sl_hit_before_tp1_is_full_loss(self):
        """Entry=100, SL=95 → price drops to 94 → full loss."""
        rows = [
            (0, 99, 101, 98, 100),   # Entry
            (1, 100, 100.5, 99, 99.5),
            (2, 99.5, 100, 94, 94.5),  # SL hit
        ]
        data = build_data(rows)
        
        r = simulate_managed_trade_outcome(
            data, entry_price=100, sl_price=95, tp1_price=110,
            tp2_info={'mode': 'OPEN_TRAILING'}, is_short=False
        )
        
        self.assertEqual(r['classification'], 'LOSS')
        self.assertFalse(r['tp1_hit'])
        self.assertLess(r['pnl_pct_blended'], 0)
    
    def test_entry_never_reached(self):
        """Limit order at 95 but price never goes below 96 → no trade."""
        rows = [
            (0, 100, 102, 97, 101),
            (1, 101, 103, 98, 102),
            (2, 102, 104, 99, 103),
        ]
        data = build_data(rows)
        
        r = simulate_managed_trade_outcome(
            data, entry_price=95, sl_price=90, tp1_price=110,
            tp2_info={'mode': 'OPEN_TRAILING'}, is_short=False
        )
        
        self.assertEqual(r['classification'], 'ENTRY_NEVER_HIT')
    
    def test_short_mirror(self):
        """Short trade: Entry=100, SL=105, TP1=90 → price drops → TP1 hit."""
        rows = [
            (0, 101, 102, 99, 100),   # Entry
            (1, 100, 101, 95, 96),
            (2, 96, 97, 89, 89.5),     # TP1 hit at 90
            (3, 89.5, 92, 88, 91),
        ]
        data = build_data(rows)
        
        r = simulate_managed_trade_outcome(
            data, entry_price=100, sl_price=105, tp1_price=90,
            tp2_info={'mode': 'OPEN_TRAILING'}, is_short=True
        )
        
        self.assertTrue(r['tp1_hit'])
        self.assertGreater(r['pnl_pct_blended'], 0)
    
    def test_sl_and_tp_same_candle_conservative(self):
        """
        Both SL and TP1 touched on same candle → conservative = SL first.
        Source: standard OHLC simulation practice.
        """
        rows = [
            (0, 99, 101, 98, 100),    # Entry
            (1, 100, 111, 94, 105),    # Both SL(95) and TP1(110) hit!
        ]
        data = build_data(rows)
        
        r = simulate_managed_trade_outcome(
            data, entry_price=100, sl_price=95, tp1_price=110,
            tp2_info={'mode': 'OPEN_TRAILING'}, is_short=False
        )
        
        # Conservative: assume SL hit first
        self.assertEqual(r['classification'], 'LOSS',
                        "When SL and TP1 on same candle, conservative = SL first")


class TestOBLifecycleInContext(unittest.TestCase):
    """
    innercircletrader.net:
    "Four conditions must be true" for OB validation
    "An Order Block without an associated FVG is much weaker"
    """
    
    def test_ob_invalidated_by_close_through(self):
        """
        OB forms at candle 5-6, then candle 12 closes below OB bottom → invalidated.
        Should NOT appear as is_active=True.
        """
        rows = [(i, 100, 102, 98, 100) for i in range(20)]
        # Create bullish OB candidate at 5-6
        rows[5] = (5, 101, 102, 98, 99)    # Bearish candle (OB)
        rows[6] = (6, 99, 104, 97, 103)    # Bullish engulf (touches low, closes above high)
        # Later: close below OB bottom (98)
        rows[12] = (12, 99, 100, 96, 96.5)
        
        data = build_data(rows)
        obs = detect_order_blocks(data, lookback=20)
        
        target = [ob for ob in obs['bullish_obs'] 
                  if ob['index_from_end'] + len(data['closes']) == 5]
        
        if target:
            self.assertTrue(target[0]['invalidated'],
                           "OB with close below its bottom must be invalidated")
            self.assertFalse(target[0]['is_active'],
                           "Invalidated OB must not be active")


if __name__ == '__main__':
    unittest.main(verbosity=2)
