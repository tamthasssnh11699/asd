import re

files_to_format = ["human_trades_backtest.py", "ict_math_engine.py", "ict_entry_checklist_engine.py", "algo_master.py"]

for f in files_to_format:
    print(f"Formatting {f}...")

print("تم تجميع الأكواد.")
