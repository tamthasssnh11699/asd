import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore

brain = BrainCore()
SYMBOL = "ETH/USDT"

entry_ts = 1783302300000 # 2026-07-06 01:45 UTC
entry_price = 1788.86
original_sl = 1793.00

print("=== محاكاة (قراءة هيكل السوق كمتداول متمرس) ===")
data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", entry_ts + 24*3600*1000, limit=150)

current_sl = original_sl
in_trade = True
risk = original_sl - entry_price

for i in range(len(data_5m['closes'])):
    if data_5m['timestamps'][i] < entry_ts: continue
    
    h = data_5m['highs'][i]
    l = data_5m['lows'][i]
    dt_utc = datetime.datetime.fromtimestamp(data_5m['timestamps'][i]/1000, tz=datetime.timezone.utc)
    
    # الخروج عند ضرب الستوب الديناميكي
    if h >= current_sl:
        profit = entry_price - current_sl
        print(f"❌ [{dt_utc.strftime('%H:%M')}] كسر القمة الهيكلية! خروج يدوي. الربح المحقق = {profit/(risk):.2f}R")
        in_trade = False
        break
        
    # الذكاء الهيكلي الحقيقي (Trail above Swing Highs)
    # لا نقوم بتقريب الستوب بطريقة عمياء للشموع الثلاثة الأخيرة.
    # ننتظر السعر ليهبط بقوة ويصنع قمة محلية، ثم نضع الستوب فوقها.
    # للتبسيط هنا: ننقل الستوب فقط عندما يهبط السعر لمستويات دنيا جديدة، ونضعه فوق قمة الشمعة التي سبقت الانطلاق.
    if l < (entry_price - 4*risk): 
        # السعر وصل لـ 4R !
        # ننقل الستوب لمنطقة تأمين قوية مثلا 3R
        smart_sl = entry_price - 2.5*risk
        if smart_sl < current_sl:
            print(f"🧠 [{dt_utc.strftime('%H:%M')}] السعر ضرب 4R. تأمين الأرباح عند 2.5R (سعر {smart_sl:.2f}).")
            current_sl = smart_sl
            
    elif l < (entry_price - 8*risk):
        # السعر وصل لـ 8R !
        smart_sl = entry_price - 6.0*risk
        if smart_sl < current_sl:
            print(f"🧠 [{dt_utc.strftime('%H:%M')}] السعر ضرب 8R. تأمين الأرباح عند 6.0R (سعر {smart_sl:.2f}).")
            current_sl = smart_sl

