# -*- coding: utf-8 -*-
"""
HONEST BACKTEST — March 2025 BTC/USDT 5m
==========================================
Rules:
1. NO FUTURE DATA: at each point, the bot only sees candles UP TO that moment
2. Walk-forward: simulate scan every 12 candles (1 hour) 
3. Use 250 candles lookback for analysis (same as live)
4. Kill Zone gate: only trade during London/NY sessions
5. Track every trade from entry to close
6. Log every decision with reasoning

Data: Real BTC/USDT 5m from Binance, Feb-Mar 2025
Test month: March 2025 only (Feb is lookback warmup)
"""
import csv
import sys
import os
import json
import datetime
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ict_math_engine import (
    detect_ict_three_candle_swings, compute_displacement,
    detect_fair_value_gaps, detect_order_blocks, classify_sweep_or_run,
    detect_mss, compute_mechanical_bias_anchor, compute_premium_discount,
    find_recent_sweep, find_tp_targets, simulate_managed_trade_outcome,
)
from ict_sessions import classify_session
from ict_entry_checklist_engine import evaluate_all_entry_models

# ═══════════════════════════════════════════════════════════
# LOAD DATA
# ═══════════════════════════════════════════════════════════
def load_csv(path):
    """Load OHLCV CSV into our dict format."""
    rows = []
    with open(path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            dt = datetime.datetime.strptime(row['datetime'], '%Y-%m-%d %H:%M')
            ts = int(dt.timestamp() * 1000)
            rows.append({
                'ts': ts,
                'dt': row['datetime'],
                'o': float(row['open']),
                'h': float(row['high']),
                'l': float(row['low']),
                'c': float(row['close']),
                'v': float(row['volume']),
            })
    return rows

def slice_data(all_rows, end_idx, lookback=250):
    """Get lookback candles UP TO end_idx (NO future data)."""
    start = max(0, end_idx - lookback + 1)
    chunk = all_rows[start:end_idx + 1]
    return {
        'timestamps': [r['ts'] for r in chunk],
        'opens':  [r['o'] for r in chunk],
        'highs':  [r['h'] for r in chunk],
        'lows':   [r['l'] for r in chunk],
        'closes': [r['c'] for r in chunk],
        'volumes': [r['v'] for r in chunk],
    }

# ═══════════════════════════════════════════════════════════
# BUILD HIGHER TIMEFRAMES (from 5m data, no cheating)
# ═══════════════════════════════════════════════════════════
def aggregate_tf(data_5m, tf_minutes):
    """Aggregate 5m candles into higher TF. Only uses closed candles."""
    n = len(data_5m['closes'])
    ratio = tf_minutes // 5
    if n < ratio:
        return None
    
    agg_n = n // ratio
    out = {'timestamps': [], 'opens': [], 'highs': [], 'lows': [], 'closes': [], 'volumes': []}
    for i in range(agg_n):
        s = i * ratio
        e = s + ratio
        out['timestamps'].append(data_5m['timestamps'][s])
        out['opens'].append(data_5m['opens'][s])
        out['highs'].append(max(data_5m['highs'][s:e]))
        out['lows'].append(min(data_5m['lows'][s:e]))
        out['closes'].append(data_5m['closes'][e - 1])
        out['volumes'].append(sum(data_5m['volumes'][s:e]))
    return out

# ═══════════════════════════════════════════════════════════
# MAIN BACKTEST
# ═══════════════════════════════════════════════════════════
def run_backtest():
    data_path = '/home/user/historical_data/btc_jan_mar_2025.csv'
    all_rows = load_csv(data_path)
    print(f"Loaded {len(all_rows)} candles ({all_rows[0]['dt']} to {all_rows[-1]['dt']})")
    
    # Find March 1 start index
    march_start = None
    for i, r in enumerate(all_rows):
        if r['dt'].startswith('2025-03-01'):
            march_start = i
            break
    
    if march_start is None:
        print("ERROR: Can't find March 2025 data")
        return
    
    print(f"March starts at index {march_start} ({all_rows[march_start]['dt']})")
    print(f"Lookback warmup: {march_start} candles from February")
    
    # Scan every 12 candles (1 hour) through March
    scan_interval = 12
    trades = []
    active_trade = None
    trade_log = []
    scan_count = 0
    signals_found = 0
    
    EXECUTABLE_SESSIONS = {"LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"}
    RISK_PCT = 0.01
    ACCOUNT = 1000.0
    
    march_end = len(all_rows)  # all data through end of March
    
    for idx in range(march_start, march_end, scan_interval):
        scan_count += 1
        current_row = all_rows[idx]
        now_ts = current_row['ts']
        
        # ═══ MANAGE ACTIVE TRADE (check every scan) ═══
        if active_trade is not None:
            cur_high = current_row['h']
            cur_low = current_row['l']
            t = active_trade
            
            # Simple trade management (matching algo_master logic)
            closed = False
            msg = None
            
            if t['is_short']:
                if cur_high >= t['current_sl']:
                    if t['current_sl'] == t['sl']:
                        msg = "SL_HIT"; t['pnl'] = -t['risk_usd']
                    elif t['current_sl'] == t['entry']:
                        msg = "BE_EXIT"; t['pnl'] = 0
                    else:
                        profit = (t['entry'] - t['current_sl']) * t['size'] * (0.5 if t['tp1_hit'] else 1.0)
                        msg = f"TRAIL_EXIT +{profit:.2f}"; t['pnl'] = profit
                    closed = True
                elif cur_low <= t['tp1'] and not t['tp1_hit']:
                    partial = abs(t['tp1'] - t['entry']) * t['size'] * 0.5
                    t['tp1_hit'] = True; t['current_sl'] = t['entry']; t['partial_pnl'] = partial
                    msg = f"TP1_HIT +{partial:.2f} → BE"
            else:
                if cur_low <= t['current_sl']:
                    if t['current_sl'] == t['sl']:
                        msg = "SL_HIT"; t['pnl'] = -t['risk_usd']
                    elif t['current_sl'] == t['entry']:
                        msg = "BE_EXIT"; t['pnl'] = 0
                    else:
                        profit = (t['current_sl'] - t['entry']) * t['size'] * (0.5 if t['tp1_hit'] else 1.0)
                        msg = f"TRAIL_EXIT +{profit:.2f}"; t['pnl'] = profit
                    closed = True
                elif cur_high >= t['tp1'] and not t['tp1_hit']:
                    partial = abs(t['tp1'] - t['entry']) * t['size'] * 0.5
                    t['tp1_hit'] = True; t['current_sl'] = t['entry']; t['partial_pnl'] = partial
                    msg = f"TP1_HIT +{partial:.2f} → BE"
            
            if msg:
                trade_log.append({
                    'time': current_row['dt'], 'event': msg,
                    'price': current_row['c'], 'sl': t['current_sl']
                })
            
            if closed:
                total_pnl = t.get('partial_pnl', 0) + t.get('pnl', 0)
                ACCOUNT += total_pnl
                t['exit_time'] = current_row['dt']
                t['exit_reason'] = msg
                t['total_pnl'] = total_pnl
                trades.append(dict(t))
                active_trade = None
            continue  # Don't scan for new trades while in a trade
        
        # ═══ ANALYSIS (NO FUTURE DATA) ═══
        # Get 5m data up to current candle
        data_5m = slice_data(all_rows, idx, lookback=250)
        
        # Build higher TFs from the SAME lookback window (larger)
        data_full = slice_data(all_rows, idx, lookback=10000)
        data_15m = aggregate_tf(data_full, 15)
        data_1h = aggregate_tf(data_full, 60)
        data_4h = aggregate_tf(data_full, 240)
        data_1d = aggregate_tf(data_full, 1440)
        
        if not data_1d or len(data_1d['closes']) < 10:
            continue
        
        # Step 1: Session check
        sess = classify_session(now_ts)
        if sess['session'] not in EXECUTABLE_SESSIONS:
            continue
        
        # Step 2: Daily bias
        bias_info = compute_mechanical_bias_anchor(data_1d, lookback=30)
        bias = bias_info['anchor_direction']
        if bias not in ('BULLISH', 'BEARISH'):
            continue
        
        # Step 3: Sweep on 15m
        if not data_15m or len(data_15m['closes']) < 20:
            continue
        is_long = (bias == 'BULLISH')
        sweep = find_recent_sweep(data_15m, is_long, window=12)
        if not sweep:
            continue
        
        # Step 4: Entry models on 5m
        try:
            htf_sources = []
            if data_1d: htf_sources.append(('1d', data_1d))
            if data_4h: htf_sources.append(('4h', data_4h))
            
            model_res = evaluate_all_entry_models(
                data_5m, bias, lookback=150,
                htf_data_sources=htf_sources,
                setup_tf_data=data_15m
            )
        except Exception as e:
            continue
        
        if not model_res or model_res.get('error'):
            continue
        
        chosen = model_res.get('chosen_model')
        if not chosen or chosen.get('status') not in ('READY',):
            continue
        
        # Check not OBSERVATION_ONLY
        if chosen.get('status') == 'OBSERVATION_ONLY':
            continue
        if chosen.get('model') == 'GENERIC_STRUCTURAL_FALLBACK':
            continue
        
        plan = chosen.get('plan')
        if not plan or not plan.get('entry') or not plan.get('stop_loss') or not plan.get('tp'):
            continue
        
        entry = plan['entry']
        sl = plan['stop_loss']
        tp1 = plan['tp']
        
        # Sanity: geometry check
        if is_long and sl >= entry:
            continue
        if not is_long and sl <= entry:
            continue
        
        risk_dist = abs(entry - sl)
        if risk_dist <= 0:
            continue
        
        risk_usd = ACCOUNT * RISK_PCT
        pos_size = risk_usd / risk_dist
        
        signals_found += 1
        
        # Open trade
        active_trade = {
            'entry_time': current_row['dt'],
            'model': chosen['model'],
            'bias': bias,
            'entry': entry,
            'sl': sl,
            'tp1': tp1,
            'current_sl': sl,
            'tp1_hit': False,
            'is_short': not is_long,
            'risk': risk_dist,
            'size': pos_size,
            'risk_usd': risk_usd,
            'partial_pnl': 0,
            'pnl': 0,
            'conditions': [(c['name'], c['status']) for c in chosen.get('conditions', [])],
        }
        
        trade_log.append({
            'time': current_row['dt'],
            'event': f"OPEN {bias} {chosen['model']}",
            'entry': entry, 'sl': sl, 'tp1': tp1,
            'price': current_row['c'],
        })
    
    # ═══════════════════════════════════════════════════════════
    # RESULTS
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'='*70}")
    print(f"  BACKTEST RESULTS — March 2025 BTC/USDT 5m")
    print(f"{'='*70}")
    print(f"Scans: {scan_count}")
    print(f"Signals found: {signals_found}")
    print(f"Trades executed: {len(trades)}")
    
    if trades:
        wins = [t for t in trades if t['total_pnl'] > 0]
        losses = [t for t in trades if t['total_pnl'] < 0]
        bes = [t for t in trades if t['total_pnl'] == 0]
        
        print(f"Wins: {len(wins)} | Losses: {len(losses)} | BE: {len(bes)}")
        print(f"Win rate: {len(wins)/len(trades)*100:.1f}%")
        print(f"Total PnL: ${sum(t['total_pnl'] for t in trades):.2f}")
        print(f"Final balance: ${ACCOUNT:.2f}")
        
        print(f"\n{'='*70}")
        print(f"  TRADE DETAILS")
        print(f"{'='*70}")
        for i, t in enumerate(trades):
            print(f"\n  Trade #{i+1}:")
            print(f"    Model: {t['model']}")
            print(f"    Bias: {t['bias']}")
            print(f"    Entry: {t['entry_time']} @ {t['entry']:.2f}")
            print(f"    SL: {t['sl']:.2f} | TP1: {t['tp1']:.2f}")
            print(f"    Exit: {t.get('exit_time','STILL OPEN')} — {t.get('exit_reason','')}")
            print(f"    PnL: ${t['total_pnl']:.2f}")
            print(f"    Conditions:")
            for name, status in t.get('conditions', []):
                ico = '✅' if status is True else ('❌' if status is False else '⏳')
                print(f"      {ico} {name}")
    else:
        print("\n  ⚠️ NO TRADES EXECUTED!")
        print(f"  Signals found but not executed: {signals_found}")
        if signals_found == 0:
            print(f"  The pipeline produced zero signals in {scan_count} scans.")
            print(f"  This is a DIAGNOSTIC finding — the bot may be too strict")
            print(f"  or have bugs preventing signal generation.")
    
    # Diagnostic: why no trades?
    if len(trades) == 0:
        print(f"\n{'='*70}")
        print(f"  DIAGNOSTIC: WHY NO TRADES?")
        print(f"{'='*70}")
        # Run a few scans with detailed logging
        diag_count = 0
        for idx in range(march_start, min(march_start + 500, march_end), scan_interval):
            current_row = all_rows[idx]
            now_ts = current_row['ts']
            sess = classify_session(now_ts)
            if sess['session'] not in EXECUTABLE_SESSIONS:
                continue
            
            data_5m = slice_data(all_rows, idx, lookback=250)
            data_full = slice_data(all_rows, idx, lookback=10000)
            data_1d = aggregate_tf(data_full, 1440)
            data_15m = aggregate_tf(data_full, 15)
            
            if not data_1d or len(data_1d['closes']) < 10:
                print(f"  {current_row['dt']}: Not enough daily data ({len(data_1d['closes']) if data_1d else 0} bars)")
                continue
            
            bias_info = compute_mechanical_bias_anchor(data_1d, lookback=30)
            bias = bias_info['anchor_direction']
            
            if bias not in ('BULLISH', 'BEARISH'):
                print(f"  {current_row['dt']}: Bias={bias} (not tradeable)")
                diag_count += 1
                if diag_count > 5: break
                continue
            
            is_long = bias == 'BULLISH'
            sweep = find_recent_sweep(data_15m, is_long, window=12) if data_15m else None
            
            if not sweep:
                print(f"  {current_row['dt']}: Bias={bias}, No sweep found")
                diag_count += 1
                if diag_count > 10: break
                continue
            
            try:
                htf_sources = []
                if data_1d: htf_sources.append(('1d', data_1d))
                model_res = evaluate_all_entry_models(
                    data_5m, bias, lookback=150,
                    htf_data_sources=htf_sources,
                    setup_tf_data=data_15m
                )
                chosen = model_res.get('chosen_model') if model_res else None
                status = chosen.get('status') if chosen else 'NO_MODEL'
                model = chosen.get('model') if chosen else 'NONE'
                print(f"  {current_row['dt']}: Bias={bias}, Sweep=✅, Model={model}, Status={status}")
                
                if chosen and chosen.get('conditions'):
                    for c in chosen['conditions']:
                        ico = '✅' if c['status'] is True else ('❌' if c['status'] is False else '⏳')
                        print(f"    {ico} {c['name']}: {c.get('detail','')[:80]}")
                
                diag_count += 1
                if diag_count > 8: break
            except Exception as e:
                print(f"  {current_row['dt']}: ERROR — {str(e)[:100]}")
                diag_count += 1
                if diag_count > 8: break
    
    return trades, trade_log

if __name__ == '__main__':
    trades, log = run_backtest()
