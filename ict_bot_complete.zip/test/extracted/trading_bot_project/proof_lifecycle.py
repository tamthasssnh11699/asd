# -*- coding: utf-8 -*-
"""إثبات حي لدورة حياة الصفقة (فتح -> TP1+BE -> تماشي هيكلي -> TP2 runner).
نستورد دالة manage_active_trade الحقيقية من algo_master ونغذّيها مسار سعر
مُصطنع شمعة بشمعة، ونطبع الرصيد وخط الإيقاف بعد كل سهم. هاد الإثبات بيورّي
إنو التماشي "ك فهم" (خلف قمم/قيعان حقيقية) مو حفظ غبي."""
import sys, os, types, time

sys.path.insert(0, "/tmp/fakepkgs")  # yfinance stub
PROJ = "/home/user/test/extracted/trading_bot_project"
sys.path.insert(0, PROJ)

# نمنع BrainCore الحقيقي (اللي بيطلب OpenRouter) ونحط بديل بسيط
import brain_core
class _DM:
    def fetch_ohlcv_up_to(self, *a, **k):
        raise RuntimeError("not used in lifecycle test")
class FakeBrain:
    def __init__(self):
        self.data_manager = _DM()
brain_core.BrainCore = FakeBrain

import algo_master as am

def make5(highs, lows, closes):
    n = len(closes)
    return {"highs": list(highs), "lows": list(lows), "closes": list(closes),
            "opens": list(closes), "volumes": [1.0]*n, "symbol": "TEST", "timeframe": "5m"}

def run_lifecycle(name, is_short, path):
    """path: list of (tag, high, low, close). نبني شموع تدريجياً وندير الصفقة."""
    print("\n" + "="*78)
    print(f"  🧪 {name}  (is_short={is_short})")
    print("="*78)
    # فتح صفقة بمعطيات واضحة
    entry, sl, tp1, tp2 = (200.0, 202.0, 198.0, 194.0) if is_short else (100.0, 98.0, 104.0, 110.0)
    risk = abs(entry - sl)
    account0 = 100.0
    risk_usd = account0 * am.RISK_PCT  # 1$ (1%)
    size = risk_usd / risk
    t = {"bias": "BEARISH" if is_short else "BULLISH", "entry": entry, "sl": sl, "tp1": tp1,
         "tp2": tp2, "current_sl": sl, "be_activated": False, "tp1_hit": False, "tp2_hit": False,
         "is_short": is_short, "risk": risk, "size": size, "risk_usd": risk_usd, "model": "MODEL_B_PROOF"}
    account = account0
    print(f"  🔵 فتح {'SHORT' if is_short else 'LONG'} @ {entry:.2f} | SL {sl:.2f} | TP1 {tp1:.2f} | TP2 {tp2:.2f} "
          f"| حجم {size:.4f} | مخاطرة {risk_usd:.2f}$")
    print(f"  📊 رصيد البداية: {account:.2f}$\n")
    base_h = list(range(90, 130, 1))[:30]
    base_l = [x-0.5 for x in base_h]
    base_c = base_h[:]
    highs, lows, closes = list(base_h), list(base_l), list(base_c)
    prev_sl = sl
    for tag, h, l, c in path:
        highs.append(h); lows.append(l); closes.append(c)
        d5 = make5(highs, lows, closes)
        account, msg, closed, pnl = am.manage_active_trade("TEST", t, d5, account)
        arrow = "⬆️" if t["current_sl"] > prev_sl else ("⬇️" if t["current_sl"] < prev_sl else "➖")
        print(f"  🕯️ {tag:<22} | شمعة H {h:.2f} L {l:.2f} C {c:.2f}")
        print(f"     SL الآن: {t['current_sl']:.2f} {arrow}  | TP1_hit={t['tp1_hit']} BE={t['be_activated']} "
              f"TP2_hit={t['tp2_hit']} | رصيد {account:.2f}$ | {msg or ''}")
        prev_sl = t["current_sl"]
        if closed:
            print(f"     ✅ أُغلقت الصفقة. pnl هالشمعة {pnl:+.2f}$")
            break
    print(f"\n  💰 الرصيد النهائي: {account:.2f}$  (تغيّر {account-account0:+.2f}$)")
    return account, t

print("="*78)
print("  إثبات: فتح صفقة + تماشي خلف القمم/القيعان + TP2 runner (أوتوماتيكي 100%)")
print("="*78)

# ===== LONG: صعود -> TP1+BE -> تماشي خلف قيعان أعلى -> TP2 =====
# ندخل عند 100. نترك السعر يصعد لـ104 (TP1), ثم يقعد يسوي قيعان أعلى (تماشي),
# ثم يخبط 110 (TP2 runner).
long_path = [
    ("صعود لـ TP1", 104.5, 100.5, 104.2),     # يخبط TP1 -> 50% + BE (SL->100)
    ("قاع أعلى #1", 105.0, 100.6, 104.8),     # تماشي خلف قاع أعلى
    ("قاع أعلى #2", 106.5, 101.5, 106.0),     # تماشي أكثر
    ("قاع أعلى #3", 108.0, 102.5, 107.5),     # تماشي أكثر
    ("ضرب TP2",    110.6, 108.0, 110.2),      # يخبط TP2 runner -> إغلاق
]
accL, tL = run_lifecycle("LONG — تماشي خلف قيعان صاعدة", False, long_path)

# ===== SHORT: هبوط -> TP1+BE -> تماشي خلف قمم أدنى -> TP2 =====
short_path = [
    ("هبوط لـ TP1", 199.5, 197.5, 197.8),     # يخبط TP1 -> 50% + BE (SL->200)
    ("قمة أدنى #1", 199.4, 198.0, 198.5),     # تماشي خلف قمة أدنى
    ("قمة أدنى #2", 198.0, 197.0, 197.5),     # تماشي أكثر
    ("قمة أدنى #3", 196.5, 195.5, 196.0),     # تماشي أكثر
    ("ضرب TP2",    193.4, 193.0, 193.6),      # يخبط TP2 runner -> إغلاق
]
accS, tS = run_lifecycle("SHORT — تماشي خلف قمم هابطة", True, short_path)

# ===== LONG مع انعكاس بعد التماشي: يضرب الـ SL المماشَى بربح =====
print("\n" + "="*78)
print("  🧠 اختبار 'التماشي الذكي': بعد ما راح الـ SL يلحّق بالسعر، السعر ينعكس")
print("      ويضرب الـ SL المماشَى -> خروج بربح (مو خسارة، مو وقف أصلي)")
print("="*78)
rev_path = [
    ("صعود لـ TP1", 104.5, 100.5, 104.2),     # TP1 + BE
    ("قاع أعلى #1", 105.0, 100.6, 104.8),     # تماشي
    ("قاع أعلى #2", 106.5, 101.5, 106.0),     # تماشي أكثر
    ("انعكاس لأسفل", 106.8, 101.0, 101.2),    # يضبط التماشي SL~100.30
    ("بخبط SL المماشَى", 101.5, 100.1, 100.4), # ينزل تحت 100.30 -> خروج بربح
]
accR, tR = run_lifecycle("LONG — انعكاس يضرب SL المماشَى", False, rev_path)

print("\n" + "="*78)
print("  ✅ النتيجة: الفتح أوتوماتيكي، التماشي خلف قمم/قيعان حقيقية (ratchet لأعلى فقط),")
print("     TP1 يأخذ 50% ويأمّن BE، TP2 runner يتبع السيولة. كلو رياضيات مو AI.")
print("="*78)
