# ملخص التعديلات المطبقة — الدفعة الأولى

## المنهج
- كل تعديل مبني على مصدر رسمي من مايكل/ICT
- كل تعديل مختبر بحالات خصومية (adversarial tests)
- لم يُضف أي رقم أو عتبة أو قاعدة من عندي

## التعديلات المطبقة

### 1. ✅ `detect_ict_three_candle_swings()` — جديد
**المصدر:** ICT 2022 Mentorship Ep5 (14:29) + Month 1 Notes
**التعديل:** دالة جديدة تكتشف Swing بتعريف مايكل الرسمي (3 شموع)
**الاختبارات:** 9 حالات (basic, equal neighbor rejected, last/first candle, multiple, symmetry, determinism)

### 2. ✅ `classify_sweep_or_run()` — إصلاح
**المصدر:** ICT methodology - أحدث حدث هو الأهم
**التعديل:**
- يرجع **أحدث breach** بدل أول breach
- إغلاق مساوٍ للمستوى = `BOUNDARY_CLOSE_UNCONFIRMED` (ليس sweep مؤكد)
- يرجع كل الأحداث في `events[]` للسياق
**الاختبارات:** 2 حالات (latest wins, boundary not genuine)

### 3. ✅ FVG Lifecycle — إصلاح
**المصدر:** innercircletrader.net: "Not every FVG is tradeable"
**التعديل:** كل FVG أصبحت تحمل:
- `is_active`: False إذا filled_pct >= 100%
- `status`: UNTOUCHED / PARTIALLY_MITIGATED / FULLY_FILLED
**الاختبار:** fully filled FVG has is_active=False

### 4. ✅ OB Invalidation — إصلاح
**المصدر:** innercircletrader.net OB guide: "Without all four, it is just a candle"
**التعديل:** كل OB أصبحت تحمل:
- `invalidated`: True إذا أُغلق خلف حدها
- `invalidated_index_from_end`
- `is_active`: False إذا invalidated
- `formation_status`: "CANDIDATE_ENGULF_PAIR"
**الاختبار:** invalidated OB not active

### 5. ✅ Bearish `retracement_pct` — إصلاح
**المصدر:** innercircletrader.net "ICT Fibonacci Settings"
**التعديل:** Bearish retracement يُقاس من القاع صعوداً (ليس من القمة دائماً)
**الاختبار:** Low=0, High=100, Price=78.6, Bearish → retracement=78.6% (ليس 21.4%)

## نتائج الاختبارات
```
14 passed in 0.10s
```

## ما لم يُطبق بعد (الدفعات التالية)
- GENERIC_STRUCTURAL_FALLBACK → إيقاف
- Model B index bug → إصلاح
- FVG_FROM_DISPLACEMENT false linkage → إصلاح
- Weekly في analyze_bias → تفعيل
- 4H challenge → تفعيل
- Live state persistence → إضافة
- validate_ohlcv → إضافة
- Swap algo_master.detect_recent_sweep → توحيد
- SL/TP geometry check → إضافة
- is_executable_model LTF bypass → مراجعة
