# -*- coding: utf-8 -*-
"""
algo_master.py — الرادار الحي الخارق (Fully Autonomous ICT Bot, بدون AI)
═══════════════════════════════════════════════════════════════════════════
⚠️ تصميم صريح: هذا الملف **100% رياضيات بحتة** — لا يستدعي أي نموذج لغوي
(LLM) ولا أي طبقة AI. كل التحليل مبني على المحركات الرياضية الموثّقة
بمنهجية مايكل هدلستون (ICT): ict_math_engine + ict_entry_checklist_engine
+ authenticity_engine + ict_sessions. البوت "يقرأ الشارت" تماماً كما يقرأ
متداول ICT خبير: يشوف شو صار قبل، شو عم يصير هلق، شو تأكد، وشو منستنا
عند سعر معيّن — بشكل حتمي 100% (نفس المدخلات = نفس المخرج، صفر هلوسة).

المسار التحليلي الكامل (Top-Down متعدد الفريمات، كل دقيقة):
   WEEKLY/DAILY (الانحياز) -> 4H (المناطق المُنقّحة) -> 15m (الإعداد:
   خريطة السيولة + السحب + الـPD Arrays) -> 5m (نماذج الدخول A–F + الخطة).
كل شارت يُحلَّل لايف وحدو، مع تتبّع حالة لكل عملة من سكان لسكان (هل صار
اللي كنا منستناه؟ هل ظهرت فرصة جديدة؟)، وبوابة Kill Zone صارمة قبل أي دخول.
"""

import sys, time, datetime, os, json, argparse
sys.path.insert(0, ".")
from data_manager import DataManager
from ict_math_engine import (
    compute_mechanical_bias_anchor, classify_sweep_or_run,
    detect_fair_value_gaps, detect_order_blocks, detect_mss,
    compute_premium_discount, find_structural_sl_anchors,
    detect_equal_highs_lows, find_tp_targets,
    compute_structural_break_quality_score, classify_break_reversal_authenticity,
    classify_htf_structural_challenge,
)
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session, compute_overnight_range, session_prose
import pytz
import numpy as np
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass
from telegram_notify import TelegramNotifier

dm = DataManager()
ae = AuthenticityEngine()
ny_tz = pytz.timezone("America/New_York")

WATCHING_SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01
EXECUTABLE_SESSIONS = {"LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"}
SCAN_INTERVAL_SEC = 60

# حالة دائمة لكل عملة عبر السكانات (تتبّع "شو كنا منستناه")
STATE = {}

# ══════════════════════════════════════════════════════════════════
#  خيارات التشغيل + التيليغرام + سجل الصفقات
# ══════════════════════════════════════════════════════════════════
# قائمة افتراضية لتحليل السوق كامل (--market) - عدّلها كيف بدك
TOP_20_COINS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT",
                "DOGE/USDT", "ADA/USDT", "AVAX/USDT", "LINK/USDT", "DOT/USDT",
                "MATIC/USDT", "LTC/USDT", "TRX/USDT", "ATOM/USDT", "NEAR/USDT",
                "UNI/USDT", "ICP/USDT", "APT/USDT", "AR/USDT", "FIL/USDT"]

NOTIFIER = TelegramNotifier()
JOURNAL_PATH = os.path.join("data", "trade_journal_live.jsonl")


def is_executable_model(chosen):
    """موديل جاهز للتنفيذ الورقي: عندو خطة كاملة، ما في شرط فاشل،
    وكل شرط PENDING هو فقط "تأكيد سياقي" (يشتغل على فريم التنفيذ نفسو
    فعلياً، فهوي معلّق دايماً بالتعريف) أو توقيت الجلسة - البوابة الحقيقية
    بتمارسها algo_master نفسها (EXECUTABLE_SESSIONS + بوابة الشروط الحقيقية
    المفقودة زمنياً). هاد الإصلاح (يوليو 2026) بيخلّي البوت يتكيّف مع كل
    موديلات مايكل الستّة (A/C/E/F صاروا ينفّذو بعد ما كانو محجوبين بشرط
    LTF_CONFIRMATION المعلّق دايماً)."""
    # شروط PENDING هادا معناها "لسا منستنا تشكّل حدث حقيقي" (مثلاً
    # الاندفاع بعد السحب بموديل B، أو التلاعب بالتجميع بموديل D) - هاي
    # لازم تبقى مانعة التنفيذ. أما شروط التأكيد التالية فهي معلّقة دايماً
    # بالتعريف (لأنو الموديل شغّال أصلاً على فريم الدخول)، فما منعملها
    # كمانع - هاد بيطابق منهجية مايكل (ندخل على الـPD Array بعد
    # السحب+الاندفاع+الهيكل، من دون ننتظر بوابة تأكيد ثانية معلّقة).
    _NON_BLOCKING_PENDING = {
        "ACTIVE_KILL_ZONE_TIMING",         # توقيت الجلسة (بتعالج بـEXECUTABLE_SESSIONS)
        "LTF_CONFIRMATION_CHOCH_OR_BOS",   # تأكيد LTF (معلّق دايماً - الموديل شغّال ع 5m)
        "LTF_BOS_CONFIRMS",                # تأكيد BOS إضافي (موديل F)
        "HTF_CONTEXT_AT_PD_ARRAY",         # سياق HTF (موديل E - تأكيد نوعي لا بوابة)
    }
    if not chosen or not chosen.get("plan"):
        return False
    # ⚠️ FIX: OBSERVATION_ONLY و DISQUALIFIED لا يُنفَّذان
    if chosen.get("status") in ("OBSERVATION_ONLY", "DISQUALIFIED", "NO_CANDIDATE"):
        return False
    plan = chosen["plan"]
    if not (plan.get("entry") and plan.get("stop_loss") and plan.get("tp")):
        return False
    for c in chosen.get("conditions", []):
        if c["status"] is False:
            return False
        if c["status"] == "PENDING" and c["name"] not in _NON_BLOCKING_PENDING:
            return False
    return True


def log_trade_event(ev):
    """يسجّل كل حدث صفقة بـJSONL (مع تاريخ ووقت وأسعار) - لمتابعة المصير."""
    try:
        os.makedirs(os.path.dirname(JOURNAL_PATH), exist_ok=True)
        with open(JOURNAL_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _now_ny_str():
    return datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz).strftime("%Y-%m-%d %H:%M NY")


def tg_open(symbol, t):
    return NOTIFIER.open_msg(symbol, t)


def tg_close(symbol, t, exit_price, pnl, reason, balance):
    return NOTIFIER.close_msg(symbol, t, exit_price, pnl, reason, balance)


def tg_balance(balance, open_count):
    return NOTIFIER.balance_msg(balance, open_count, time.strftime("%Y-%m-%d"))


# ══════════════════════════════════════════════════════════════════
#  أدوات مساعدة
# ══════════════════════════════════════════════════════════════════
def _fmt(p):
    try:
        p = float(p)
    except Exception:
        return str(p)
    if p == 0:
        return "0.00"
    a = abs(p)
    # دقّة ديناميكية: عملات رخيصة (مثل XRP ~1.10) بتحتاج 4-6 خانات عشان
    # نشوف الأرقام الحقيقية ونأكد التحليل — مو تقريب أعمى بخانتين.
    if a >= 1000:
        return f"{p:,.2f}"
    if a >= 10:
        return f"{p:,.3f}"
    if a >= 1:
        return f"{p:.4f}"
    if a >= 0.01:
        return f"{p:.5f}"
    return f"{p:.6f}"


def _safe(data, key):
    """يضمن وجود مفتاح قائمة بالبيانات (بعض المحركات تتطلب volumes)."""
    if data is None:
        return None
    if key not in data or not isinstance(data.get(key), list):
        n = len(data.get("closes", []))
        data[key] = [0.0] * n
    return data


def _validate_ohlcv(data):
    """يفحص سلامة بيانات OHLCV قبل أي تحليل.
    هندسة برمجية — ليست قاعدة ICT.
    Returns (ok: bool, reason: str)."""
    if not data:
        return False, "NO_DATA"
    keys = ("opens", "highs", "lows", "closes")
    lengths = [len(data.get(k, [])) for k in keys]
    if not all(l > 0 for l in lengths):
        return False, "EMPTY_ARRAYS"
    if len(set(lengths)) > 1:
        return False, f"LENGTH_MISMATCH: {dict(zip(keys, lengths))}"
    n = lengths[0]
    ts = data.get("timestamps", [])
    if ts and len(ts) != n:
        return False, f"TIMESTAMPS_LENGTH_MISMATCH: {len(ts)} vs {n}"
    # Check for NaN/Infinity
    import math
    for k in keys:
        arr = data[k]
        for i, v in enumerate(arr):
            if not math.isfinite(v):
                return False, f"NON_FINITE_VALUE: {k}[{i}]={v}"
    # Check OHLC consistency: High >= max(Open,Close), Low <= min(Open,Close)
    for i in range(n):
        h, l = data["highs"][i], data["lows"][i]
        o, c = data["opens"][i], data["closes"][i]
        if h < max(o, c) or l > min(o, c):
            return False, f"IMPOSSIBLE_OHLC: bar {i} H={h} L={l} O={o} C={c}"
        if h < l:
            return False, f"HIGH_BELOW_LOW: bar {i} H={h} L={l}"
    # Check timestamps not duplicated and sorted
    if ts and len(ts) >= 2:
        for i in range(1, len(ts)):
            if ts[i] <= ts[i-1]:
                return False, f"TIMESTAMPS_NOT_SORTED: [{i-1}]={ts[i-1]} [{i}]={ts[i]}"
    return True, "OK"


def _note_hurdle(plan, bias, pd, lines):
    """مايكل (source 3): أي منطقة سعر (FVG/OB) بجهة معاكسة لاتجاه الصفقة
    وبتقع بين الدخول والهدف = عقبة سيولة (مقاومة محتملة) السعر لازم
    يستردّا/يتجاوزها قبل يوصل الهدف — "FVG بيعكس الاتجاه = فخ/مقاومة،
    مو فرصة". البوت بيبلّغ فيها متل مايكل مو بيتجاهلها."""
    if not plan:
        return
    entry = float(plan.get("entry") or 0); tp1 = float(plan.get("tp") or 0)
    if entry == 0 or tp1 == 0:
        return
    is_long = bias == "BULLISH"
    lo, hi = (entry, tp1) if is_long else (tp1, entry)
    hurdles = []
    for f in (pd.get("fvgs") or []):
        fdir = f.get("dir")
        if is_long and fdir == "BEAR" and lo <= f["ce"] <= hi:
            hurdles.append(f"FVG هابط {_fmt(f['bottom'])}–{_fmt(f['top'])}")
        if (not is_long) and fdir == "BULL" and lo <= f["ce"] <= hi:
            hurdles.append(f"FVG صاعد {_fmt(f['bottom'])}–{_fmt(f['top'])}")
    for ob in (pd.get("obs") or []):
        obdir = ob.get("dir")
        mid = (ob["bottom"] + ob["top"]) / 2
        if is_long and obdir == "BEAR" and lo <= mid <= hi:
            hurdles.append(f"OB هابط {_fmt(ob['bottom'])}–{_fmt(ob['top'])}")
        if (not is_long) and obdir == "BULL" and lo <= mid <= hi:
            hurdles.append(f"OB صاعد {_fmt(ob['bottom'])}–{_fmt(ob['top'])}")
    if hurdles:
        lines.append(f"   🧠 فهم: بين الدخول و TP1 في عقبة سيولة معاكسة → " + ", ".join(hurdles)
                     + " — السعر لازم يستردّا/يتجاوزها قبل يوصل الهدف (مقاومة محتملة بجهة الصفقة).")


def fetch_all_tf(symbol, now_ts):
    """يجلب كل الفريمات المطلوبة للتحليل الكامل؛ يرجع dict tf->data (يتجاهل الفاشل)."""
    out = {}
    for tf in ["1w", "1d", "4h", "15m", "5m"]:
        try:
            d = dm.fetch_ohlcv_up_to(symbol, tf, now_ts, limit=250)
        except Exception:
            d = None
        if d and d.get("closes"):
            _safe(d, "volumes")
            ok, reason = _validate_ohlcv(d)
            if ok:
                out[tf] = d
            else:
                print(f"⚠️ {symbol} {tf}: data rejected — {reason}")
    return out


# ══════════════════════════════════════════════════════════════════
#  طبقات التحليل (كل طبقة = عين مايكل على فريم معيّن)
# ══════════════════════════════════════════════════════════════════
def analyze_bias(d1d, d4h, d1w):
    """الانحياز العام Top-Down: Weekly → Daily → 4H.
    المصدر: 2022 Mentorship Ep2:
    "Looking for a likely move higher or lower based on the weekly candle.
     That sets your initial bias for the week."
    "The majority of finding the draw on liquidity will be found in the
     daily timeframe analysis."
    """
    res = {"dir_1d": "UNKNOWN", "str_1d": "", "dir_4h": "UNKNOWN",
           "dir_1w": "UNKNOWN", "seq_1d": "", "last_break_1d": None,
           "narrative": "", "context_warnings": []}

    # ⚠️ FIX: Weekly يدخل في السياق (كان يُجلب ويُتجاهل)
    if d1w and d1w.get("closes"):
        aw = compute_mechanical_bias_anchor(d1w, lookback=40)
        res["dir_1w"] = aw.get("anchor_direction", "UNKNOWN")

    if d1d and d1d.get("closes"):
        a = compute_mechanical_bias_anchor(d1d, lookback=80)
        res["dir_1d"] = a.get("anchor_direction", "UNKNOWN")
        res["str_1d"] = a.get("strength", "")
        res["seq_1d"] = a.get("sequence_direction") or ""
        res["last_break_1d"] = a.get("last_confirmed_break_direction")
        res["narrative"] = a.get("narrative", "")

    if d4h and d4h.get("closes"):
        a4 = compute_mechanical_bias_anchor(d4h, lookback=80)
        res["dir_4h"] = a4.get("anchor_direction", "UNKNOWN")

    # ⚠️ FIX: Weekly/Daily conflict → context_warning (ليس HOLD اخترعناه)
    # لم أجد مصدراً رسمياً يقول "إذا Weekly ضد Daily = لا تتداول"
    # لذلك أضيفها كتحذير سياقي فقط، ليس بوابة منع
    if (res["dir_1w"] in ("BULLISH", "BEARISH") and
        res["dir_1d"] in ("BULLISH", "BEARISH") and
        res["dir_1w"] != res["dir_1d"]):
        res["context_warnings"].append("WEEKLY_DAILY_CONFLICT")

    # تحدّي الـ4H لانحياز الـ1D
    if d4h and d4h.get("closes") and res["dir_1d"] in ("BULLISH", "BEARISH"):
        ch = classify_htf_structural_challenge(d4h, res["dir_1d"], lookback=100)
        res["htf_challenge"] = ch.get("classification")
        # ⚠️ FIX: 4H reversal = تحذير سياقي (ليس بوابة HOLD اخترعناه)
        if ch.get("classification") == "REAL_REVERSAL_CONFIRMED":
            res["context_warnings"].append("4H_REVERSAL_EVIDENCE")

    return res


def analyze_liquidity_map(data, label):
    """خريطة السيولة (ICT الصحيح): BSL = قمم فوق السعر (هدف البيع/الشورت)،
    SSL = قيعان تحت السعر (هدف الشراء/اللونغ). بنرتّب حسب الجهة الحقيقية
    مقارنة بسعر هلق — ما بنطبع مستويات عالجهة الغلط كبّت السعر ع حافّة."""
    if not data or not data.get("closes"):
        return {"bsl": [], "ssl": [], "raw_count": 0}
    sig = ae.detect_significant_swings(data, swing_window=3, lookback_candles=150)
    cur = float(data["closes"][-1])
    bsl, ssl = [], []
    for s in sig.get("all_highs_tiered", []):
        if s["price"] > cur:   # BSL لازم فوق السعر
            bsl.append({"side": "BSL", "price": s["price"], "tier": s["tier"],
                        "dist": s["price"] - cur, "idx": s["index_from_end"]})
    for s in sig.get("all_lows_tiered", []):
        if s["price"] < cur:   # SSL لازم تحت السعر
            ssl.append({"side": "SSL", "price": s["price"], "tier": s["tier"],
                        "dist": cur - s["price"], "idx": s["index_from_end"]})
    bsl.sort(key=lambda r: r["dist"])
    ssl.sort(key=lambda r: r["dist"])
    return {"bsl": bsl[:3], "ssl": ssl[:3], "raw_count": len(bsl) + len(ssl)}


def detect_recent_sweep(data, bias, label, window=12):
    """يكشف سحب سيولة حقيقي صار مؤخّراً.
    ⚠️ FIX: توحيد — يستدعي find_recent_sweep الموحّد بدل تكرار المنطق.
    المصدر: مبدأ هندسي (مصدر حقيقة واحد) — ليس قاعدة ICT."""
    from ict_math_engine import find_recent_sweep
    if not data or not data.get("closes"):
        return None
    is_long = (bias == "BULLISH")
    return find_recent_sweep(data, is_long, window=window)


def analyze_pd_arrays(data, label):
    """المناطق السعرية (PD Arrays): FVG + Order Blocks مع تأكيد الاندفاع."""
    if not data or not data.get("closes"):
        return {"fvgs": [], "obs": []}
    fvgs = detect_fair_value_gaps(data, lookback=len(data["closes"]), require_displacement=True)
    obs = detect_order_blocks(data, lookback=len(data["closes"]))
    out_fvg = []
    for f in fvgs["bullish_fvgs"][-3:] + fvgs["bearish_fvgs"][-3:]:
        out_fvg.append({"dir": "BULL" if f in fvgs["bullish_fvgs"] else "BEAR",
                        "top": f["top"], "bottom": f["bottom"], "ce": f["ce"],
                        "filled": f["filled_pct"], "idx": f["index_from_end"]})
    out_ob = []
    for ob in obs["bullish_obs"][-3:] + obs["bearish_obs"][-3:]:
        out_ob.append({"dir": "BULL" if ob in obs["bullish_obs"] else "BEAR",
                       "top": ob["top"], "bottom": ob["bottom"],
                       "fvg": ob["fvg_nearby"], "idx": ob["index_from_end"]})
    return {"fvgs": out_fvg, "obs": out_ob}


def analyze_structure(data, label):
    """آخر كسر هيكلي + جودتو (MSS/CHoCH) كبنية تأكيد."""
    if not data or not data.get("closes"):
        return None
    mss = detect_mss(data)
    breaks = mss.get("breaks_found", [])
    if not breaks:
        return None
    b = breaks[-1]
    q = compute_structural_break_quality_score(data, b)
    rev = classify_break_reversal_authenticity(b, tier=None)
    return {"direction": b["direction"], "level": b["broken_level"],
            "displacement": b["displacement_confirmed"],
            "quality": q.get("quality_rating"), "score": q.get("total_score"),
            "reversal": rev.get("verdict"), "idx": b["break_candle_index_from_end"]}


def run_entry_models(d5m, bias, htf_sources, setup_tf_data=None):
    """نماذج الدخول A–F على فريم التنفيذ، مع مصادر أعلى للـTP2 (Draw on
    Liquidity) وفريم الإعداد (15m) لاكتشاف السحب Top-Down متل مايكل."""
    if not d5m or not d5m.get("closes"):
        return None
    if bias not in ("BULLISH", "BEARISH"):
        return None
    try:
        return evaluate_all_entry_models(d5m, bias, lookback=150,
                                         htf_data_sources=htf_sources,
                                         setup_tf_data=setup_tf_data)
    except Exception as e:
        return {"error": str(e)}


# ══════════════════════════════════════════════════════════════════
#  بناء التقرير بأسلوب مايكل (شو صار / شو عم يصير / شو تأكد / شو منستنا)
# ══════════════════════════════════════════════════════════════════
def build_report(symbol, now_ts, tf):
    d1d, d4h, d15, d5 = tf.get("1d"), tf.get("4h"), tf.get("15m"), tf.get("5m")
    cur15 = float(d15["closes"][-1]) if d15 else 0.0
    cur5 = float(d5["closes"][-1]) if d5 else 0.0
    bias = "UNKNOWN"
    lines = []
    lines.append(f"🪙 {symbol} | السعر اللحظي 15m: {_fmt(cur15)} | 5m: {_fmt(cur5)}")

    # —— التوقيت / الجلسة ——
    sess = classify_session(now_ts)
    sess_icon = "✅" if sess["is_executable_window"] else "⛔"
    lines.append(f"⏱️  التوقيت (NY): {sess['ny_time']} | الجلسة: {sess['session']} "
                 f"{sess_icon} {'قابلة للتنفيذ' if sess['is_executable_window'] else 'ميتة - مراقبة فقط'}"
                 + (f" | 🌟 Silver Bullet: {sess['silver_bullet_name']}" if sess["in_silver_bullet"] else ""))

    # —— الانحياز ——
    bias_info = analyze_bias(d1d, d4h, tf.get("1w"))
    bias = bias_info["dir_1d"]
    bdir = "🟢 صاعد BULLISH" if bias == "BULLISH" else ("🔴 هابط BEARISH" if bias == "BEARISH" else "⚪ غير واضح UNCLEAR")
    lines.append(f"📅 الانحياز (Daily): {bdir} [{bias_info['str_1d']}] | تسلسل: {bias_info['seq_1d'] or '—'}"
                 + (f" | 4H: {bias_info['dir_4h']}" if bias_info['dir_4h'] != 'UNKNOWN' else "")
                 + (f" | تحدّي 4H للانحياز: {bias_info.get('htf_challenge','')}" if bias_info.get('htf_challenge') else ""))

    if bias not in ("BULLISH", "BEARISH"):
        lines.append("   ↳ الانحياز غير واضح -> HOLD (ما منحلل دخول بلا انحياز Clear).")
        return {"lines": lines, "bias": bias, "sweep": None, "model": None, "plan": None,
                "fvg_count": 0, "ob_count": 0, "sweep_side": None, "sweep_level": None}

    # —— خريطة السيولة (15m) ——
    lm = analyze_liquidity_map(d15, "15m")
    if lm["bsl"] or lm["ssl"]:
        lq = "🌊 خريطة السيولة (15m): "
        if lm["bsl"]:
            lq += "BSL(فوق) " + ", ".join(f"{_fmt(r['price'])}[{r['tier']}](-{_fmt(r['dist'])})" for r in lm["bsl"])
        if lm["ssl"]:
            lq += " | SSL(تحت) " + ", ".join(f"{_fmt(r['price'])}[{r['tier']}](-{_fmt(r['dist'])})" for r in lm["ssl"])
        lines.append(lq)

    # —— السحب (Sweep) على 15m (فريم الإعداد) ——
    sweep = detect_recent_sweep(d15, bias, "15m")
    if sweep:
        lines.append(f"💥 السحب (Sweep) على 15m: ✅ صار سحب حقيقي {sweep['side']} عند {_fmt(sweep['level'])} "
                     f"(فتيل لحد {_fmt(sweep['wick'])}) — فتيل اخترق ورجع الإغلاق للداخل = سحب سيولة حقيقي.")
    else:
        # نحدّد شو منستنا بدقّة: للهابط منستنا سحب BSL فوق السعر،
        # وللصاعد منستنا سحب SSL تحت السعر — مو أي مستوى من الجهة الغلط.
        cur = float(d15["closes"][-1])
        sig = ae.detect_significant_swings(d15, swing_window=3, lookback_candles=150)
        if bias == "BULLISH":
            cands = [s for s in sig.get("all_lows_tiered", []) if s["price"] < cur]
            side = "SSL"
        else:
            cands = [s for s in sig.get("all_highs_tiered", []) if s["price"] > cur]
            side = "BSL"
        cands.sort(key=lambda s: abs(s["price"] - cur))
        tgt = cands[0] if cands else None
        if tgt:
            d = abs(tgt["price"] - cur)
            lines.append(f"💥 السحب: ⏳ لسا ما صار — منستنا السعر يسحب {side} عند {_fmt(tgt['price'])} "
                         f"(بعدنا {_fmt(d)}) قبل أي دخول.")
        else:
            lines.append(f"💥 السحب: ⏳ لسا ما صار — ما فيو {side} مؤكّد بجهة السعر الصحيحة بعد "
                         f"(السعر لسا ما حطّ مستوى سيولة مناسب للسحب).")

    # —— مناطق السعر PD Arrays (15m) ——
    pd = analyze_pd_arrays(d15, "15m")
    if pd["fvgs"]:
        parts = []
        for f in pd["fvgs"]:
            d = "صاعد" if f["dir"] == "BULL" else "هابط"
            parts.append(f"FVG {d}: {_fmt(f['bottom'])}–{_fmt(f['top'])} (CE {_fmt(f['ce'])}, ملء {f['filled']}%)")
        lines.append("🟥🟩 مناطق السعر (15m): " + " | ".join(parts))
    if pd["obs"]:
        parts = []
        for ob in pd["obs"]:
            d = "صاعد" if ob["dir"] == "BULL" else "هابط"
            parts.append(f"OB {d}: {_fmt(ob['bottom'])}–{_fmt(ob['top'])}" + (" +FVG" if ob["fvg"] else ""))
        lines.append("   🧱 Order Blocks: " + " | ".join(parts))

    # —— الهيكل (MSS) ——
    st = analyze_structure(d15, "15m")
    if st:
        lines.append(f"🧱 الهيكل (15m): آخر كسر {st['direction']} عند {_fmt(st['level'])} "
                     f"{'باندفاع ✅' if st['displacement'] else 'بلا اندفاع ⚠️'} | جودة {st['quality']} ({st['score']}/25) "
                     f"| أصالة الانعكاس: {st['reversal']}")

    # —— نماذج الدخول A–F (5m) ——
    htf_sources = [(tf_ := k, tf[k]) for k in ("1d", "4h") if tf.get(k)]
    model_res = run_entry_models(d5, bias, htf_sources, setup_tf_data=tf.get("15m"))
    chosen = None
    if model_res and not model_res.get("error"):
        chosen = model_res.get("chosen_model")
        status = model_res.get("final_status")
        lines.append(f"🎯 نماذج الدخول (5m): الحالة الكلية = {status}")
        if chosen:
            lines.append(f"   ▶ الموديل المعتمد: {chosen['model']} | وضع: {chosen['status']}")
            for c in chosen.get("conditions", []):
                ico = "✅" if c["status"] is True else ("❌" if c["status"] is False else "⏳")
                lines.append(f"      {ico} {c['name']}: {c['detail']}")
            plan = chosen.get("plan")
            if plan:
                lines.append(f"   📋 الخطة: دخول {_fmt(plan['entry'])} | SL {_fmt(plan['stop_loss'])} "
                             f"| TP1 {_fmt(plan['tp'])} (R:R {plan.get('rr')})")
                tp2 = plan.get("tp2")
                if tp2:
                    if tp2.get("mode") == "TARGET":
                        lines.append(f"      🎯 TP2 (Draw on Liquidity / runner): {_fmt(tp2['price'])} "
                                     f"[{tp2.get('kind')}] — {tp2.get('confluence_count')} تأكيدات")
                else:
                    lines.append(f"      🎯 TP2: OPEN_TRAILING (ما فيو مستوى سيولة بعيد كافٍ — بنتابع بالتماشي)")
            # ── فهم مايكل: PD array بجهة معاكسة بين الدخول والهدف = عقبة ──
            _note_hurdle(plan, bias, pd, lines)
        else:
            lines.append(f"   ↳ لا موديل مؤهّل هلق. سبب: {model_res.get('hold_reason_detail','')[:200]}")
    elif model_res and model_res.get("error"):
        lines.append(f"   ⚠️ خطأ بحساب النماذج: {model_res['error']}")

    fvg_count = len(pd["fvgs"])
    ob_count = len(pd["obs"])
    return {"lines": lines, "bias": bias, "sweep": sweep,
            "model": chosen, "plan": (chosen or {}).get("plan"),
            "fvg_count": fvg_count, "ob_count": ob_count,
            "sweep_side": sweep["side"] if sweep else None,
            "sweep_level": sweep["level"] if sweep else None,
            "model_status": (chosen or {}).get("status"),
            "model_name": (chosen or {}).get("model")}


# ══════════════════════════════════════════════════════════════════
#  تتبّع الحالة عبر السكانات (هل صار اللي كنا منستناه؟ فرصة جديدة؟)
# ══════════════════════════════════════════════════════════════════
def track_state(symbol, rep):
    prev = STATE.get(symbol, {})
    notes = []
    if prev:
        if rep.get("sweep_level") and prev.get("sweep_level") != rep["sweep_level"]:
            notes.append(f"✅ صار اللي كنا منستناه! سحب {rep['sweep_side']} عند {_fmt(rep['sweep_level'])}.")
        if rep.get("model_status") != prev.get("model_status"):
            ms = rep.get("model_status")
            if ms == "READY":
                notes.append("🚀 الموديل اكتمل وصار READY — جاهز للدخول بجلسة تنفيذ!")
            elif ms == "PENDING_SETUP":
                notes.append("🟡 الموديل تقدّم لـ PENDING_SETUP (ينتظر تشكّل الشروط الباقية).")
            elif ms == "DISQUALIFIED":
                notes.append("⛔ الموديل فقد الشروط المطلوبة (DISQUALIFIED).")
        if rep.get("fvg_count", 0) > prev.get("fvg_count", 0):
            notes.append("🔎 FVG جديد ظهر على 15m — منطقة سعر إضافية بالانتظار.")
        if rep.get("bias") != prev.get("bias") and rep.get("bias") in ("BULLISH", "BEARISH"):
            notes.append(f"🔄 الانحياز تبدّل لـ {rep['bias']}.")
        if not notes:
            notes.append("🔄 لا جديد جوهري — بنراقب بنفس السياق.")
    else:
        notes.append("🆕 أول سكان لهالعملة — تم تأسيس خط الأساس التحليلي.")
    STATE[symbol] = {
        "bias": rep.get("bias"), "sweep_side": rep.get("sweep_side"),
        "sweep_level": rep.get("sweep_level"), "model_status": rep.get("model_status"),
        "model_name": rep.get("model_name"), "fvg_count": rep.get("fvg_count"),
        "ob_count": rep.get("ob_count"),
    }
    return notes


# ══════════════════════════════════════════════════════════════════
#  إدارة الصفقة المفتوحة: خروج + تماشي هيكلي خلف القمم/القيعان
# ══════════════════════════════════════════════════════════════════
def manage_active_trade(symbol, t, d5, account):
    """يتابع الصفقة شمعة بشمعة: TP1 (50% + BE)، TP2 runner، وتماشي هيكلي
    خلف آخر قمة/قاع مؤكّد (swing_window=2) - متل مايكل بالضبط.
    يرجع (account, msg, closed, pnl): closed=True يعني الصفقة انغلقت هالشمعة
    (فما بيعاد حساب الخسارة كل سكان). pnl = تغيّر الرصيد بسبب هالصفقة بس."""
    if not d5 or not d5.get("closes"):
        return account, None, False, 0.0
    acc0 = account
    h = d5["highs"][-1]; l = d5["lows"][-1]
    is_short = t["is_short"]; entry = t["entry"]; sl = t["sl"]
    tp1 = t["tp1"]; size = t["size"]; risk_usd = t["risk_usd"]
    cur_sl = t["current_sl"]
    msg = None; closed = False

    if is_short:
        if h >= cur_sl:
            if cur_sl == sl:
                account -= risk_usd; msg = f"❌ SL لوس -{risk_usd:.2f}$"
            elif cur_sl == entry:
                msg = "🛡️ BE - خروج بصفر"
            else:
                profit = (entry - cur_sl) * size * (0.5 if t["tp1_hit"] else 1.0)
                account += profit; msg = f"🧠 خروج بأرباح +{profit:.2f}$ (تماشي)"
            closed = True
        elif l <= tp1 and not t["tp1_hit"]:
            account += abs(tp1 - entry) * size * 0.5
            t["tp1_hit"] = True; t["be_activated"] = True; t["current_sl"] = entry
            msg = "🎯 TP1 (50%) +BE"
        elif t.get("tp2") and l <= t["tp2"] and t["tp1_hit"] and not t.get("tp2_hit"):
            account += abs(t["tp2"] - entry) * size * 0.5
            t["tp2_hit"] = True; closed = True; msg = f"🏆 TP2 runner +{abs(t['tp2']-entry)*size*0.5:.2f}$"
        elif l <= (entry - 1.5 * t["risk"]) and not t["be_activated"]:
            t["be_activated"] = True; t["current_sl"] = entry; msg = "🛡️ تأمين 1.5R->BE"
        else:
            highs = np.asarray(d5["highs"], dtype=float)
            n = len(highs); sw = 2
            new_hl = None
            for i in range(n - 4, max(sw, n - 30), -1):
                if i - sw < 0 or i + sw >= n:
                    continue
                if highs[i] == max(highs[i - sw:i + sw + 1]):
                    new_hl = highs[i]; break
            if new_hl is not None and new_hl < cur_sl and t["be_activated"]:
                t["current_sl"] = new_hl + t["risk"] * 0.1
                msg = msg or f"🧠 تماشي خلف قمة هابطة {_fmt(t['current_sl'])}"
    else:
        if l <= cur_sl:
            if cur_sl == sl:
                account -= risk_usd; msg = f"❌ SL لوس -{risk_usd:.2f}$"
            elif cur_sl == entry:
                msg = "🛡️ BE - خروج بصفر"
            else:
                profit = (cur_sl - entry) * size * (0.5 if t["tp1_hit"] else 1.0)
                account += profit; msg = f"🧠 خروج بأرباح +{profit:.2f}$ (تماشي)"
            closed = True
        elif h >= tp1 and not t["tp1_hit"]:
            account += abs(tp1 - entry) * size * 0.5
            t["tp1_hit"] = True; t["be_activated"] = True; t["current_sl"] = entry
            msg = "🎯 TP1 (50%) +BE"
        elif t.get("tp2") and h >= t["tp2"] and t["tp1_hit"] and not t.get("tp2_hit"):
            account += abs(t["tp2"] - entry) * size * 0.5
            t["tp2_hit"] = True; closed = True; msg = f"🏆 TP2 runner +{abs(t['tp2']-entry)*size*0.5:.2f}$"
        elif h >= (entry + 1.5 * t["risk"]) and not t["be_activated"]:
            t["be_activated"] = True; t["current_sl"] = entry; msg = "🛡️ تأمين 1.5R->BE"
        else:
            lows = np.asarray(d5["lows"], dtype=float)
            n = len(lows); sw = 2
            new_ll = None
            for i in range(n - 4, max(sw, n - 30), -1):
                if i - sw < 0 or i + sw >= n:
                    continue
                if lows[i] == min(lows[i - sw:i + sw + 1]):
                    new_ll = lows[i]; break
            if new_ll is not None and new_ll > cur_sl and t["be_activated"]:
                t["current_sl"] = new_ll - t["risk"] * 0.1
                msg = msg or f"🧠 تماشي خلف قاع صاعد {_fmt(t['current_sl'])}"
    pnl = account - acc0
    return account, msg, closed, pnl


# ══════════════════════════════════════════════════════════════════
#  الدورة الحية الرئيسية
# ══════════════════════════════════════════════════════════════════
def print_banner(msg):
    print(f"\n{'='*85}\n  {msg}\n{'='*85}")


def run_analyze(symbol):
    """تحليل عملة وحدة فوراً (شغل مثل مايكل، بدون تنفيذ)."""
    symbol = symbol.upper()
    if "/" not in symbol:
        symbol = f"{symbol}/USDT"
    now_ts = int(time.time() * 1000)
    tf = fetch_all_tf(symbol, now_ts)
    if not tf.get("15m") or not tf.get("5m"):
        print(f"⚠️ تعذّر جلب بيانات {symbol}")
        return
    rep = build_report(symbol, now_ts, tf)
    for ln in rep["lines"]:
        print(ln)
    ch = rep.get("model")
    if ch:
        print("\n--- تفصيل شروط الموديل ---")
        for c in ch.get("conditions", []):
            ico = "✅" if c["status"] is True else ("❌" if c["status"] is False else "⏳")
            print(f"   {ico} {c['name']}: {c['detail']}")


def run_market(coins):
    """تحليل السوق كامل وطباعة ملخّص مرتّب حسب الجاهزية."""
    print_banner("📊 تحليل السوق الكامل")
    now_ts = int(time.time() * 1000)
    rows = []
    for sym in coins:
        tf = fetch_all_tf(sym, now_ts)
        if not tf.get("15m") or not tf.get("5m"):
            print(f"⚠️ {sym}: بلا بيانات")
            continue
        rep = build_report(sym, now_ts, tf)
        st = (rep.get("model") or {}).get("status") or "—"
        plan = rep.get("plan") or {}
        rows.append((sym, rep["bias"], st, plan))
    order = {"READY": 0, "PENDING_SETUP": 1, "NO_MODEL_QUALIFIES": 2, "—": 3}
    rows.sort(key=lambda r: order.get(r[2], 9))
    for sym, bias, st, plan in rows:
        line = f"🪙 {sym:<10} | {bias:<7} | {st:<14}"
        if plan:
            line += f" | دخول {plan.get('entry'):.2f} SL {plan.get('stop_loss'):.2f} TP1 {plan.get('tp'):.2f}"
        print(line)


def run_live_autonomous(coins=None, interval=SCAN_INTERVAL_SEC, use_tg=True, max_iter=None):
    coins = coins or WATCHING_SYMBOLS
    notifier = NOTIFIER if (use_tg and NOTIFIER.enabled) else None
    account = ACCOUNT_BALANCE
    active_trades = {}
    iter_count = 0
    print_banner("🤖 ICT Algo Master — الرادار الحي الخارق (100% رياضيات، بدون AI)")
    print(f"💼 الرصيد: {account:.2f}$ | المخاطرة: {RISK_PCT*100:.0f}% | العملات: {', '.join(coins)}")
    print(f"📲 التيليغرام: {'✅ مفعّل' if notifier else '⛔ معطّل (ضع TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID بملف .env)'}")
    if notifier:
        notifier.send(NOTIFIER.startup_msg(account, coins))

    while True:
        try:
            now_ts = int(time.time() * 1000)
            now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)
            curr_session = classify_session(now_ts).get("session", "UNKNOWN")
            iter_count += 1
            print_banner(f"📡 رادار المسح والتتبع اللحظي #{iter_count} | نيويورك: {now_ny.strftime('%H:%M:%S')} | الجلسة: {curr_session}")
            print(f"💰 الرصيد اللحظي: {account:.2f}$")
            print("-" * 85)

            # 1) إدارة الصفقات المفتوحة (خروج + تماشي)
            for symbol in list(active_trades.keys()):
                t = active_trades[symbol]
                d5 = dm.fetch_ohlcv_up_to(symbol, "5m", now_ts, limit=30)
                account, msg, closed, pnl = manage_active_trade(symbol, t, d5, account)
                if msg:
                    print(f"👁️ {symbol}: {msg} | الرصيد: {account:.2f}$")
                    if notifier:
                        notifier.send(f"👁️ <b>{symbol}</b>: {msg}\n💰 الرصيد: {account:.2f}$")
                if closed:
                    if t.get("tp2_hit"):
                        reason = "TP2 (runner)"
                    elif t["current_sl"] == t["entry"]:
                        reason = "BE (خروج بصفر)"
                    else:
                        reason = "SL (خسارة)"
                    exit_price = t.get("tp2") if t.get("tp2_hit") else t["current_sl"]
                    log_trade_event({"event": "CLOSE", "time": _now_ny_str(), "symbol": symbol,
                                    "side": "SHORT" if t["is_short"] else "LONG", "model": t["model"],
                                    "entry": t["entry"], "sl": t["sl"], "tp1": t["tp1"], "tp2": t.get("tp2"),
                                    "exit_price": exit_price, "pnl": round(pnl, 2),
                                    "balance": round(account, 2), "reason": reason})
                    if notifier:
                        notifier.send(tg_close(symbol, t, exit_price, pnl, reason, account))
                    print(f"   🏁 {symbol} أُغلقت ({reason}). الرصيد: {account:.2f}$")
                    del active_trades[symbol]
                    STATE.setdefault(symbol, {})["_notified_ready"] = False

            # 2) المسح والتحليل الكامل لكل عملة
            for symbol in coins:
                if symbol in active_trades:
                    continue
                tf = fetch_all_tf(symbol, now_ts)
                if not tf.get("15m") or not tf.get("5m"):
                    print(f"\n🪙 {symbol} | ⚠️ تعذّر جلب البيانات.")
                    continue

                rep = build_report(symbol, now_ts, tf)
                notes = track_state(symbol, rep)
                print("\n" + "=" * 60)
                for ln in rep["lines"]:
                    print(ln)
                if notes:
                    print("🔄 تتبّع الحالة: " + " ".join(notes))
                print("=" * 60 + "\n")

                # 3) التنفيذ الورقي (بوابة Kill Zone صارمة + إصلاح بوابة READY)
                chosen = rep.get("model")
                plan = rep.get("plan")
                if is_executable_model(chosen) and plan and plan.get("entry"):
                    if curr_session not in EXECUTABLE_SESSIONS:
                        prev = STATE.setdefault(symbol, {})
                        if not prev.get("_notified_ready"):
                            if notifier:
                                notifier.send(f"🔔 <b>{symbol}</b>: الموديل {chosen['model']} جاهز — بس الجلسة ميتة ({curr_session}). بنطر لجلسة تنفيذ.")
                            prev["_notified_ready"] = True
                    else:
                        entry, sl, tp1 = plan["entry"], plan["stop_loss"], plan["tp"]
                        risk_dist = abs(entry - sl)
                        risk_usd = account * RISK_PCT
                        pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                        print_banner(f"🔥 تم الدخول (محاكاة)! {symbol} 🔥")
                        print(f"الاتجاه: {'بيع 🔴' if rep['bias'] == 'BEARISH' else 'شراء 🟢'} | الموديل: {chosen['model']}")
                        print(f"دخول: {_fmt(entry)} | SL: {_fmt(sl)} | TP1: {_fmt(tp1)} | الحجم: {pos_size:.4f} | مخاطرة: {risk_usd:.2f}$")
                        t = {"bias": rep["bias"], "entry": entry, "sl": sl, "tp1": tp1,
                             "tp2": (plan.get("tp2") or {}).get("price"),
                             "current_sl": sl, "be_activated": False, "tp1_hit": False, "tp2_hit": False,
                             "is_short": rep["bias"] == "BEARISH", "risk": risk_dist,
                             "size": pos_size, "risk_usd": risk_usd, "model": chosen["model"]}
                        active_trades[symbol] = t
                        STATE.setdefault(symbol, {})["_notified_ready"] = False
                        log_trade_event({"event": "OPEN", "time": _now_ny_str(), "symbol": symbol,
                                        "side": "SHORT" if t["is_short"] else "LONG", "model": t["model"],
                                        "entry": entry, "sl": sl, "tp1": tp1, "tp2": t.get("tp2"),
                                        "size": pos_size, "risk_usd": risk_usd, "balance": round(account, 2)})
                        if notifier:
                            notifier.send(tg_open(symbol, t))

            # نبضة رصيد دورية كل ~30 سكان
            if max_iter is None and iter_count % 30 == 0 and notifier:
                notifier.send(tg_balance(account, len(active_trades)))
            if max_iter and iter_count >= max_iter:
                print(f"\n⏹️ وصلنا لعدد السكان المطلوب ({max_iter}). الرصيد: {account:.2f}$")
                break
            time.sleep(interval)
        except KeyboardInterrupt:
            print(f"\n⏹️ إيقاف يدوي. الرصيد النهائي: {account:.2f}$")
            if notifier:
                notifier.send(f"⏹️ <b>إيقاف يدوي</b>\n💰 الرصيد النهائي: {account:.2f}$")
            sys.exit(0)
        except Exception as e:
            print(f"⚠️ خطأ بالدورة (حراس الاستثناء): {e}")
            time.sleep(10)


def main():
    ap = argparse.ArgumentParser(description="ICT Algo Master — رادار حي خارق بلا AI")
    ap.add_argument("--coins", help="قائمة عملات مفصولة بفاصلة، مثلا BTC/USDT,ETH/USDT")
    ap.add_argument("--mode", default="live", choices=["live", "market"])
    ap.add_argument("--analyze", help="حلل عملة وحدة فوراً (مثلا SOL)")
    ap.add_argument("--interval", type=int, default=SCAN_INTERVAL_SEC, help="ثواني بين السكان")
    ap.add_argument("--telegram", action="store_true", help="فرض تفعيل التيليغرام")
    ap.add_argument("--no-telegram", dest="no_tg", action="store_true")
    ap.add_argument("--once", action="store_true", help="سكان واحد ثم الخروج (للاختبار)")
    ap.add_argument("--max", type=int, default=None, help="عدد السكان الأقصى")
    a = ap.parse_args()

    use_tg = False if a.no_tg else bool(a.telegram or NOTIFIER.enabled)

    if a.analyze:
        run_analyze(a.analyze)
        return
    if a.mode == "market":
        coins = [c.strip().upper() for c in a.coins.split(",")] if a.coins else TOP_20_COINS
        run_market(coins)
        return
    coins = [c.strip().upper() for c in a.coins.split(",")] if a.coins else WATCHING_SYMBOLS
    run_live_autonomous(coins=coins, interval=a.interval, use_tg=use_tg,
                        max_iter=(1 if a.once else a.max))


if __name__ == "__main__":
    main()
