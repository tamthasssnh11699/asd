# 🔬 التحسينات القادمة — بحث عميق من المصادر

## المشكلة #1: الـTrailing (الحل الحالي منيح — تحسين ممكن)

### ما يقوله مايكل بالضبط:
> "trailing stop losses below the previous down-closed candle / bullish order block's low"
> — 2022 Mentorship Notes

> "If you're bullish, down-closed candles should support price, will act as support structure"
> — 2022 Mentorship Notes

> "Once it fills an FVG, an ITL is created and should not be taken out. Once it starts rallying it shouldn't come back below the ITL"
> — 2022 Mentorship Notes

### التحسين المقترح: **Trailing يتبع ITL/ITH (Intermediate Term Low/High)**
بدل ما يتبع كل swing صغيرة:
- يتبع **آخر ITL مؤكد** (Intermediate Term Low = low مع higher low على يمينه ويساره)
- ITL أثقل من swing عادي = trailing أبطأ = يلتقط أكثر

---

## المشكلة #2: دخولات مكررة على نفس الـsetup

### ليش بيصير هالشي:
البوت يسكان كل ساعة. إذا نفس الـsweep+displacement+FVG لسا موجودين = يدخل مرة ثانية.
**المشكلة مش إنو بيدخل كثير — المشكلة إنو بيدخل على نفس ذات الفرصة!**

### الحل الذكي (مش cooldown غبي):
```python
# بدل cooldown بالوقت:
# نتبع الـFVG اللي دخلنا منها
# إذا نفس الـFVG (نفس top/bottom) = ما ندخل ثاني
# المصدر: FVG بيتحشى بعد اللمسة الأولى
# مرة واحدة = الدخول. مرة ثانية = التحشية.

entered_fvgs = set()  # نحفظ الـFVGs اللي دخلنا منها

if (fvg['top'], fvg['bottom']) in entered_fvgs:
    skip  # نفس الـFVG — ما ندخل ثاني
else:
    enter
    entered_fvgs.add((fvg['top'], fvg['bottom']))
```

### ليش هاد أذكى من cooldown:
- Cooldown 12h → ممكن يمنع صفقة ممتازة على FVG مختلفة
- Track FVG → يمنع فقط الدخول المكرر على نفس المنطقة
- مايكل يقول: "if you miss one FVG, look for the next one" → يعني FVGs مختلفة OK

---

## المشكلة #3: TP2 (الهدف الذهبي)

### ما يقوله مايكل بالضبط:

> "take profit at the opposite end of the swept range or beyond"
> — innercircletrader.net 2022 Strategy

> "Exit – where the liquidity is – prior buy stops"
> — 2022 Mentorship Notes

> "Partials at Internal range liquidity"
> — 2022 Mentorship Notes

> "The Draw on Liquidity for the most part is found on the Daily Chart"
> — 2022 Mentorship Ep2

> "When the price trades below the old low or into the FVG within the discount that is where we would sell. We want to use the closest target (low-hanging fruit)"
> — 2022 Mentorship Notes Ep2

### الـTP2 الذهبي الحقيقي:
**ليس رقم ثابت (5R أو 10R) — بل مستوى سيولة حقيقي!**

```
TP2 = أقرب مستوى من هالقائمة (بالأولوية):

1. الطرف الآخر من الـswept range
   المصدر: "opposite end of the swept range"
   مثال: إذا Sweep SSL عند 84000 والـrange high كان 86000
   → TP2 = 86000 (الطرف المقابل)

2. Previous Day High/Low
   المصدر: "lots of liquidity around previous day's highs and lows"
   أقوى مستوى سيولة يومي

3. Previous Session High/Low  
   المصدر: "Look for low hanging fruit"

4. EQH/EQL (Equal Highs/Lows)
   المصدر: "The market does not like to leave relative equal highs"
   "retail sees this as resistance — the market likes to run through them"

5. HTF FVG unfilled
   المصدر: "running to fill an imbalance"

6. Fib -2.0 extension (كـconfirmation فقط)
   المصدر: innercircletrader.net Fib Settings: "-2.0 = full SD expansion"
```

### لماذا هاد أذكى من رقم ثابت:
- رقم ثابت (5R) = عشوائي. ممكن يكون قبل مستوى سيولة أو بعده
- مستوى سيولة حقيقي = السعر **فعلاً** بيتجاوب معه
- مايكل لا يستخدم أرقام — يستخدم مستويات

---

## متى يطلع مايكل من الصفقة (الحالات المحددة):

### المصادر:

> "If your ITH is broken to the upside and you're bearish, your idea was wrong, move to the sidelines. Don't force it."
> — 2022 Mentorship Notes

> "Stick to your bias and only wait for those types of setups unless you are proven absolutely that you are wrong"
> — 2022 Mentorship Notes

> "If it isn't obvious to you... that is normal"
> — 2022 Mentorship Notes

> "When the FVG is completely filled and price closes through it — the order flow has not shown up"
> — fxnx.com IOFED guide

> "Clean invalidation: if price keeps going with momentum, you're wrong. Cut it."
> — medium.com SMC strategies

### 4 حالات خروج عند مايكل:

```
1. TP1 → 50% close + BE (مضمون)

2. TP2 → 100% close (الهدف الذهبي ضُرب)

3. Trailing Stop → structure ينكسر (خروج بربح)

4. INVALIDATION → خروج فوري بأي سعر:
   a. ITH/ITL ينكسر بالإغلاق (مش wick)
      "If your ITH is broken... your idea was wrong"
   b. الـFVG اللي دخلنا منها تنحشى بالكامل + إغلاق عبرها
      "When FVG is completely filled and price closes through it"
   c. الـsweep extreme ينكسر بالإغلاق
      "if price keeps going with momentum, you're wrong"
```

### ما لا يطلع فيه مايكل:
- **لا يطلع بالـnoise** — يتقبل الارتدادات الصغيرة
- **لا يطلع لأنو خايف** — "overwhelming uncertainty eats at you"
- **لا يغير رأيه كل ساعة** — "Stick to your bias"
- **لا يتبع كل شمعة** — يتبع **structure** (ITL/ITH)
