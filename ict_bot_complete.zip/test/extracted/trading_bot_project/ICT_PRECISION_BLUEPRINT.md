# 🎯 ICT Precision Blueprint — الدخول والستوب والتارغت بالميلي

## البحث الكامل من مصادر مايكل + ICT:

---

## 1. الدخول — أين بالضبط؟

### المصادر:
- **innercircletrader.net IOFED guide**: "IOFED is the very edge of the FVG — the level from which price can reverse even after a single-pip tap"
- **innercircletrader.net IOFED**: "ICT teaches pyramiding from the IOFED with adds at the CE"
- **2022 Notes Ep6**: "Best to enter position in a FVG within 50% or higher retracement within the displacement"
- **innercircletrader.net OTE**: "The 70.5% level is the central OTE level"
- **Reddit ICT community**: "When FVG middle body candle close beyond the swing point = IOFED, meaning FVG is not expected to close in"

### الطريقة الذكية:
```
لا نختار نقطة واحدة ثابتة. نبني "نظام هرمي" (Pyramid):

Position 1 (40%): IOFED — حافة الـFVG (أبكر دخول)
  - Bullish: low of 3rd candle (أعلى حافة FVG)
  - Bearish: high of 3rd candle (أدنى حافة FVG)

Position 2 (40%): CE — منتصف FVG (50%)
  - الأكثر تفاعلاً — "most reactive level"

Position 3 (20%): OB body — فتحة شمعة الـOB (إذا متوفر)
  
→ إذا السعر ارتد من IOFED مباشرة: 40% بربح + 60% ما دخلت
→ إذا وصل CE: 80% بربح
→ إذا وصل OB: 100% بربح بأفضل سعر
```

**لكن الروبوت لا يقدر يبني هرم حقيقي** (يحتاج أوامر متعددة).
**الحل العملي الذكي:**

```python
# Entry = weighted average
entry = IOFED * 0.3 + CE * 0.5 + OB_body * 0.2

# أو ببساطة: CE (midpoint) — الأكثر عملية والأكثر تفاعلاً
# مايكل نفسه يقول CE = "most reactive level"
```

---

## 2. الستوب — أين بالضبط؟

### المصادر:
- **innercircletrader.net 2022 Strategy**: "stop loss beyond the swept extreme"
- **innercircletrader.net OB guide**: "10–20 pips beyond the OB extreme"
- **innercircletrader.net Fib**: "10 to 20 pips below the 1.0 fibonacci level"
- **innercircletrader.net OTE**: "Stop loss beyond the extreme of the dealing range... with a small buffer"
- **innercircletrader.net**: "Stops parked exactly at the level get hunted on the wick. The buffer is non-negotiable."
- **2022 Notes Ep6**: "You put your stop above candle 1 or candle 2. That stop may feel like a lot of range. You want a lot of range when you're starting out"
- **arongroups.co CE guide**: "Place stop-loss at structural invalidation, not arbitrary pip distance"
- **fxnx.com IOFED**: "stop below the displacement low is your line of last resort"

### الطريقة الذكية:
```
SL يجب أن يكون عند "نقطة الإبطال الهيكلي" — مش رقم عشوائي.
إذا السعر وصل هناك = القصة كاملة انتهت.

الخيارات بالترتيب من الأوسع (الأأمن) للأضيق:
1. خلف الـsweep wick extreme (الأبعد = الأأمن)
2. خلف الـOB low/high (حافة المنطقة المؤسساتية)
3. خلف الـFVG far edge (حافة الفجوة البعيدة)
4. خلف الـMSS swing (swing اللي اتكسر)

القاعدة الذكية:
SL = أبعد نقطة بين [sweep_wick, OB_edge, FVG_far_edge] + buffer

Buffer ديناميكي:
- Forex: 10-20 pips (مايكل)
- BTC: 0.05-0.15% من السعر (ATR-based)
- Gold: 50-100 cents (مايكل)

القاعدة الحديدية:
إذا SL_distance < 0.5 × ATR(14) → لا صفقة!
"إذا المخاطرة كبيرة: لا تأخذ الصفقة" — مايكل Ep6
```

---

## 3. TP1 — الهدف القريب (Low Hanging Fruit)

### المصادر:
- **2022 Notes Ep2**: "We want to use the closest target (low-hanging fruit)"
- **2022 Notes Ep3**: "Look for low hanging fruit, aim for the easiest target"
- **innercircletrader.net Fib**: "-0.27 = short-term internal target"
- **2022 Notes**: "partials should be taken below each low (sell side liquidity)"
- **innercircletrader.net Fib**: "Taking partials at -1.0"
- **2022 Notes**: "If in 2 cons, sell one at 50% level and the other at sellside liquidity"

### الطريقة الذكية:
```
TP1 = أقرب مستوى سيولة حقيقي باتجاه الصفقة:
1. أقرب old high/low (buy stops / sell stops)
2. أقرب FVG غير ممتلئة بالاتجاه المعاكس
3. Fib -1.0 extension من الـimpulse leg

اختيار الأقرب = low hanging fruit (مايكل)

عند TP1:
- إغلاق 50% من المركز
- SL ينتقل لـBE (سعر الدخول)
```

---

## 4. TP2 — الهدف الذهبي (Draw on Liquidity)

### المصادر:
- **2022 Notes Ep2**: "The Draw on Liquidity for the most part is found on the Daily Chart"
- **2022 Notes**: "Exit – where the liquidity is – prior buy stops"
- **innercircletrader.net Fib**: "-2.0 = full standard deviation, prior session highs/lows"
- **innercircletrader.net Fib**: "trailing the rest toward -2.0 and beyond when the higher-timeframe draw on liquidity supports it"
- **innercircletrader.net 2022**: "take profit at the opposite end of the swept range or beyond"
- **tradingfinder.com**: "target the range low for the take profit"

### الطريقة الذكية:
```
TP2 = Draw on Liquidity على HTF:
1. Previous Day High/Low (الأوضح والأعملي)
2. Previous Session High/Low
3. HTF swing high/low (Daily/4H)
4. Fib -2.0 extension
5. Opposite end of the swept range

هذا الهدف يعطي RR 4-8+ عادةً (الذهبي!)

عند TP2:
- إغلاق 100% المتبقي
- أو trailing stop إذا ما وصل
```

---

## 5. إدارة الصفقة — شمعة بشمعة

### المصادر:
- **2022 Notes**: "trailing stop losses below the previous down-closed candle/bullish order block's low"
- **2022 Notes**: "Once it fills an FVG, an ITL is created and should not be taken out"
- **innercircletrader.net OTE**: "trail the stop to break-even after the first 1:1"
- **xs.com ICT Trading**: "Move stop to break-even after 2R gain. Trail stops behind internal structure or BOS points"
- **2022 Notes**: "If you're bullish, down-closed candles should support price"
- **2022 Notes**: "If your ITH is broken to the upside and you're bearish, your idea was wrong"
- **fxnx.com IOFED**: "what you want to see is a prompt, energetic reaction back in your direction"
- **fxnx.com**: "When price stalls inside the zone, fills the gap completely, and closes through it... the order flow has not shown up"

### الطريقة الذكية:
```
Phase 0: PENDING (Limit Order معلق)
  - السعر لسا ما وصل للدخول
  - إذا FVG انحشيت بالكامل قبل ما يوصل → إلغاء!

Phase 1: ENTERED (بعد الدخول)
  - SL ثابت. لا حركة!
  - مايكل: "Before TP1: SL stays at its ORIGINAL position"
  
  ⚡ Fast Invalidation:
  - إذا أول 3 شموع ما أظهرت "energetic reaction" → مراقبة
  - إذا السعر أغلق خلف الـFVG بالكامل → "order flow has not shown up" → خروج فوري

Phase 2: TP1 HIT (50% مغلقة)
  - SL → BE (سعر الدخول بالضبط)
  - "Taking partials at -1.0 and trailing the rest"

Phase 3: RUNNER (50% المتبقية)
  - Trailing stop يتبع الـstructure على فريم أعلى (15m مش 5m!)
  - "trailing stop below previous bullish OB's low"
  - مش كل swing صغيرة — بل down-closed candles / OBs
  - SL لا يتراجع أبداً!
  
  الفرق الجوهري:
  OLD: trailing على 5m = يلاحق كل تحرك = يُضرب بسرعة
  NEW: trailing على 15m structure = يتحمل النويز = يلتقط الحركة الكبيرة

Phase 4: EXIT
  - TP2 ضُرب → 🏆 Golden exit
  - Trailing ضُرب → 🧠 Structure exit (بربح)
  - BE ضُرب → 🛡️ Risk-free exit
  
Phase X: INVALIDATION (خروج طوارئ)
  - "If your ITH is broken... move to the sidelines"
  - إذا السعر كسر الـsweep extreme بإغلاق → القصة انتهت → خروج فوري
```
