# -*- coding: utf-8 -*-
"""
verify_bot.py — أداة تأكيد مستقلة لتحليل algo_master.py
═══════════════════════════════════════════════════════════════
تشتغل جنب البوت: بتجيب بيانات OKX الحقيقية لحظياً، وبتشغّل نفس دوال
البوت بالضبط (analyze_bias / detect_recent_sweep / analyze_pd_arrays /
analyze_structure / run_entry_models)، وبتطبع "الحقيقة المستقلة"
اللي بتقارنها مع اللي طبعه البوت. إذا تطابقو = البوت عم يقرا الشارت
الحقيقي. وإذا اختلفو = في مشكلة.

التشغيل:
    python3 verify_bot.py            # يفحص كل العملات
    python3 verify_bot.py SOL        # يفحص عملة وحدة (مع عرض شموع للعين)
    python3 verify_bot.py BTC --eyeball   # مع عرض آخر 45 شمعة للتأكد من السحب
"""
import sys, argparse, pytz
sys.path.insert(0, "/tmp/fakepkgs")
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import requests
from datetime import datetime, timezone

import brain_core
class FakeBrain:
    class data_manager:
        @staticmethod
        def fetch_ohlcv_up_to(*a, **k):
            raise RuntimeError("not used")
brain_core.BrainCore = FakeBrain

import algo_master as am
NY = pytz.timezone("America/New_York")

SYMS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]

def fetch(symbol, bar, limit=250):
    okx = {"1w": "1W", "1d": "1D", "4h": "4H"}.get(bar, bar)
    r = requests.get("https://www.okx.com/api/v5/market/history-candles",
                     params={"instId": symbol.replace("/", "-"), "bar": okx,
                             "limit": str(limit)}, timeout=25).json()
    raw = list(reversed(r["data"]))
    return {"timestamps": [int(x[0]) for x in raw], "opens": [float(x[1]) for x in raw],
            "highs": [float(x[2]) for x in raw], "lows": [float(x[3]) for x in raw],
            "closes": [float(x[4]) for x in raw], "volumes": [float(x[5]) for x in raw],
            "symbol": symbol, "timeframe": bar, "count": len(raw), "source": "okx"}

def analyze(symbol):
    tf = {b: fetch(symbol, b) for b in ["1w", "1d", "4h", "15m", "5m"]}
    d1d, d4h, d15, d5 = tf["1d"], tf["4h"], tf["15m"], tf["5m"]
    bias = am.analyze_bias(d1d, d4h, tf["1w"])["dir_1d"]
    lm = am.analyze_liquidity_map(d15, "15m")
    sw = am.detect_recent_sweep(d15, bias, "15m")
    st = am.analyze_structure(d15, "15m")
    mr = am.run_entry_models(d5, bias, [(k, tf[k]) for k in ("1d", "4h") if tf.get(k)])
    ch = mr.get("chosen_model") if mr and not mr.get("error") else None
    return {"tf": tf, "bias": bias, "lm": lm, "sw": sw, "st": st,
            "model": ch, "final": (mr or {}).get("final_status")}

def short(symbol, r):
    b = r["bias"]
    sw = r["sw"]
    sweep_txt = (f"{sw['side']} {sw['level']:.2f} (فتيل {sw['wick']:.2f})") if sw else "لا سحب بعد"
    mod = r["model"]
    mod_txt = f"{mod['model']}/{mod['status']}" if mod else f"{r['final']}"
    plan = (mod or {}).get("plan") or {}
    plan_txt = (f"دخول {plan['entry']:.2f} | SL {plan['stop_loss']:.2f} | TP1 {plan['tp']:.2f} (RR {plan.get('rr')})") if plan else "—"
    print(f"  🪙 {symbol:<10} | انحياز {b:<7} | سحب 15m: {sweep_txt:<28} | موديل: {mod_txt:<26} | {plan_txt}")

def eyeball(symbol, r, n=45):
    d15 = r["tf"]["15m"]; n0 = len(d15["closes"])
    print(f"\n  👁️ عرض آخر {n} شمعة 15m لـ {symbol} (نتأكد من السحب بعيننا):")
    print("     idx   time(NY)      O        H        L        C")
    for i in range(n0 - n, n0):
        t = datetime.fromtimestamp(d15["timestamps"][i] / 1000, tz=NY)
        print(f"     {- (n0 - i):>3}   {t.strftime('%m-%d %H:%M')}  {d15['opens'][i]:7.2f} {d15['highs'][i]:7.2f} {d15['lows'][i]:7.2f} {d15['closes'][i]:7.2f}")
    if r["sw"]:
        print(f"     👉 السحب المكتشف: {r['sw']['side']} عند {r['sw']['level']:.2f} (فتيل {r['sw']['wick']:.2f})")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("symbol", nargs="?", default="ALL")
    ap.add_argument("--eyeball", action="store_true", help="اعرض آخر شموع للتأكد اليدوي")
    a = ap.parse_args()
    targets = [a.symbol.upper()] if a.symbol != "ALL" else SYMS
    # normalize to SYMS entries
    targets = [s for s in SYMS if s.replace("/","") in a.symbol.replace("/","") or a.symbol == "ALL"] or targets

    print("🔍 فحص مستقل ببيانات OKX الحقيقية — نفس دوال algo_master بالضبط\n")
    results = {}
    for sym in (SYMS if a.symbol == "ALL" else targets):
        try:
            r = analyze(sym)
            results[sym] = r
            short(sym, r)
        except Exception as e:
            print(f"  🪙 {sym:<10} | ⚠️ خطأ: {e}")

    if a.symbol != "ALL" and results:
        sym = list(results.keys())[0]
        eyeball(sym, results[sym])
    elif a.eyeball:
        for sym in results:
            eyeball(sym, results[sym], n=20)

    print("\n✅ قارن هالنتيجة مع اللي طبعه البوت — إذا تطابقو البوت عم يقرا الشارت الحقيقي.")
    print("   🔁 شغّلها كمان مرة بعد دقيقتين: الحقل 'الانحياز/السحب/الـFVG/الموديل' لازم يضل ثابت (بيتغيّر بس السعر).")

if __name__ == "__main__":
    main()
