# -*- coding: utf-8 -*-
"""
ict_smart_runner.py — الـRunner الذكي اللي يفكر كمايكل
═══════════════════════════════════════════════════════════
يقرأ الشارت كل شمعة. يفهم القصة. يميّز بين:
- STL sweep (سحب سيولة للتجميع = ابقَ!)
- ITL break (كسر هيكلي حقيقي = اطلع!)
- OB support (شموع اتجاهية تدعم = ابقَ!)
- Structure break (الهيكل انكسر = اطلع!)

المصادر:
- مايكل: "continue to trust that move and hold onto your trade"
- مايكل: "down-closed candles should support price"
- مايكل: "Only permissible break is STL taking out sell-stops to re-accumulate"
- مايكل: "If your ITH is broken, your idea was wrong"
- مايكل: "Once an ITL is created it should not be taken out"
- مايكل: "Keep perspective limited to 5-day time horizon"
"""
import numpy as np


class MarketReader:
    """
    يقرأ الشارت ويفهم الهيكل — يميّز STL من ITL.
    
    STL (Short Term Low): أي swing low عادي — كسره = سحب سيولة = عادي
    ITL (Intermediate Term Low): low مع higher low على يمينه ويساره
      → كسر ITL = "significant break in market structure"
    """
    
    def __init__(self):
        self.candles = []
        self.swing_lows = []   # كل swing low مع تصنيفه
        self.swing_highs = []
        self.ob_supports = []  # down-closed candles = bullish OB support
        self.ob_resistances = []  # up-closed candles = bearish OB resistance
    
    def add_candle(self, candle):
        """يضيف شمعة ويحدث فهمه للهيكل."""
        self.candles.append(candle)
        n = len(self.candles)
        if n < 5:
            return
        
        # Track OB-like candles (directional candles = structure)
        # مايكل: "down-closed candles should support price" (bullish)
        # مايكل: "up-closed candles should not be breached" (bearish)
        c = self.candles[-1]
        if c['c'] < c['o']:  # down-closed = potential bullish support
            body_pct = (c['o'] - c['c']) / (c['h'] - c['l']) if c['h'] != c['l'] else 0
            if body_pct > 0.4:  # real directional candle, not doji
                self.ob_supports.append({
                    'low': c['l'], 'high': c['h'], 'open': c['o'],
                    'index': n-1, 'broken': False
                })
        elif c['c'] > c['o']:  # up-closed = potential bearish resistance
            body_pct = (c['c'] - c['o']) / (c['h'] - c['l']) if c['h'] != c['l'] else 0
            if body_pct > 0.4:
                self.ob_resistances.append({
                    'low': c['l'], 'high': c['h'], 'open': c['o'],
                    'index': n-1, 'broken': False
                })
        
        # Detect swing points (need 2 candles on each side for confirmation)
        mid = n - 3
        if mid < 2:
            return
        
        # Swing Low: middle candle low < neighbors
        if (self.candles[mid]['l'] < self.candles[mid-1]['l'] and
            self.candles[mid]['l'] < self.candles[mid-2]['l'] and
            self.candles[mid]['l'] < self.candles[mid+1]['l'] and
            self.candles[mid]['l'] < self.candles[mid+2]['l']):
            
            # Classify: STL or ITL?
            sl_entry = {
                'price': self.candles[mid]['l'],
                'index': mid,
                'type': 'STL',  # default — upgrade to ITL below
                'broken': False,
            }
            
            # Check if this is an ITL:
            # ITL = has higher low on both sides (it's a structural low)
            # مايكل: "ITL has higher low to the left and right of it"
            prev_lows = [s['price'] for s in self.swing_lows[-3:]]
            if prev_lows and sl_entry['price'] < min(prev_lows):
                # This is the LOWEST low recently — more likely ITL
                sl_entry['type'] = 'ITL'
            elif len(prev_lows) >= 2:
                # Check if previous swing low was higher (= we have HL pattern)
                if prev_lows[-1] > sl_entry['price']:
                    sl_entry['type'] = 'ITL'  # Breaking this = breaking structure
            
            self.swing_lows.append(sl_entry)
        
        # Swing High: middle candle high > neighbors
        if (self.candles[mid]['h'] > self.candles[mid-1]['h'] and
            self.candles[mid]['h'] > self.candles[mid-2]['h'] and
            self.candles[mid]['h'] > self.candles[mid+1]['h'] and
            self.candles[mid]['h'] > self.candles[mid+2]['h']):
            
            sh_entry = {
                'price': self.candles[mid]['h'],
                'index': mid,
                'type': 'STH',
                'broken': False,
            }
            
            prev_highs = [s['price'] for s in self.swing_highs[-3:]]
            if prev_highs and sh_entry['price'] > max(prev_highs):
                sh_entry['type'] = 'ITH'
            elif len(prev_highs) >= 2:
                if prev_highs[-1] < sh_entry['price']:
                    sh_entry['type'] = 'ITH'
            
            self.swing_highs.append(sh_entry)
    
    def is_structure_intact(self, is_long, current_close):
        """
        هل الهيكل لسا سليم؟ = هل لازم نبقى بالصفقة؟
        
        مايكل:
        - "Once an ITL is created it should not be taken out"
        - "If your ITH is broken, your idea was wrong"
        - "Only permissible break is STL for re-accumulation"
        
        Returns: (intact: bool, reason: str)
        """
        if is_long:
            # Check ITL breaks (= structure break = EXIT)
            for sl in reversed(self.swing_lows[-5:]):
                if sl['type'] == 'ITL' and not sl['broken']:
                    if current_close < sl['price']:
                        sl['broken'] = True
                        return False, f"ITL BROKEN at {sl['price']:.0f} — structure invalidated"
            
            # Check OB support breaks (= bearish signal)
            # مايكل: "down-closed candles should support price"
            recent_obs = [ob for ob in self.ob_supports[-5:] if not ob['broken']]
            broken_obs = 0
            for ob in recent_obs:
                if current_close < ob['low']:
                    ob['broken'] = True
                    broken_obs += 1
            
            if broken_obs >= 2:
                return False, f"Multiple OB supports broken — institutional selling"
            
            # STL break = OK (re-accumulation)
            # مايكل: "Only permissible that they break is if it is a STL"
            for sl in reversed(self.swing_lows[-5:]):
                if sl['type'] == 'STL' and not sl['broken']:
                    if current_close < sl['price']:
                        sl['broken'] = True
                        # This is OK — just re-accumulation
            
            return True, "Structure intact — OBs supporting, ITL holding"
        
        else:  # Short
            for sh in reversed(self.swing_highs[-5:]):
                if sh['type'] == 'ITH' and not sh['broken']:
                    if current_close > sh['price']:
                        sh['broken'] = True
                        return False, f"ITH BROKEN at {sh['price']:.0f} — structure invalidated"
            
            recent_obs = [ob for ob in self.ob_resistances[-5:] if not ob['broken']]
            broken_obs = 0
            for ob in recent_obs:
                if current_close > ob['high']:
                    ob['broken'] = True
                    broken_obs += 1
            
            if broken_obs >= 2:
                return False, f"Multiple OB resistances broken — institutional buying"
            
            for sh in reversed(self.swing_highs[-5:]):
                if sh['type'] == 'STH' and not sh['broken']:
                    if current_close > sh['price']:
                        sh['broken'] = True
            
            return True, "Structure intact — OBs resisting, ITH holding"
    
    def get_smart_trail_level(self, is_long, buffer=0):
        """
        مستوى trailing ذكي — خلف ITL/ITH فقط (مش أي swing).
        
        مايكل: "trailing stop below previous bullish OB's low"
        لكن: مش كل OB — فقط الـITL/ITH confirmed
        """
        if is_long:
            # Trail behind last confirmed ITL
            itls = [s for s in self.swing_lows if s['type'] == 'ITL' and not s['broken']]
            if itls:
                return itls[-1]['price'] - buffer
            # Fallback: trail behind last unbroken OB support
            obs = [ob for ob in self.ob_supports if not ob['broken']]
            if obs:
                return obs[-1]['low'] - buffer
        else:
            iths = [s for s in self.swing_highs if s['type'] == 'ITH' and not s['broken']]
            if iths:
                return iths[-1]['price'] + buffer
            obs = [ob for ob in self.ob_resistances if not ob['broken']]
            if obs:
                return obs[-1]['high'] + buffer
        
        return None


def manage_smart_dual(candle_5m, candle_1h, state):
    """
    يدير الصفقة المزدوجة بذكاء مايكل.
    
    Position A: الصياد — يخرج بسرعة بربح مضمون
    Position B: الراكب — يبقى طالما الهيكل سليم
    """
    h, l, c, o = candle_5m['h'], candle_5m['l'], candle_5m['c'], candle_5m.get('o', candle_5m['c'])
    is_short = state['is_short']
    is_long = not is_short
    events = []
    risk = state['risk']
    
    # Initialize reader if needed
    if 'reader' not in state:
        state['reader'] = MarketReader()
    
    # Feed candles to the reader
    if candle_1h:
        state['reader'].add_candle(candle_1h)
    
    # Track days
    state['candle_count'] = state.get('candle_count', 0) + 1
    days_in_trade = state['candle_count'] / 288  # 288 5M candles = 1 day
    
    # ═══ POSITION A: الصياد ═══
    pa = state.get('pos_a', {})
    if pa.get('active'):
        if not pa.get('tp1_hit'):
            if (is_short and h >= pa['sl']) or (is_long and l <= pa['sl']):
                pa['active'] = False
                pa['pnl'] = -state['risk_pct_a']
                pa['exit_reason'] = 'SL_HIT'
                events.append('❌ A:SL')
            elif pa.get('tp1'):
                if (is_short and l <= pa['tp1']) or (is_long and h >= pa['tp1']):
                    pa['tp1_hit'] = True
                    move = abs(pa['tp1'] - pa['entry'])
                    rr = move / risk if risk > 0 else 0
                    pa['pnl'] = rr * state['risk_pct_a']
                    pa['sl'] = pa['entry']
                    events.append('🎯 A:TP1')
        elif pa.get('tp1_hit'):
            if (is_short and h >= pa['sl']) or (is_long and l <= pa['sl']):
                pa['active'] = False
                pa['exit_reason'] = 'A_TRAIL'
                events.append('🧠 A:Trail')
            else:
                # Quick trailing for Position A
                body = abs(c - o)
                rng = h - l
                if rng > 0 and body / rng > 0.5:
                    atr = state.get('atr', 1)
                    if is_long and c > o:
                        new_sl = l - atr * 0.1
                        if new_sl > pa['sl']:
                            pa['sl'] = new_sl
                    elif is_short and c < o:
                        new_sl = h + atr * 0.1
                        if new_sl < pa['sl']:
                            pa['sl'] = new_sl
    
    # ═══ POSITION B: الراكب الذكي ═══
    pb = state.get('pos_b', {})
    if pb.get('active'):
        
        # TP2 — always check
        if pb.get('tp2_price'):
            if (is_short and l <= pb['tp2_price']) or (is_long and h >= pb['tp2_price']):
                pb['active'] = False
                move = abs(pb['tp2_price'] - pb['entry'])
                rr = move / risk if risk > 0 else 0
                pb['pnl'] = rr * state['risk_pct_b']
                pb['exit_reason'] = 'TP2_GOLDEN'
                events.append('🏆 B:TP2 GOLDEN!')
                # Force close A too if still open
                if pa.get('active'):
                    pa['active'] = False
                    if not pa.get('tp1_hit'):
                        move_a = abs(pb['tp2_price'] - pa['entry'])
                        rr_a = move_a / risk if risk > 0 else 0
                        pa['pnl'] = rr_a * state['risk_pct_a']
                    pa['exit_reason'] = 'CLOSED_WITH_B'
                    events.append('🏆 A:Closed with B at TP2')
        
        if not pb.get('active', True):
            pass  # Already closed above
        
        # SL check (before BE is set)
        elif not pb.get('be_set'):
            if (is_short and h >= pb['sl']) or (is_long and l <= pb['sl']):
                pb['active'] = False
                pb['pnl'] = -state['risk_pct_b']
                pb['exit_reason'] = 'SL_HIT'
                events.append('❌ B:SL')
        
        # After BE: THE SMART PART — read the chart!
        elif pb.get('be_set') and pb.get('active', False):
            
            # BE check
            if (is_short and h >= pb['sl']) or (is_long and l <= pb['sl']):
                pb['active'] = False
                trail_move = abs(pb['sl'] - pb['entry'])
                rr = trail_move / risk if risk > 0 else 0
                pb['pnl'] = rr * state['risk_pct_b']
                pb['exit_reason'] = 'SMART_TRAIL'
                events.append('🧠 B:Smart trail')
            
            # 5-day limit
            # مايكل: "Keep perspective limited to 5-day time horizon"
            elif days_in_trade >= 5:
                pb['active'] = False
                move = abs(c - pb['entry'])
                rr = move / risk if risk > 0 else 0
                direction_ok = (is_long and c > pb['entry']) or (is_short and c < pb['entry'])
                pb['pnl'] = rr * state['risk_pct_b'] if direction_ok else 0
                pb['exit_reason'] = '5DAY_LIMIT'
                events.append('📅 B:5-day limit')
            
            else:
                # ═══ READ THE CHART — هل الهيكل لسا سليم؟ ═══
                intact, reason = state['reader'].is_structure_intact(is_long, c)
                
                if not intact:
                    # Structure broken! EXIT!
                    pb['active'] = False
                    move = abs(c - pb['entry'])
                    rr = move / risk if risk > 0 else 0
                    direction_ok = (is_long and c > pb['entry']) or (is_short and c < pb['entry'])
                    pb['pnl'] = rr * state['risk_pct_b'] if direction_ok else 0
                    pb['exit_reason'] = 'STRUCTURE_BREAK'
                    events.append(f'🧱 B:{reason}')
                else:
                    # Structure intact — update trailing behind ITL/ITH
                    atr = state.get('atr', abs(pb['entry'] * 0.001))
                    trail = state['reader'].get_smart_trail_level(is_long, buffer=atr * 0.3)
                    
                    if trail is not None:
                        if is_long and trail > pb['sl']:
                            pb['sl'] = trail
                            events.append(f'📈 B:ITL trail→{trail:.0f}')
                        elif is_short and trail < pb['sl']:
                            pb['sl'] = trail
                            events.append(f'📉 B:ITH trail→{trail:.0f}')
        
        # Set BE when Position A hits TP1
        if pa.get('tp1_hit') and not pb.get('be_set') and pb.get('active'):
            pb['sl'] = pb['entry']
            pb['be_set'] = True
            events.append('🛡️ B:BE (A hit TP1)')
    
    # Both closed?
    both_closed = (not pa.get('active', False)) and (not pb.get('active', False))
    if both_closed:
        state['pnl_pct'] = (pa.get('pnl', 0) or 0) + (pb.get('pnl', 0) or 0)
        state['exit_reason_a'] = pa.get('exit_reason', '?')
        state['exit_reason_b'] = pb.get('exit_reason', '?')
    
    return events, both_closed


def manage_triple_position(candle_5m, candle_1h, candle_4h, state):
    """
    3 مراكز بالتوازي من نفس الدخول:
    
    A (60%): Scalp — يخرج عند TP1 بسرعة
    B (30%): Day Runner — يبقى ساعات، trailing على 1H ITL
    C (10%): Swing Runner — يبقى أيام، trailing على 4H/Daily structure
    
    المصدر: مايكل Core Content:
    "Take 70% off when you can and let the remaining run"
    "Swing Trading: entry on 5-min, manage on 4-hour"
    "Keep perspective limited to 5-day time horizon"
    """
    h, l, c, o = candle_5m['h'], candle_5m['l'], candle_5m['c'], candle_5m.get('o', candle_5m['c'])
    is_short = state['is_short']
    is_long = not is_short
    events = []
    risk = state['risk']
    
    # Initialize readers
    if 'reader_1h' not in state:
        state['reader_1h'] = MarketReader()
    if 'reader_4h' not in state:
        state['reader_4h'] = MarketReader()
    
    if candle_1h:
        state['reader_1h'].add_candle(candle_1h)
    if candle_4h:
        state['reader_4h'].add_candle(candle_4h)
    
    state['candle_count'] = state.get('candle_count', 0) + 1
    days = state['candle_count'] / 288
    
    # ═══ POSITION A: Scalp (same as before) ═══
    pa = state.get('pos_a', {})
    if pa.get('active'):
        if not pa.get('tp1_hit'):
            if (is_short and h >= pa['sl']) or (is_long and l <= pa['sl']):
                pa['active'] = False; pa['pnl'] = -state['risk_pct_a']; pa['exit_reason'] = 'SL'
                events.append('❌ A:SL')
            elif pa.get('tp1'):
                if (is_short and l <= pa['tp1']) or (is_long and h >= pa['tp1']):
                    pa['tp1_hit'] = True
                    rr = abs(pa['tp1'] - pa['entry']) / risk if risk > 0 else 0
                    pa['pnl'] = rr * state['risk_pct_a']
                    pa['sl'] = pa['entry']
                    events.append('🎯 A:TP1')
        elif pa.get('tp1_hit'):
            if (is_short and h >= pa['sl']) or (is_long and l <= pa['sl']):
                pa['active'] = False; pa['exit_reason'] = 'A_TRAIL'
                events.append('🧠 A:Trail')
            else:
                body = abs(c - o); rng = h - l
                if rng > 0 and body / rng > 0.5:
                    atr = state.get('atr', 1)
                    if is_long and c > o:
                        ns = l - atr * 0.1
                        if ns > pa['sl']: pa['sl'] = ns
                    elif is_short and c < o:
                        ns = h + atr * 0.1
                        if ns < pa['sl']: pa['sl'] = ns
    
    # ═══ POSITION B: Day Runner (1H ITL trailing) ═══
    pb = state.get('pos_b', {})
    if pb.get('active'):
        if pb.get('tp2_price'):
            if (is_short and l <= pb['tp2_price']) or (is_long and h >= pb['tp2_price']):
                pb['active'] = False
                rr = abs(pb['tp2_price'] - pb['entry']) / risk if risk > 0 else 0
                pb['pnl'] = rr * state['risk_pct_b']; pb['exit_reason'] = 'TP2'
                events.append('🏆 B:TP2')
        
        if pb.get('active') and not pb.get('be_set'):
            if (is_short and h >= pb['sl']) or (is_long and l <= pb['sl']):
                pb['active'] = False; pb['pnl'] = -state['risk_pct_b']; pb['exit_reason'] = 'SL'
                events.append('❌ B:SL')
        
        if pb.get('active') and pb.get('be_set'):
            if (is_short and h >= pb['sl']) or (is_long and l <= pb['sl']):
                pb['active'] = False
                rr = abs(pb['sl'] - pb['entry']) / risk if risk > 0 else 0
                pb['pnl'] = rr * state['risk_pct_b']; pb['exit_reason'] = 'B_TRAIL'
                events.append('🧠 B:Trail')
            else:
                intact, reason = state['reader_1h'].is_structure_intact(is_long, c)
                if not intact:
                    pb['active'] = False
                    rr = abs(c - pb['entry']) / risk if risk > 0 else 0
                    ok = (is_long and c > pb['entry']) or (is_short and c < pb['entry'])
                    pb['pnl'] = rr * state['risk_pct_b'] if ok else 0
                    pb['exit_reason'] = 'B_STRUCT'; events.append(f'🧱 B:{reason[:30]}')
                else:
                    atr = state.get('atr', 1)
                    tl = state['reader_1h'].get_smart_trail_level(is_long, buffer=atr*0.3)
                    if tl:
                        if is_long and tl > pb['sl']: pb['sl'] = tl
                        elif is_short and tl < pb['sl']: pb['sl'] = tl
        
        if pa.get('tp1_hit') and not pb.get('be_set') and pb.get('active'):
            pb['sl'] = pb['entry']; pb['be_set'] = True
            events.append('🛡️ B:BE')
    
    # ═══ POSITION C: Swing Runner (4H/Daily structure — يبقى أيام!) ═══
    # المصدر: مايكل: "Swing Trading: manage on 4-hour"
    # المصدر: "Keep perspective limited to 5-day time horizon"
    # المصدر: "try to hold it out for the move"
    pc = state.get('pos_c', {})
    if pc.get('active'):
        
        # TP3: Draw on Liquidity الأبعد
        if pc.get('tp3_price'):
            if (is_short and l <= pc['tp3_price']) or (is_long and h >= pc['tp3_price']):
                pc['active'] = False
                rr = abs(pc['tp3_price'] - pc['entry']) / risk if risk > 0 else 0
                pc['pnl'] = rr * state['risk_pct_c']; pc['exit_reason'] = 'TP3_MEGA'
                events.append('💎 C:TP3 MEGA!')
        
        # SL (before BE)
        if pc.get('active') and not pc.get('be_set'):
            if (is_short and h >= pc['sl']) or (is_long and l <= pc['sl']):
                pc['active'] = False; pc['pnl'] = -state['risk_pct_c']; pc['exit_reason'] = 'SL'
                events.append('❌ C:SL')
        
        # After BE
        if pc.get('active') and pc.get('be_set'):
            if (is_short and h >= pc['sl']) or (is_long and l <= pc['sl']):
                pc['active'] = False
                rr = abs(pc['sl'] - pc['entry']) / risk if risk > 0 else 0
                ok = (is_long and pc['sl'] > pc['entry']) or (is_short and pc['sl'] < pc['entry'])
                pc['pnl'] = rr * state['risk_pct_c'] if ok else 0
                pc['exit_reason'] = 'C_TRAIL'; events.append('🧠 C:4H Trail')
            
            # 5-day limit
            elif days >= 5:
                pc['active'] = False
                ok = (is_long and c > pc['entry']) or (is_short and c < pc['entry'])
                rr = abs(c - pc['entry']) / risk if risk > 0 else 0
                pc['pnl'] = rr * state['risk_pct_c'] if ok else 0
                pc['exit_reason'] = '5DAY'; events.append('📅 C:5-day')
            
            else:
                # ═══ 4H STRUCTURE CHECK ═══
                # مايكل: "manage on 4-hour"
                # أبطأ بكثير من 1H — يتحمل retracements يومية
                intact_4h, reason_4h = state['reader_4h'].is_structure_intact(is_long, c)
                if not intact_4h:
                    pc['active'] = False
                    rr = abs(c - pc['entry']) / risk if risk > 0 else 0
                    ok = (is_long and c > pc['entry']) or (is_short and c < pc['entry'])
                    pc['pnl'] = rr * state['risk_pct_c'] if ok else 0
                    pc['exit_reason'] = 'C_4H_BREAK'
                    events.append(f'🧱 C:4H {reason_4h[:25]}')
                else:
                    # Trail behind 4H ITL
                    atr = state.get('atr', 1)
                    tl4 = state['reader_4h'].get_smart_trail_level(is_long, buffer=atr*0.5)
                    if tl4:
                        if is_long and tl4 > pc['sl']: pc['sl'] = tl4
                        elif is_short and tl4 < pc['sl']: pc['sl'] = tl4
        
        # BE when A hits TP1
        if pa.get('tp1_hit') and not pc.get('be_set') and pc.get('active'):
            pc['sl'] = pc['entry']; pc['be_set'] = True
            events.append('🛡️ C:BE')
    
    # All closed?
    all_closed = (not pa.get('active',False)) and (not pb.get('active',False)) and (not pc.get('active',False))
    if all_closed:
        state['pnl_pct'] = (pa.get('pnl',0) or 0) + (pb.get('pnl',0) or 0) + (pc.get('pnl',0) or 0)
        state['exit_reason_a'] = pa.get('exit_reason','?')
        state['exit_reason_b'] = pb.get('exit_reason','?')
        state['exit_reason_c'] = pc.get('exit_reason','?')
    
    return events, all_closed
