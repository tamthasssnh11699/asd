import sys
sys.path.insert(0, ".")
from algo_master import run_live_autonomous
# We will just run it but break it after 1 cycle to see the output format.
import time
time.sleep = lambda x: sys.exit(0) # kill after 1st cycle

try:
    run_live_autonomous()
except SystemExit:
    pass
