with open("algo_master.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i in range(len(lines)):
    if '                if res.get("classification") == "LIQUIDITY_RUN_CONTINUATION":\n' == lines[i]:
        lines[i+1] = '                    pass\n'

with open("algo_master.py", "w", encoding="utf-8") as f:
    f.writelines(lines)
