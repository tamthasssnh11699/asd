import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome

brain = BrainCore()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_USD = ACCOUNT_BALANCE * 0.01 # $1.00

# أولاً سنجلب المرشحين من 5 إلى 10 (نقاط جديدة)
print("نجلب النقاط الجديدة من السوق...")
import scan_last_month_michael_style_v7 as scanner

with open('/tmp/last_month_michael_candidates_v7.json') as f:
    all_candidates = json.load(f)
    
candidates = all_candidates[5:10]

results = []
for idx, cand in enumerate(candidates):
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    dt_str = cand['datetime_utc']
    swept_level = cand['swept_level_price']
    
    found = False
    for k in range(0, 36):
        sim_ts = sweep_ts + (k * 5 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                model = chosen.get("model")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    if outcome and outcome.get("outcome") != "PENDING":
                        out_code = outcome.get("outcome")
                        
                        # Financial Math
                        sl_dist_pct = abs(entry - sl) / entry
                        pos_size_usd = RISK_USD / sl_dist_pct if sl_dist_pct > 0 else 0
                        
                        profit_usd = 0.0
                        if out_code in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
                            tp1_dist_pct = abs(tp1 - entry) / entry
                            profit_usd = (tp1_dist_pct * pos_size_usd) * 0.5 
                        elif out_code == "SL_HIT":
                            profit_usd = -RISK_USD
                        
                        results.append({
                            "num": idx+6,
                            "date": dt_str,
                            "bias": bias,
                            "sweep_level": swept_level,
                            "type": "SHORT" if is_short else "LONG",
                            "entry": entry,
                            "sl": sl,
                            "tp1": tp1,
                            "model": model,
                            "outcome": out_code,
                            "sl_dist_pct": sl_dist_pct * 100,
                            "pos_size": pos_size_usd,
                            "profit": profit_usd,
                            "mfe": outcome.get('max_favorable_excursion')
                        })
                        found = True
                        break
        except Exception as e:
            pass
            
    if not found:
        results.append({
            "num": idx+6,
            "date": dt_str,
            "outcome": "HOLD"
        })

print("="*50)
for r in results:
    print(r)

