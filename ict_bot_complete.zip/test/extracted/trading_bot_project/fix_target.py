import sys
sys.path.insert(0, ".")
from data_manager import DataManager
from authenticity_engine import AuthenticityEngine

dm = DataManager()
data_15m = dm.get_ohlcv("SOLUSDT", "15m", 200, output_format="dict")
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}
ae = AuthenticityEngine()
sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)

lows = [s for s in sig.get("all_lows_tiered", []) if s['price'] < closed_15m['closes'][-1] and s.get("tier") in ["MAJOR", "MODERATE"]]

valid_lows = []
n = len(closed_15m['closes'])
for s in lows:
    idx = n + s['index_from_end']
    min_since = min(closed_15m['lows'][idx+1:]) if idx+1 < n else closed_15m['lows'][idx]
    if min_since >= s['price']: # It hasn't been breached!
        valid_lows.append(s)

print(f"Valid lows: {valid_lows}")
