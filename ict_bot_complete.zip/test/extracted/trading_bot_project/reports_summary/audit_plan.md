# خطة المراجعة الشاملة الكاملة للمشروع — من الصفر للنهاية

**الهدف**: مراجعة كل جزء من المشروع، دالة دالة، للتأكد من:
1. **التطابق الحرفي مع دستور مايكل** (`data/trading_knowledge.txt`, 16,529 سطر، 22 قسم رئيسي).
2. **الصحة الرياضية الكاملة** (بلا أخطاء حسابية، بلا انعكاسات اتجاه، بلا قيم مستحيلة).
3. **التناظر التام بين الاتجاهين** (شراء=BULLISH/LONG يقابله بيع=BEARISH/SHORT بمرآة كاملة - أي منطق يُطبَّق لاتجاه يجب أن ينعكس صح للاتجاه الثاني، بلا تحيز).
4. **قدرة تمييز الحقيقي من الوهمي** في كل موقع قرار: كسر حقيقي/فخ (fakeout)، سحب سيولة حقيقي/مصطنع، ريتيست حقيقي/وهمي، انعكاس حقيقي/تصحيح مؤقت، OB حقيقي/مشبوه، FVG حقيقي/بلا قيمة.

## منهجية المراجعة لكل دالة/قسم
1. قراءة نص الدستور ذي الصلة أولاً (لا افتراض من الذاكرة).
2. قراءة الكود الفعلي كاملاً.
3. اختبار الاتجاهين (BULLISH/BEARISH أو LONG/SHORT) بسيناريوهات صناعية متناظرة تماماً + بيانات حقيقية عند الإمكان.
4. البحث عن أي "تحيز اتجاهي" (كود يعمل صح لجهة وناقص/معكوس للجهة الثانية).
5. البحث عن أي حالة قد تُخرج رقماً "مستحيلاً" (خارج نطاق منطقي، بالاتجاه المعاكس، بلا أساس بالبيانات).
6. توثيق: ✅ سليم / ⚠️ يحتاج تحسين / ❌ خطأ مكتشف (مع سبب دقيق ورقم سطر).
7. أي إصلاح: تنفيذه فوراً + unit test + regression + تحقق أنه لا يكسر الصفقات الرابحة الموثّقة.

## المراحل (بالترتيب، من الأساس للأعلى)

### المرحلة 0: البنية التحتية الرياضية البحتة (`ict_math_engine.py`, 2767 سطر، 24 دالة)
- [ ] `_atr` — حساب ATR
- [ ] `compute_displacement` — قياس الانزياح/الديسبليسمنت
- [ ] `detect_fair_value_gaps` — كشف FVG (bullish + bearish)
- [ ] `_compute_fill_pct` — نسبة امتلاء الفجوة
- [ ] `detect_order_blocks` — كشف Order Blocks (bullish + bearish)
- [ ] `_count_retests` — عدّ إعادة الاختبار
- [ ] `classify_sweep_or_run` — تصنيف سحب السيولة الحقيقي/الوهمي
- [ ] `detect_judas_swing` — كشف Judas Swing
- [ ] `detect_mss` — كشف Market Structure Shift (BOS/CHoCH)
- [ ] `compute_mechanical_bias_anchor` — حساب الانحياز الميكانيكي
- [ ] `compute_premium_discount` — حساب Premium/Discount + OTE
- [ ] `find_structural_sl_anchors` — إيجاد نقاط الستوب الهيكلية
- [ ] `detect_equal_highs_lows` — كشف EQH/EQL
- [ ] `find_tp_targets` — حساب TP1/TP2 (تم إصلاح باغ خطير فيها الجلسة الماضية)
- [ ] `simulate_managed_trade_outcome` — محاكاة إدارة الصفقة
- [ ] `compute_opposing_break_context` — سياق الكسر المعاكس
- [ ] `compute_structural_break_quality_score` — جودة الكسر الهيكلي
- [ ] `classify_break_reversal_authenticity` — تصنيف أصالة الانعكاس
- [ ] `check_order_invalidated_before_fill` — إبطال الأوامر المعلّقة
- [ ] `detect_breaker_block_opportunity` — كشف Breaker Block
- [ ] `classify_htf_structural_challenge` — تصنيف التحدي الهيكلي (انعكاس حقيقي/تصحيح)

### المرحلة 1: محرك الأصالة (`authenticity_engine.py`, 2347 سطر، ~25 دالة)
- كل دوال كشف الفخاخ (fakeout)، تقييم الحجم، تدقيق الادعاءات الرقمية، سلاسل الاستنتاج السببي.

### المرحلة 2: محرك نماذج الدخول (`ict_entry_checklist_engine.py`, 1506 سطر)
- Model A إلى F + Generic Fallback — كل نموذج دخول يجب فحصه بالاتجاهين.

### المرحلة 3: محرك التحليل متعدد المراحل (`multi_pass_analysis.py`, 3304 سطر)
- تسلسل Weekly→Daily→4H→1H→Entry، البوابات (Gates)، آليات التحقق والإصلاح التلقائي.

### المرحلة 4: الباكتيست والتنفيذ الفعلي (`human_trades_backtest.py`, `backtest_engine.py`, `brain_core.py`)

### المرحلة 5: تنظيف الملفات المؤقتة/التجريبية
- عشرات ملفات `run_trade*.py` وسكربتات `scan_last_month_*` المكرّرة (v1-v7) — تحديد أيها فعّال وأيها legacy يمكن أرشفته.

## سجل التقدّم
(يُحدَّث بعد كل دالة/قسم يُنجَز)

### المرحلة 0: `ict_math_engine.py` — ✅ منجزة بالكامل (2767 سطر، 24 دالة، كل الدوال فُحصت)

**منهجية الفحص المُطبَّقة لكل دالة**: (1) قراءة نص الدستور المطابق، (2) قراءة الكود، (3) unit test بالاتجاهين (BULLISH/BEARISH أو LONG/SHORT) بسيناريوهات صناعية متناظرة (مرآة كاملة)، (4) بحث خارجي عند الشك، (5) توثيق النتيجة.

| الدالة | الحالة | الملاحظة |
|---|---|---|
| `_atr` | ✅ سليم | حساب Wilder's ATR قياسي |
| `compute_displacement` | ⚠️→✅ موثَّق | لا يفحص الحجم كشرط إلزامي رغم أن نص الدستور المحلي يذكره كـ"ALL must be present" — **تحقق خارجي**: أداة FibAlgo المرجعية (طرق الكشف الرسمية الثلاث) لا تستخدم الحجم إطلاقاً بأي منها؛ متوافق مع [CRYPTO_MARKET_DATA] 19.3 (الحجم تكميلي، لا بوابة قاطعة). أُضيف تعليق توضيحي بالكود يوثّق هذا القرار بدليل خارجي، لا إغفال. الحجم يُستخدم فعلياً بمكان منفصل (`compute_structural_break_quality_score` Factor 3). |
| `detect_fair_value_gaps` | ✅ سليم | تعريف الـ3 شمعات الصارم + فلتر ديسبليسمنت + filled_pct، متناظر تماماً bullish/bearish |
| `_compute_fill_pct` | ✅ سليم | |
| `detect_order_blocks` | ✅ سليم + مُختبَر | Unit test: سيناريو صاعد ومرآته الهابطة أعطيا نفس القياسات بالضبط (نطاق 2.4، engulf/fvg/tested_count متطابقة). نطاق `top=high,bottom=low` (Standard غير refined) **مؤكَّد خارجياً** (أداة TradingFinder المرجعية: "Standard = entire length from Low to High") |
| `_count_retests` | ✅ سليم | |
| `classify_sweep_or_run` | ✅ سليم + مُختبَر | 3 unit tests (فتيل يرجع=GENUINE_REVERSAL_SWEEP، إغلاق يتجاوز=LIQUIDITY_RUN_CONTINUATION، بالاتجاهين) كلها نجحت |
| `detect_judas_swing` | ✅ سليم | نافذة NY_AM_KILLZONE (08:30-11:00 NY) بعد نطاق ليلي 00:00-08:30 **مؤكَّدة خارجياً حرفياً** (ictkillzone.com: "overnight range midnight-8:30 AM ET... NY open sweeps one of its boundaries") |
| `detect_mss` | ✅ سليم + مُختبَر | Unit test: سيناريو صاعد (سوينغ لو+قمة+سحب+اندفاع كاسر) ومرآته الهابطة أعطيا نفس البنية بالضبط |
| `compute_mechanical_bias_anchor` | ✅ سليم | منطق HH/HL vs LH/LL + اتفاق/تعارض مع آخر كسر مؤكد، متناظر |
| `compute_premium_discount` | ✅ سليم + مُختبَر | Unit test يطابق **المثال الحرفي بالدستور 100%** (bullish OTE=[98642,99146]، bearish OTE=[99854,100358]) - باغ سابق (قياس من القاع دائماً بغض النظر عن الاتجاه) تم إصلاحه بجلسة سابقة، **مؤكَّد الاستدعاء الوحيد الفعلي بالمشروع يمرر `is_bullish_setup` صراحة** (لا اعتماد على افتراضي خطر) |
| `find_structural_sl_anchors` | ✅ سليم + مُختبَر | Unit test بالاتجاهين: LONG anchors كلها تحت السعر المرجعي، SHORT كلها فوقه - تناظر تام |
| `detect_equal_highs_lows` | ✅ سليم + مُختبَر | Unit test: 3 قمم بفارق 0.2856% (ضمن حد 0.3%) اتجمعت TRIPLE بشكل صحيح |
| `find_tp_targets` | ✅ سليم بعد الإصلاح + مُختبَر بشكل شامل | **الإصلاح الحرج بالجلسة الماضية (`direction_preserved_after_offset`) مؤكَّد يعمل**: unit test بالاتجاهين (LONG tp1 فوق الدخول دائماً، SHORT تحته دائماً) نجح؛ صفقات رابحة موثّقة (trade8/9/14) لم تتأثر |
| `simulate_managed_trade_outcome` | ✅ سليم | منطق إدارة الصفقة (TP1 50%+BE+Structure Trail) مبني بحرص شديد، متناظر تماماً بين is_short=True/False، بما فيه معالجة دقيقة لتصادم SL/TP1 بنفس شمعة الدخول (تقريب مسار OHLC القياسي) |
| `compute_opposing_break_context` | ✅ سليم + مُختبَر | Unit test بالاتجاهين: 9 كسور معاكسة سابقة → STRONG_OPPOSING_CONTEXT بكلا الاتجاهين بالتساوي |
| `compute_structural_break_quality_score` | ✅ سليم | 5+1 عوامل (BOS/CHoCH Quality Score حرفي من الدستور + Factor 6 كثافة سياق) - منطق متناظر، لا تحيز اتجاهي |
| `classify_break_reversal_authenticity` | ✅ سليم | 4 حالات (MAJOR/CONFIRMED_HIGH_CONVICTION/PARTIALLY_CONFIRMED/UNCONFIRMED) بلا أي تمييز اتجاهي بالمنطق |
| `check_order_invalidated_before_fill` | ✅ سليم | من جلسة سابقة، مؤكَّد حياً (صفقة 54 ساعة) |
| `detect_breaker_block_opportunity` | ✅ سليم | من جلسة سابقة، 4 شروط مطابقة لـ6+ مصادر خارجية |
| `classify_htf_structural_challenge` | ✅ سليم | من جلسة سابقة، منطق مبني على `challenging_direction` متغير، لا تحيز، مؤكَّد حياً مرتين (P5, P7) |

**النتيجة الإجمالية للمرحلة 0**: الملف الرياضي الأساسي **سليم بنيوياً بنسبة عالية جداً** - لا أخطاء رياضية جديدة، لا تحيزات اتجاهية، توثيق واحد فقط (الحجم بالديسبليسمنت) تم توضيحه بتعليق بدل تعديل الكود (القرار الأصلي صحيح ومدعوم خارجياً).

### التالي: المرحلة 1 — `authenticity_engine.py` (2347 سطر، ~25 دالة) - قيد التنفيذ
