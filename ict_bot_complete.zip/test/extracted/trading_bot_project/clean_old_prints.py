import re

with open("algo_master.py", "r", encoding="utf-8") as f:
    content = f.read()

content = re.sub(r'print\(f"🪙 \{symbol:<9\} \| السعر: \{current_p:\.4f\}.*?\)', '', content)
content = re.sub(r'print\(f"🪙 \{symbol:<9\} \| הסعر: \{current_p:\.4f\}.*?\)', '', content)

with open("algo_master.py", "w", encoding="utf-8") as f:
    f.write(content)

