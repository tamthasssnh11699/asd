import re

with open("algo_master.py", "r", encoding="utf-8") as f:
    content = f.read()

content = content.replace("                                valid_target = None", "                valid_target = None")

with open("algo_master.py", "w", encoding="utf-8") as f:
    f.write(content)
