import sys, json
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import os
os.chdir("/home/user/test/extracted/trading_bot_project")
from nemotron_backtest_driver import run_one_backtest

KEY = "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"
trades = json.load(open("/home/user/human_trades/all_human_trades_with_outcomes.json"))
t1 = next(t for t in trades if t["id"] == 1)

result = run_one_backtest(
    symbol=t1["symbol"], timeframe="1h", end_ts=t1["publish_ts"],
    api_key=KEY, label="TEST_LESSON_V2_EFFECT_TRADE1", max_tokens=4000, timeout=200,
    backup_keys=[],
)
with open("/home/user/human_trades/test_lesson_v2_effect_trade1_result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False, default=str)
print("done, signal:", (result or {}).get("result",{}).get("signal"))
