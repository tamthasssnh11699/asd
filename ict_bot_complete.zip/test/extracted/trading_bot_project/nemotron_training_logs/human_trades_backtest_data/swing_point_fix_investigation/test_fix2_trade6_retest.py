import sys, json
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import os
os.chdir("/home/user/test/extracted/trading_bot_project")
from nemotron_backtest_driver import run_one_backtest

KEY = "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"
trades = json.load(open("/home/user/human_trades/all_human_trades_with_outcomes.json"))
t6 = next(t for t in trades if t["id"] == 6)

result = run_one_backtest(
    symbol=t6["symbol"], timeframe="1h", end_ts=t6["publish_ts"],
    api_key=KEY, label="TEST_FIX2_TRADE6_RETEST", max_tokens=4000, timeout=200,
    backup_keys=[],
)
with open("/home/user/human_trades/test_fix2_trade6_retest_result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False, default=str)
print("done, signal:", (result or {}).get("result",{}).get("signal"))
