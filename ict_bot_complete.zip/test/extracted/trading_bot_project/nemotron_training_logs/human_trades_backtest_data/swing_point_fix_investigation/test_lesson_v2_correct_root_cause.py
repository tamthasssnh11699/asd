"""
استخراج الدرس الصحيح من صفقة BTC #1 - هذه المرة بالسياق الدقيق الكامل
المكتشف بالتحليل العميق (لا السياق السطحي "لم يوجد تأكيد 1H" السابق
الذي أنتج تعديلاً خاطئاً زاد الخسارة). السبب الجذري الحقيقي الموثّق:
البوت استخدم قاعاً يومياً (26 أبريل) كمرجع حماية للـSL رغم أن نفس
الشمعة اليومية التالية المتاحة أصلاً وقت اتخاذ القرار (27-28 أبريل)
كانت قد كسرت هذا القاع فعلياً لأسفل - أي أن مرجع الحماية كان "ميتاً"
فعلياً لحظة استخدامه.
"""
import sys, json
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import os
os.chdir("/home/user/test/extracted/trading_bot_project")

from nemotron_openrouter_client import NemotronClient
import lesson_learning

KEY = "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"

trade_context = {
    "symbol": "BTC/USDT",
    "signal": "BUY",
    "entry_model": "MODEL_A_OTE_OB",
    "bot_reasoning": (
        "SL at 76100 (below Daily HL 76562 and 1H sweep low 76426, with "
        "0.3*ATR buffer)"
    ),
    "what_the_bot_claimed_as_reference_low": (
        "A daily swing low from 2 days before entry, labeled as the "
        "governing 'Higher Low' (HL) of the bullish Daily structure."
    ),
}

# السياق الدقيق - هذا الجزء هو الاكتشاف الفعلي من التحقق اليدوي بالبيانات
outcome_summary = {
    "outcome": "SL_HIT",
    "detail": (
        "VERIFIED ROOT CAUSE (checked directly against raw OHLC data, "
        "independent of the bot's own narrative): the daily swing low "
        "the bot used as its SL reference point ('Daily HL') had ALREADY "
        "BEEN BROKEN by a MORE RECENT daily candle that was already "
        "available in the dataset at the exact moment the trade was "
        "entered - the very next daily candle after the referenced low, "
        "and even the daily candle of the entry day itself, both printed "
        "a LOWER low than the reference level the bot cited as its "
        "'Higher Low' structural support. The bot's SL was therefore "
        "NOT actually protected by a level that had proven to hold - it "
        "was resting inside a zone that price had already demonstrated "
        "it could trade through. The stop was hit within about half a "
        "day, when price made an entirely ordinary continuation move "
        "into the SAME territory that had already been visited below "
        "the cited reference low before entry - not a new, unusual, or "
        "unpredictable move. The market later did move strongly in the "
        "intended direction (the bias itself was correct), but the SL "
        "placement failed to survive completely ordinary volatility "
        "because it referenced a stale/already-invalidated swing low "
        "instead of the most recent confirmed one."
    ),
    "was_decision_correct_in_hindsight": False,
    "was_the_directional_bias_correct": True,
    "was_the_risk_placement_correct": False,
}

print("=== سياق دقيق ومصحّح (السبب الجذري الفعلي المُتحقَّق) ===")
print(json.dumps(outcome_summary, indent=2, ensure_ascii=False)[:600])
print()

nc = NemotronClient(KEY, reasoning_effort="none", max_tokens=1500, timeout=120)
print("جارٍ استخراج الدرس الصحيح من الموديل الفعلي...")
lesson = lesson_learning.extract_lesson(nc, trade_context, outcome_summary)

if lesson:
    print()
    print("=== الدرس الجديد الصحيح ===")
    print(json.dumps(lesson, indent=2, ensure_ascii=False))
else:
    print("❌ فشل الاستخراج")

with open("/home/user/human_trades/lesson_v2_extracted.json", "w", encoding="utf-8") as f:
    json.dump(lesson, f, indent=2, ensure_ascii=False)
