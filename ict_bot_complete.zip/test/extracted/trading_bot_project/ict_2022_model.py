# -*- coding: utf-8 -*-
"""
ict_2022_model.py — نموذج ICT 2022 الموحد
═══════════════════════════════════════════
المصدر: ICT 2022 Mentorship (Michael Huddleston)
innercircletrader.net: "Complete ICT Trading Strategy 2022"
liquidityscan.io: "The 2022 Mentorship Model is a four-step sequence"

النموذج = تسلسل واحد:
  1. Daily Bias (HTF direction)
  2. Liquidity Sweep (session high/low or swing raid)
  3. Market Structure Shift + Displacement (close through swing with big candle)
  4. Fair Value Gap from displacement (entry zone)
  5. Retest of FVG (trigger)

ليس 6 نماذج منفصلة. نموذج واحد بقصة واحدة متسلسلة.
"""
import numpy as np
from ict_math_engine import (
    detect_ict_three_candle_swings, _atr,
    compute_premium_discount, find_tp_targets,
)


def detect_displacement_ict(data, lookback=30):
    """
    Displacement بتعريف مايكل الحقيقي:
    
    المصدر: ictkillzone.com:
    "significantly larger than the 3–5 preceding candles, at minimum 2x"
    "body-to-range ratio above ~75%"
    
    المصدر: FibAlgo (أداة مرجعية):
    "body at least 60-70% of total candle range"
    
    المصدر: innercircletrader.net Displacement guide:
    "Without displacement, there is no valid FVG entry"
    
    الشروط (ديناميكية، مش أرقام ثابتة):
    1. body ≥ 2× متوسط جسم آخر 5 شموع (يتكيف مع التقلب)
    2. body/range ≥ 60% (يضمن أنها شمعة اتجاهية مش فتيل)
    3. يجب أن تترك FVG (بدون FVG = ليس displacement)
    """
    opens = np.asarray(data.get("opens", []), dtype=float)
    highs = np.asarray(data.get("highs", []), dtype=float)
    lows = np.asarray(data.get("lows", []), dtype=float)
    closes = np.asarray(data.get("closes", []), dtype=float)
    n = len(closes)
    if n < 10:
        return {"displacement_candles": [], "most_recent": None}
    
    start = max(6, n - lookback)
    results = []
    
    for i in range(start, n):
        body = abs(closes[i] - opens[i])
        rng = highs[i] - lows[i]
        if rng <= 0:
            continue
        body_pct = body / rng
        
        # شرط 1: body/range ≥ 60% (مرجع: FibAlgo 60-70%)
        if body_pct < 0.60:
            continue
        
        # شرط 2: body ≥ 2× متوسط آخر 5 شموع
        # (مرجع: "significantly larger than 3-5 preceding candles, at minimum 2x")
        prev_start = max(0, i - 5)
        prev_bodies = [abs(closes[j] - opens[j]) for j in range(prev_start, i)]
        if not prev_bodies:
            continue
        avg_body = np.mean(prev_bodies)
        if avg_body <= 0:
            continue
        body_multiple = body / avg_body
        if body_multiple < 2.0:
            continue
        
        # شرط 3: يجب أن تترك FVG (نفحص بالشمعة التالية)
        leaves_fvg = False
        if i >= 2 and i < n - 1:
            # Bullish FVG: low[i+1] > high[i-1]
            if closes[i] > opens[i]:  # bullish displacement
                if i + 1 < n and lows[i + 1] > highs[i - 1]:
                    leaves_fvg = True
            # Bearish FVG: high[i+1] < low[i-1]
            else:
                if i + 1 < n and highs[i + 1] < lows[i - 1]:
                    leaves_fvg = True
        
        direction = "BULLISH" if closes[i] > opens[i] else "BEARISH"
        
        results.append({
            "index": i,
            "index_from_end": i - n,
            "direction": direction,
            "body": round(body, 4),
            "body_pct": round(body_pct * 100, 1),
            "body_multiple": round(body_multiple, 2),
            "leaves_fvg": leaves_fvg,
            "is_valid_displacement": leaves_fvg,  # displacement بدون FVG = ليس حقيقي
            "open": round(float(opens[i]), 6),
            "close": round(float(closes[i]), 6),
            "high": round(float(highs[i]), 6),
            "low": round(float(lows[i]), 6),
        })
    
    valid = [d for d in results if d['is_valid_displacement']]
    return {
        "displacement_candles": results,
        "valid_displacements": valid,
        "most_recent": valid[-1] if valid else None,
    }


def evaluate_ict_2022_model(data_5m, data_15m, bias, session_info=None):
    """
    النموذج الموحد — تسلسل واحد:
    
    المصدر: innercircletrader.net "Complete ICT Trading Strategy 2022":
    "1. Establish daily bias
     2. Mark the price range
     3. Wait for liquidity sweep
     4. Watch for MSS on lower timeframes
     5. Confirm displacement
     6. Mark the PD Array (FVG)
     7. Wait for retest
     8. Execute"
    
    Returns:
        {
            "stage": "WAITING_FOR_SWEEP" | "WAITING_FOR_MSS" | 
                     "WAITING_FOR_FVG_RETEST" | "READY",
            "narrative": str,  # القصة الكاملة
            "sweep": {...},
            "mss": {...},
            "fvg": {...},
            "plan": {...} or None,
        }
    """
    if bias not in ("BULLISH", "BEARISH"):
        return {"stage": "NO_BIAS", "narrative": "Bias unclear — no trade"}
    
    is_long = bias == "BULLISH"
    n5 = len(data_5m.get("closes", []))
    n15 = len(data_15m.get("closes", [])) if data_15m else 0
    
    if n5 < 30 or n15 < 20:
        return {"stage": "INSUFFICIENT_DATA", "narrative": "Not enough candles"}
    
    # ═══════════════════════════════════════════════════
    # STEP 1: LIQUIDITY SWEEP (on 15m — setup timeframe)
    # ═══════════════════════════════════════════════════
    # المصدر: 2022 Mentorship: "wait for liquidity sweep of the range"
    
    swings_15 = detect_ict_three_candle_swings(data_15m)
    
    # البحث عن sweep: wick تجاوز swing level + close رجع
    sweep = None
    target_swings = swings_15['swing_lows'] if is_long else swings_15['swing_highs']
    
    # نبحث عن sweep في آخر 12 شمعة 15m
    search_start = max(0, n15 - 12)
    
    for sw in reversed(target_swings):
        sw_idx = sw['index']
        if sw_idx >= n15 - 1:
            continue
        
        # هل أي شمعة لاحقة (خلال 12 bar) سحبت هذا المستوى؟
        for i in range(max(sw_idx + 1, search_start), n15):
            if is_long:
                wicked = data_15m['lows'][i] < sw['price']
                closed_back = data_15m['closes'][i] > sw['price']
            else:
                wicked = data_15m['highs'][i] > sw['price']
                closed_back = data_15m['closes'][i] < sw['price']
            
            if wicked and closed_back:
                sweep = {
                    "level": sw['price'],
                    "sweep_index_15m": i,
                    "sweep_ts": data_15m['timestamps'][i] if i < len(data_15m.get('timestamps', [])) else None,
                    "side": "SSL" if is_long else "BSL",
                    "wick_extreme": data_15m['lows'][i] if is_long else data_15m['highs'][i],
                }
                break
        if sweep:
            break
    
    if not sweep:
        return {
            "stage": "WAITING_FOR_SWEEP",
            "narrative": f"{'SSL' if is_long else 'BSL'} sweep not detected on 15m yet",
            "sweep": None, "mss": None, "fvg": None, "plan": None,
        }
    
    # ═══════════════════════════════════════════════════
    # STEP 2: MSS + DISPLACEMENT (on 5m — entry timeframe)
    # ═══════════════════════════════════════════════════
    # المصدر: "After the sweep, switch to lower timeframes (5M) to confirm a reversal"
    # المصدر: backtrex.com: "MSS = sweep + close through swing with displacement"
    
    # حدد الشموع على 5m التي تقع بعد الـsweep
    sweep_ts = sweep.get('sweep_ts')
    sweep_5m_start = 0
    if sweep_ts:
        for i, ts in enumerate(data_5m['timestamps']):
            if ts >= sweep_ts:
                sweep_5m_start = i
                break
    else:
        sweep_5m_start = max(0, n5 - 36)  # fallback: last 3 hours
    
    # ابحث عن displacement بعد الـsweep
    disp = detect_displacement_ict(data_5m, lookback=n5 - sweep_5m_start + 5)
    
    # فلتر: displacement يجب أن يكون بعد الـsweep وبنفس اتجاه الـbias
    valid_disp = [d for d in disp.get('valid_displacements', []) 
                  if d['index'] >= sweep_5m_start and d['direction'] == bias]
    
    if not valid_disp:
        # هل في displacement بدون FVG؟ (للتشخيص)
        all_disp = [d for d in disp.get('displacement_candles', [])
                    if d['index'] >= sweep_5m_start and d['direction'] == bias]
        if all_disp:
            narrative = (f"Displacement found (body {all_disp[-1]['body_multiple']}x avg, "
                        f"{all_disp[-1]['body_pct']}% body ratio) but no FVG formed")
        else:
            narrative = "No displacement candle after sweep"
        
        return {
            "stage": "WAITING_FOR_MSS",
            "narrative": narrative,
            "sweep": sweep, "mss": None, "fvg": None, "plan": None,
        }
    
    mss_disp = valid_disp[-1]  # أحدث displacement صالح
    
    # ═══════════════════════════════════════════════════
    # STEP 3: FVG FROM DISPLACEMENT
    # ═══════════════════════════════════════════════════
    # المصدر: "Mark the PD Array created during the displacement leg — FVG"
    
    disp_idx = mss_disp['index']
    
    # الـFVG تتكون من الـdisplacement candle والشمعتين حولها
    if disp_idx < 1 or disp_idx >= n5 - 1:
        return {
            "stage": "WAITING_FOR_FVG_RETEST",
            "narrative": "Displacement at edge of data — can't form FVG",
            "sweep": sweep, "mss": mss_disp, "fvg": None, "plan": None,
        }
    
    if is_long:
        fvg_top = data_5m['lows'][disp_idx + 1]
        fvg_bottom = data_5m['highs'][disp_idx - 1]
    else:
        fvg_top = data_5m['lows'][disp_idx - 1]
        fvg_bottom = data_5m['highs'][disp_idx + 1]
    
    if fvg_top <= fvg_bottom:
        return {
            "stage": "WAITING_FOR_MSS",
            "narrative": "Displacement didn't create a valid FVG gap",
            "sweep": sweep, "mss": mss_disp, "fvg": None, "plan": None,
        }
    
    fvg_ce = (fvg_top + fvg_bottom) / 2
    
    # هل الـFVG لسا نشطة (ما انحشيت)؟
    fvg_filled = False
    for i in range(disp_idx + 2, n5):
        if is_long and data_5m['lows'][i] <= fvg_bottom:
            fvg_filled = True
            break
        if not is_long and data_5m['highs'][i] >= fvg_top:
            fvg_filled = True
            break
    
    fvg = {
        "top": round(fvg_top, 6),
        "bottom": round(fvg_bottom, 6),
        "ce": round(fvg_ce, 6),
        "disp_index": disp_idx,
        "is_active": not fvg_filled,
    }
    
    if fvg_filled:
        return {
            "stage": "FVG_FILLED",
            "narrative": "FVG was filled — setup invalidated",
            "sweep": sweep, "mss": mss_disp, "fvg": fvg, "plan": None,
        }
    
    # ═══════════════════════════════════════════════════
    # STEP 4: BUILD PLAN
    # ═══════════════════════════════════════════════════
    # المصدر: "Execute the trade at the PD Array tap"
    # Entry: at FVG CE (Consequent Encroachment — innercircletrader.net)
    # SL: beyond the swept extreme (innercircletrader.net MSS guide)
    # TP: opposite liquidity pool
    
    entry_price = fvg_ce
    
    # SL: beyond the sweep extreme
    # المصدر: "stop loss beyond the swept extreme that preceded the MSS, with a small buffer"
    buffer = abs(sweep['wick_extreme'] - sweep['level']) * 0.1  # 10% of sweep wick
    if buffer < abs(entry_price) * 0.0005:
        buffer = abs(entry_price) * 0.0005  # minimum buffer
    
    if is_long:
        sl_price = sweep['wick_extreme'] - buffer
    else:
        sl_price = sweep['wick_extreme'] + buffer
    
    risk_dist = abs(entry_price - sl_price)
    if risk_dist <= 0:
        return {
            "stage": "INVALID_GEOMETRY",
            "narrative": "SL too close to entry",
            "sweep": sweep, "mss": mss_disp, "fvg": fvg, "plan": None,
        }
    
    # TP: find targets
    tp_result = find_tp_targets(data_5m, entry_price, sl_price, is_long=is_long)
    tp1 = tp_result.get('tp1')
    
    if not tp1:
        return {
            "stage": "NO_TARGET",
            "narrative": "No structural target found with sufficient R:R",
            "sweep": sweep, "mss": mss_disp, "fvg": fvg, "plan": None,
        }
    
    plan = {
        "direction": "BUY_LIMIT" if is_long else "SELL_LIMIT",
        "entry": round(entry_price, 6),
        "stop_loss": round(sl_price, 6),
        "tp": tp1['price'],
        "tp1": tp1,
        "tp2": tp_result.get('tp2'),
        "rr": tp1['rr'],
        "basis": (
            f"ICT 2022 Model: {sweep['side']} sweep at {sweep['level']:.2f} "
            f"→ {bias} displacement ({mss_disp['body_multiple']}x avg, {mss_disp['body_pct']}% body) "
            f"→ FVG {fvg['bottom']:.2f}-{fvg['top']:.2f} "
            f"→ entry at CE {fvg['ce']:.2f}"
        ),
    }
    
    # هل السعر الحالي عند/قرب الـFVG؟
    cur_price = data_5m['closes'][-1]
    near_fvg = fvg_bottom <= cur_price <= fvg_top
    
    if near_fvg:
        stage = "READY"
        narrative = f"Price AT FVG — READY to execute {plan['direction']}"
    else:
        stage = "WAITING_FOR_FVG_RETEST"
        dist = abs(cur_price - fvg_ce)
        narrative = f"Waiting for price to retrace to FVG CE={fvg_ce:.2f} (distance: {dist:.2f})"
    
    return {
        "stage": stage,
        "narrative": narrative,
        "sweep": sweep,
        "mss": mss_disp,
        "fvg": fvg,
        "plan": plan,
    }
