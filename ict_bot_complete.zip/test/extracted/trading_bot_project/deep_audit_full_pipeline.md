# 🔬 تدقيق عميق: المسار التحليلي الكامل — دالة دالة من البيانات حتى إغلاق الصفقة

**المنهج:** كل دالة تُفحص بمعيارين:
1. **هل الفكرة نفسها ICT حقيقي؟** (مطابقة مفهوم مايكل)
2. **هل التطبيق يُنفذها بشكل صحيح بلا مبالغة/تراخي/خربطة؟**

**التصنيفات المستخدمة:** ICT-MATCH | ICT-PARTIAL | IMPLEMENTATION-BUG | OVERSTRICT | OVERPERMISSIVE | CONTEXT-BLIND | UNSOURCED | CONFLICT | LOOKAHEAD | DEAD-CODE | DISPLAY-ONLY

---

## المرحلة 1: جلب البيانات

### `fetch_all_tf()` — algo_master.py:192
**ماذا تفعل:** تجلب 1w/1d/4h/15m/5m من OKX بنفس `now_ts`.

**الحكم: OVERPERMISSIVE + ERROR-HIDING**

**المشاكل:**
- **تبتلع كل Exception بصمت** (سطر 198: `except Exception: d = None`). إذا فشل جلب Daily أو 4H، يكمل التحليل بدون أن يعرف أحد أن البيانات ناقصة. الانحياز يصبح UNKNOWN بصمت.
- **لا يوجد فحص freshness**: لو كان آخر timestamp متأخر ساعة عن `now_ts`، يقبل البيانات.
- **لا يوجد فحص OHLCV integrity**: NaN، timestamps مكررة، High < Low — كلها تمر.
- **Weekly يُجلب ولا يُستخدم** في القرار الفعلي (راجع `analyze_bias`).
- **لا فحص alignment بين الفريمات**: 5m قد يكون أحدث من 15m بدقائق.

**هل هذا ICT؟** لا. هذه مسألة هندسة بيانات.

---

## المرحلة 2: الانحياز (Daily Bias)

### `analyze_bias()` — algo_master.py:209
**ماذا تفعل:** تحسب الانحياز من Daily + 4H + challenge.

**الحكم: DISPLAY-ONLY (4H) + DEAD-CODE (Weekly) + ICT-PARTIAL (Daily)**

**المشاكل الحرجة:**
1. **Weekly لا يدخل في القرار أبداً** — يُجلب ويُمرر ولا يُستخدم. سطر 360: `tf.get("1w")` يُمرر لـ`analyze_bias` لكن الدالة لا تفعل شيئاً به.
2. **4H challenge يُحسب ويُخزن في `res["htf_challenge"]`** لكنه **لا يؤثر** على `res["dir_1d"]`. حتى لو كانت النتيجة `REAL_REVERSAL_CONFIRMED`، الاتجاه يبقى كما هو. **DISPLAY-ONLY**.
3. **لا يوجد `context_warnings`** أو أي آلية لإبلاغ البوت أن هناك تعارض.

**هل هذا ICT؟** مايكل يستخدم Top-Down فعلاً (Weekly → Daily → 4H)، لكن التنفيذ هنا **Daily فقط**. الادعاء بأنه "Top-Down" مبالغ فيه.

### `compute_mechanical_bias_anchor()` — ict_math_engine.py:717
**ماذا تفعل:** تقارن تسلسل HH/HL مع آخر structural break.

**الحكم: ICT-PARTIAL + CONTEXT-BLIND**

**ما هو صحيح:**
- HH+HL = صاعد، LH+LL = هابط — مفهوم صحيح عند ICT.
- إذا تعارض المصدران → MIXED — قرار سليم.

**ما هو ناقص:**
- **يعتمد فقط على آخر قمتين وآخر قاعين** — نافذة ضيقة جداً.
- **لا يستخدم Draw on Liquidity**: مايكل لا يحدد الانحياز فقط من HH/HL. يسأل: أين يريد السعر أن يذهب؟ أي سيولة يستهدف؟
- **لا يستخدم HTF dealing range أو Premium/Discount**.
- **آخر break من `detect_mss` غير مصنف**: قد يكون internal BOS تافه.
- **`swing_window=2`**: مايكل عرّف swing بثلاث شموع (2022 Ep5, 14:29). هذه الدالة تستخدم `window=2` (أي 5 شموع).

---

## المرحلة 3: خريطة السيولة

### `analyze_liquidity_map()` — algo_master.py:230
**ماذا تفعل:** تجمع BSL (فوق السعر) وSSL (تحت السعر) من `detect_significant_swings`.

**الحكم: ICT-PARTIAL + CONTEXT-BLIND + UNSOURCED**

**ما هو صحيح:**
- BSL فوق السعر، SSL تحت السعر — صحيح مفهومياً.
- ترتيب حسب المسافة — منطقي.

**ما هو خاطئ/ناقص:**
1. **`detect_significant_swings` ليست ICT**: تستخدم topographic prominence وعتبات ATR مخترعة (0.5/1.5/4 ATR). **مايكل عرّف Swing بثلاث شموع فقط.** لا يوجد `detect_ict_three_candle_swings` في الكود.
2. **لا يحدد هل المستوى swept سابقاً**: مستوى مسحوب ليس سيولة بعد.
3. **لا يدمج EQH/EQL**: مستويات متساوية = سيولة مكدّسة أهم من swing منفرد.
4. **لا يفرق external/internal liquidity**.
5. **يختار أقرب 3 فقط** — قد يفوّت المستوى الأهم إذا كان أبعد قليلاً.
6. **وصف BSL بأنها "هدف البيع/الشورت"** — غير دقيق. BSL قد تكون هدف صعود أو raid قبل هبوط.

---

## المرحلة 4: كشف السحب (Sweep)

### `detect_recent_sweep()` — algo_master.py:252 + `find_recent_sweep()` — ict_math_engine.py:442

**الحكم: CONFLICT + IMPLEMENTATION-BUG + OVERPERMISSIVE**

**⚠️ مشكلة التكرار:**
- `algo_master.detect_recent_sweep` (39 سطر) و`find_recent_sweep` (47 سطر) **يكرران نفس المنطق بشكل شبه مطابق**. الكود يدّعي أنه وحّدهما لكن algo_master لا تزال تطبق منطقها المستقل.

**⚠️ مشكلة `classify_sweep_or_run` (سطر 363):**
```python
for i in range(start, n):
    if wicked_beyond:
        return {...}  # يرجع أول breach ويتوقف!
```
- **يرجع أول breach زمنياً وليس الأحدث**. إذا حصل Run ثم Sweep، يرجع الـRun.
- **لا يتعامل مع `close == level_price`**: إغلاق على المستوى بالضبط يُعتبر "عاد للداخل" = Sweep مؤكد. هذا ليس صحيحاً بالضرورة.
- **لا tolerance/tick size**: تجاوز بـ0.0001 يُعتبر sweep.
- **يسمي النتيجة فوراً `GENUINE_REVERSAL_SWEEP`** بلا displacement أو MSS بعده. هذا تسمية مبالغة. الأدق: `WICK_RAID_REJECTED_ON_CLOSE`.

**⚠️ مشكلة الاختيار:**
- يختار المستوى **الأقرب للسعر الحالي**، ليس الأحدث ولا الأهم.
- **window=12 ثابت** عبر 5m و15m — ساعة على 5m و3 ساعات على 15m.

**هل هذا ICT؟** الفكرة (wick beyond + close back) صحيحة كحدث خام. لكن تسميتها "genuine reversal" بلا displacement/MSS ليست ICT كاملة. مايكل ينتظر displacement بعد السحب.

---

## المرحلة 5: Displacement

### `compute_displacement()` — ict_math_engine.py:79
**الحكم: UNSOURCED-HEURISTIC + ICT-PARTIAL**

```python
is_displacement = (body_atr_ratio >= 1.5) and (body_pct >= 0.65)
```

**ما هو صحيح:**
- يتطلب جسماً قوياً وإغلاقاً اتجاهياً — المفهوم العام صحيح.
- حتمي ولا يستخدم المستقبل.

**ما هو مشكلة:**
1. **1.5 و65% أرقام غير مثبتة من مايكل**. المصدر المذكور (FibAlgo, backtrex) هي أدوات طرف ثالث.
2. **ATR يتضمن الشمعة نفسها**: شمعة كبيرة ترفع ATR فتُضعف نسبتها الخاصة.
3. **لا يشترط imbalance (FVG) ناتجة**: displacement حقيقي عند مايكل يترك فجوة سعرية.
4. **لا يشترط كسر مستوى أو repricing**: شمعة كبيرة بسبب خبر عشوائي ≠ displacement مؤسساتي.
5. **لا يربطه بالسيولة أو القصة الأكبر**.

---

## المرحلة 6: FVG (Fair Value Gap)

### `detect_fair_value_gaps()` — ict_math_engine.py:149
**الحكم: ICT-MATCH (التكوين) + LIFECYCLE-INCOMPLETE**

**ما هو صحيح (مطابق مايكل):**
- Bullish: `low[candle3] > high[candle1]` ✅
- Bearish: `high[candle3] < low[candle1]` ✅
- CE = midpoint ✅
- `require_displacement=True` افتراضياً ✅ (لكن يُمرر `False` من عدة أماكن!)

**ما هو مشكلة حرجة:**
1. **لا `is_active` أو `invalidated`**: FVG ممتلئة 100% تبقى ضمن المرشحات.
2. **لا `formed_at_ts`، `first_touch_ts`، `fully_filled_at_ts`**: بلا دورة حياة.
3. **`filled_pct` يُحسب لكنه لا يُستخدم كفلتر**: المستدعون يأخذون أي FVG.
4. **`require_displacement=False` يُستخدم في أماكن كثيرة**: Order Blocks (سطر 270)، GENERIC_FALLBACK (سطر 1424)، Models B/D/E (سطور 183, 449, 1007, 1157, 1424). هذا يقبل FVG بلا displacement — يخالف ما يقوله مايكل في Episode 6.

---

## المرحلة 7: Order Block

### `detect_order_blocks()` — ict_math_engine.py:251
**الحكم: DOCUMENTATION-FALSE + OVERPERMISSIVE**

**التعليق يقول 4 شروط إلزامية:**
1. Touch extreme ✅ (مطبق)
2. Close engulf ✅ (مطبق)
3. FVG مرتبطة ❌ (**يُحسب `fvg_nearby` لكنه ليس شرطاً!** سطر 293: `if touched_low and closed_above` — بلا fvg_nearby)
4. MSS ❌ (**غير مطبق إطلاقاً داخل الدالة**)

**نتيجة:** كل engulf pair يُقبل كـOB. التعليق يكذب على القارئ.

**مشاكل إضافية:**
- **لا invalidation**: OB أُغلق خلف حدها تبقى صالحة للأبد.
- **لا mitigation tracking**: OB اختُبرت 5 مرات تبقى "جديدة".
- **`_count_retests` يعد لمسات لكنه لا يؤثر في القرار**.

---

## المرحلة 8: MSS (Market Structure Shift)

### `detect_mss()` — ict_math_engine.py:576
**الحكم: MISNAMED + OVERGENERATING**

**ما تفعله فعلياً:** تكتشف **كل** إغلاق يتجاوز **أي** swing محلي. ليست MSS تحديداً.

**مشاكل:**
1. **لا تميز MSS من BOS من CHoCH**: كلها "breaks_found".
2. **تعيد عدة أحداث متداخلة لنفس حركة السعر**.
3. **`breaks[-1]` = آخر عنصر برمجي، ليس بالضرورة أهم break**.
4. **`prior_sweep` قد يكون sweep لسوينغ سابق لا علاقة له بالكسر الحالي**.
5. **اسمها `detect_mss` لكن التعليق (سطر 578-590) يعترف أنها ليست MSS**.

**هل هذا ICT؟** MSS عند مايكل = تسلسل محدد: Liquidity raid → Displacement → Close through short-term swing. هذه الدالة تكتشف الشق الأخير فقط (close through swing) بلا سياق.

---

## المرحلة 9: OTE (Optimal Trade Entry)

### `compute_premium_discount()` — ict_math_engine.py:883
**الحكم: ICT-MATCH (OTE zones) + IMPLEMENTATION-BUG (retracement_pct)**

**ما هو صحيح:**
- Equilibrium = 50% ✅
- Bullish OTE = مقاس من القمة نزولاً ✅
- Bearish OTE = مقاس من القاع صعوداً ✅

**🔴 خطأ مثبت:**
```python
retracement_pct = (swing_high_price - current_price) / rng * 100  # سطر 919
```
هذا يُحسب دائماً من القمة نزولاً بغض النظر عن الاتجاه. في Bearish setup: Low=0, High=100, Price=78.6 → يرجع 21.4% بدل 78.6%.

**`in_ote_zone` صحيح** — المشكلة فقط في `retracement_pct` كرقم معروض.

---

## المرحلة 10: نماذج الدخول (Models A–F)

### `evaluate_all_entry_models()` — ict_entry_checklist_engine.py

**الحكم العام: CONFLICT + UNSOURCED-PRIORITY**

**ترتيب الأفضلية:**
```
Model B → Model A → Model C → Models D/E/F → GENERIC_STRUCTURAL_FALLBACK
```
هذا الترتيب **غير مثبت كتعريف رسمي من مايكل**.

### 🔴 `GENERIC_STRUCTURAL_FALLBACK` (سطر 1398):
- **لا يزال يرجع `status: "READY"`** (سطر 1559).
- **يفتح صفقات** بمجرد وجود أي OB أو FVG بجهة الانحياز.
- **ليس نموذج ICT**: التعليق نفسه يعترف (سطر 1545: "no named entry model qualified").
- **يضع `LTF_CONFIRMATION_CHOCH_OR_BOS: True`** بلا فحص (سطر 1555: "assumed true as fallback").

### 🔴 Model B — خطأ Index السالب (سطر 386):
```python
candle_ts = ts[res["idx"]] if (0 <= res["idx"] < len(ts)) else None
```
`find_recent_sweep` يرجع `idx` سالب دائماً (مثل `-3`). الشرط `0 <= -3` يفشل → `sweep_candle_ts = None` → يفترض أن السحب حصل على آخر شمعة 5m → **كل الربط الزمني خاطئ**.

### 🔴 `FVG_FROM_DISPLACEMENT` — ربط وهمي:
```python
fvgs = detect_fair_value_gaps(data, lookback=lookback, require_displacement=False)  # سطر 449
```
الاسم يقول "from displacement" لكن `require_displacement=False`! يقبل أي FVG بعد sweep index بغض النظر عن علاقتها بالـdisplacement.

### `is_executable_model()` — algo_master.py:68:
- **يتجاوز شروط PENDING** إذا كانت في `_NON_BLOCKING_PENDING`:
  - `ACTIVE_KILL_ZONE_TIMING` — مقبول (يُعالج ببوابة Session).
  - `LTF_CONFIRMATION_CHOCH_OR_BOS` — **خطير**: هذا تأكيد هيكلي حقيقي، وتجاوزه يعني الدخول بلا تأكيد.
  - `HTF_CONTEXT_AT_PD_ARRAY` — **خطير**: السياق الأعلى مفقود ويُتجاوز.

---

## المرحلة 11: Entry / SL / TP

### الدخول:
**الحكم: UNSOURCED-METHOD**

- الدخول يُحسب من `chosen_zone["price"]` (منتصف OB أو CE الـFVG).
- مايكل في 2022 Episode 6 (17:21-17:30): "الدخول عند حد FVG قرب high الشمعة الثالثة". وفي (35:45-36:04): "tick واحد بعد الحد".
- **المشروع يدخل عند CE (المنتصف)**، مايكل يذكر الحد (edge). فرق.

### الستوب:
**الحكم: ICT-PARTIAL**

- `find_structural_sl_anchors` تجمع OB edges + swings + sweep points — **المفهوم صحيح**.
- مايكل في Episode 6 (27:18-27:30): "الستوب فوق extreme أو swing high".
- **المشكلة:** الـswings المستخدمة تعتمد على `detect_significant_swings` (topographic prominence) بدل تعريف مايكل الرسمي بثلاث شموع.

### الأهداف:
### `find_tp_targets()` — ict_math_engine.py:1277
**الحكم: ICT-PARTIAL + UNSOURCED-BUFFER + FIB-RISK**

**ما هو صحيح:**
- يبحث عن مستويات هيكلية حقيقية (EQH/EQL, Swing, OB) — مفهوم صحيح.
- لا يقبل هدف بلا R:R ≥ 2 — منطقي.

**مشاكل:**
1. **Target buffer ثابت 0.15%** (سطر 1417): `offset = level_price * 0.0015`. هذا رقم مخترع. قد يكون كبيراً جداً على أصول رخيصة أو صغيراً جداً على BTC.
2. **Fib -0.27 لا يزال هدفاً تنفيذياً** (سطر 1381): `kind: "ICT_FIB_-0.27"`. هذا مقاس وليس مستوى سيولة مرصود.
3. **يتخطى الهدف القريب لصناعة R:R أفضل**: الترتيب بـ`_pref_rank` يعطي أولوية لـEQH/EQL ثم OB ثم swings. قد يتخطى swing قريب (R:R 1.8) ويأخذ EQH بعيد (R:R 3.5). مايكل يقول: "أقرب هدف" (Episode 2, 48:02).
4. **لا فحص هندسة**: Long مع SL فوق Entry لا يُرفض.

---

## المرحلة 12: إدارة الصفقة (Live)

### `manage_active_trade()` — algo_master.py:509
**الحكم: ICT-PARTIAL + IMPLEMENTATION-BUGS**

**ما هو صحيح:**
- TP1 عند 50% ثم BE — مطابق ICT ✅
- Structural trailing خلف آخر swing — المفهوم صحيح ✅

**مشاكل حرجة:**
1. **TP1 والـSL في نفس الشمعة**: لا يعرف أيهما حصل أولاً. الكود يفحص SL أولاً (سطر 524/555) — سياسة متحفظة مقبولة. **لكن لا يوجد معالجة صريحة** لهذه الحالة.
2. **`1.5 * risk` BE** (سطر 540/571): إذا وصل السعر 1.5R بلا TP1 → ينقل SL لـBE. **هذا غير موثق عند مايكل**. مايكل ينقل BE عند TP1 فقط.
3. **Trailing يستخدم `swing_window=2`** (5 شموع) بدل 3 شموع ICT.
4. **`buffer = risk * 0.1`** (سطر 552/583): buffer الستوب المتحرك = 10% من المخاطرة الأصلية. **رقم مخترع**.
5. **لا حفظ حالة**: إذا أُعيد تشغيل البوت → تضيع الصفقات المفتوحة.
6. **لا يفحص هل السعر لمس الدخول فعلاً**: يفترض الدخول حصل (limit order).

---

## المرحلة 13: الباكتيست

### `simulate_managed_trade_outcome()` — ict_math_engine.py:1664
**الحكم: IMPLEMENTATION-PARTIAL + LOOKAHEAD-RISK**

**ما هو صحيح:**
- يبحث عن أول لمسة للدخول ✅
- يتعامل مع TP/SL على شمعة الدخول بحذر (OHLC path approximation) ✅
- TP1+SL في نفس الشمعة → يفترض SL أولاً (محافظ) ✅

**مشاكل:**
1. **Swing confirmation**: يعتبر swing مؤكداً عند `i` لكن **confirmation يحتاج شمعتين بعده** (`swing_window=2`). الـswing عند index `i` يُسجل عند index `i`، بينما الواقع يتأكد عند `i+2`. **هذا lookahead**.
2. **TP2+trailing_stop في نفس الشمعة** (سطر 1842-1843): يفترض TP2 حصل أولاً — **متفائل**. يجب أن يكون محافظاً (trailing stop).
3. **`NEITHER_HIT_WITHIN_WINDOW`**: يستخدم `closes[-1]` — غير واضح إذا كان هذا هو السعر الأخير أو سعر اعتباطي.

---

## 📊 ملخص التصنيفات

| الدالة | الفكرة ICT؟ | التطبيق صحيح؟ | الحكم |
|--------|------------|--------------|-------|
| `fetch_all_tf` | هندسة | ❌ خطأ | ERROR-HIDING |
| `analyze_bias` | ICT-PARTIAL | ❌ 4H/Weekly ميتان | DISPLAY-ONLY |
| `compute_mechanical_bias_anchor` | ICT-PARTIAL | ⚠️ ناقص | CONTEXT-BLIND |
| `analyze_liquidity_map` | ICT-PARTIAL | ❌ swings غلط | UNSOURCED |
| `classify_sweep_or_run` | ICT-PARTIAL | ❌ أول breach | IMPLEMENTATION-BUG |
| `find_recent_sweep` | ICT-PARTIAL | ⚠️ تكرار | CONFLICT |
| `compute_displacement` | ICT-PARTIAL | ⚠️ عتبات | UNSOURCED-HEURISTIC |
| `detect_fair_value_gaps` | **ICT-MATCH** (تكوين) | ❌ بلا lifecycle | LIFECYCLE-INCOMPLETE |
| `detect_order_blocks` | DOCUMENTATION-FALSE | ❌ شرطين من 4 | OVERPERMISSIVE |
| `detect_mss` | MISNAMED | ❌ كل break | OVERGENERATING |
| `compute_premium_discount` | **ICT-MATCH** (zones) | ❌ bearish % | IMPLEMENTATION-BUG |
| `evaluate_model_b` | ICT-PARTIAL | ❌ idx bug | IMPLEMENTATION-BUG |
| `GENERIC_FALLBACK` | ❌ ليس ICT | يفتح صفقات | UNSOURCED |
| `find_tp_targets` | ICT-PARTIAL | ⚠️ buffer/fib | UNSOURCED-BUFFER |
| `manage_active_trade` | ICT-PARTIAL | ⚠️ 1.5R BE | UNSOURCED |
| `simulate_managed_trade_outcome` | هندسة | ⚠️ lookahead | LOOKAHEAD-RISK |

---

## 🔴 أخطر 10 مشاكل بالترتيب

1. **Index السالب في Model B** → كل ربط زمني sweep/displacement/FVG خاطئ
2. **`classify_sweep_or_run` يرجع أول breach** → قد يختار Run قديم بدل Sweep حديث
3. **`GENERIC_STRUCTURAL_FALLBACK` يفتح صفقات** → بلا نموذج ICT
4. **FVG بلا lifecycle** → دخول على FVG مستهلكة
5. **OB بلا invalidation** → دخول على OB منكسرة
6. **Swings تستخدم topographic prominence** بدل تعريف مايكل (3 شموع)
7. **`FVG_FROM_DISPLACEMENT` يقبل أي FVG** → ربط وهمي بالـdisplacement
8. **Weekly/4H لا يدخلان في القرار** → ادعاء Top-Down وهمي
9. **لا حفظ حالة الصفقة** → restart = فقدان صفقات
10. **Bearish retracement_pct خاطئ** → عرض مضلل

---

## ✅ ما هو صحيح فعلاً ومطابق ICT

1. **تكوين FVG الثلاثي** (low[3] > high[1]) — حقيقة رياضية صحيحة
2. **OTE zones** (61.8%–78.6%) — مطابق مايكل
3. **Wick beyond + close back** — الحدث الخام صحيح
4. **TP1 50% + BE** — مطابق مايكل
5. **Structural SL** (المفهوم) — صحيح
6. **تحويل الوقت NY + DST** — صحيح تقنياً
7. **Kill Zone gate** — المفهوم صحيح (لكن الأوقات مكيّفة للكريبتو)

---

*هذا التقرير مبني على قراءة كل سطر بالملفات الأصلية. لم أُضف أي حكم بدون إثبات من الكود نفسه. الأرقام والأسطر مذكورة للتحقق.*
