import sys, time, datetime, os
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session
import pytz

brain = BrainCore()
ae = AuthenticityEngine()
ny_tz = pytz.timezone('America/New_York')

WATCHING_SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

def print_banner(msg):
    print(f"\n{'='*85}\n  {msg}\n{'='*85}")

def run_live_autonomous():
    account = ACCOUNT_BALANCE
    active_trades = {}
    ignored_signals = set()
    
    print_banner(f"🟢 تشغيل صندوق التحوط الآلي (Fully Autonomous ICT Bot) | الرصيد: {account}$ | المخاطرة: 1%")
    
    while True:
        try:
            now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)
            curr_session = classify_session(int(time.time()*1000)).get("session", "UNKNOWN")
            
            print_banner(f"📡 رادار المسح والتتبع اللحظي | توقيت نيويورك: {now_ny.strftime('%H:%M:%S')} | الجلسة: {curr_session}")
            print(f"💰 رصيد الحساب اللحظي: {account:.2f}$")
            print("-" * 85)

            # ==========================================
            # 1. إدارة الصفقات המفتوحة (Trade Management)
            # ==========================================
            for symbol in list(active_trades.keys()):
                t = active_trades[symbol]
                data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=20)
                if not data_5m or not data_5m['closes']: continue
                
                h, l, c = data_5m['highs'][-1], data_5m['lows'][-1], data_5m['closes'][-1]
                entry, sl, tp1, risk = t['entry'], t['sl'], t['tp1'], t['risk']
                is_short, size, risk_usd = t['is_short'], t['size'], t['risk_usd']
                
                print(f"👁️ أتابع صفقة {symbol} | السعر: {c:.4f} | الستوب المحمي: {t['current_sl']:.4f}")
                
                if is_short:
                    # فحص الستوب
                    if h >= t['current_sl']:
                        if t['current_sl'] == sl:
                            account -= risk_usd
                            print(f"   ❌ السعر ضرب الستوب لوس! خسارة: {-risk_usd:.2f}$ | الرصيد الجديد: {account:.2f}$")
                        elif t['current_sl'] == entry:
                            print(f"   🛡️ السعر ارتد لـ Break-Even. خرجنا بأمان בצفر خسارة | الرصيد: {account:.2f}$")
                        else:
                            profit = (entry - t['current_sl']) * size * (0.5 if t['tp1_hit'] else 1.0)
                            account += profit
                            print(f"   🧠 السعر كسر الهيكل المتتبع! خروج بأرباح: +{profit:.2f}$ | الرصيد: {account:.2f}$")
                        del active_trades[symbol]
                        continue
                        
                    # فحص الهدف الأول (Partials)
                    if l <= tp1 and not t['tp1_hit']:
                        profit_50 = (abs(tp1 - entry) * size) * 0.5
                        account += profit_50
                        t['tp1_hit'], t['be_activated'], t['current_sl'] = True, True, entry
                        print(f"   🎯 ضربنا الهدف الأول! جنينا 50% من الأرباح (+{profit_50:.2f}$). الستوب عالدخول (BE) ونلاحق بالباقي!")
                        
                    # تأمين 1.5R
                    if l <= (entry - 1.5*risk) and not t['be_activated']:
                        t['be_activated'], t['current_sl'] = True, entry
                        print(f"   🛡️ السعر هبط 1.5R. تم تأمين الصفقة عالدخول.")
                        
                    # تتبع هيكلي 
                    if len(data_5m['highs']) >= 3 and data_5m['highs'][-2] > data_5m['highs'][-3] and data_5m['highs'][-2] > data_5m['highs'][-1]:
                        swing_high = data_5m['highs'][-2]
                        if l < data_5m['lows'][-2] and swing_high < t['current_sl'] and t['be_activated']:
                            t['current_sl'] = swing_high + (risk * 0.1)
                            print(f"   🧠 تشكلت قمة هابطة جديدة! حركت الستوب إلى {t['current_sl']:.4f} لأحصر السعر.")
                else: # LONG
                    if l <= t['current_sl']:
                        if t['current_sl'] == sl:
                            account -= risk_usd
                            print(f"   ❌ السعر ضرب الستوب لوس! خسارة: {-risk_usd:.2f}$ | الرصيد الجديد: {account:.2f}$")
                        elif t['current_sl'] == entry:
                            print(f"   🛡️ السعر ارتد لـ Break-Even. خرجنا بأمان בצفر خسارة | الرصيد: {account:.2f}$")
                        else:
                            profit = (t['current_sl'] - entry) * size * (0.5 if t['tp1_hit'] else 1.0)
                            account += profit
                            print(f"   🧠 السعر كسر الهيكل المتتبع! خروج بأرباح: +{profit:.2f}$ | الرصيد: {account:.2f}$")
                        del active_trades[symbol]
                        continue
                        
                    if h >= tp1 and not t['tp1_hit']:
                        profit_50 = (abs(tp1 - entry) * size) * 0.5
                        account += profit_50
                        t['tp1_hit'], t['be_activated'], t['current_sl'] = True, True, entry
                        print(f"   🎯 ضربنا الهدف الأول! جنينا 50% من الأرباح (+{profit_50:.2f}$). الستوب عالدخول (BE) ونلاحق بالباقي!")
                        
                    if h >= (entry + 1.5*risk) and not t['be_activated']:
                        t['be_activated'], t['current_sl'] = True, entry
                        print(f"   🛡️ السعر صعد 1.5R. تم تأمين الصفقة עالدخول.")
                        
                    if len(data_5m['lows']) >= 3 and data_5m['lows'][-2] < data_5m['lows'][-3] and data_5m['lows'][-2] < data_5m['lows'][-1]:
                        swing_low = data_5m['lows'][-2]
                        if h > data_5m['highs'][-2] and swing_low > t['current_sl'] and t['be_activated']:
                            t['current_sl'] = swing_low - (risk * 0.1)
                            print(f"   🧠 تشكل قاع صاعد جديد! حركت الستوب إلى {t['current_sl']:.4f} لأحصر السعر.")

            # ==========================================
            # 2. مسح السوق للفرص الجديدة (Scanner)
            # ==========================================
            for symbol in WATCHING_SYMBOLS:
                if symbol in active_trades: continue # لا تبحث عن صفقة جديدة لعملة نتداولها بالفعل
                
                data_1d = brain.data_manager.fetch_ohlcv_up_to(symbol, "1d", int(time.time()*1000), limit=100)
                if not data_1d or not data_1d['closes']: continue
                bias = compute_mechanical_bias_anchor(data_1d, lookback=60).get("anchor_direction")
                
                data_15m = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", int(time.time()*1000), limit=200)
                if not data_15m or not data_15m['closes']: continue
                current_p = data_15m['closes'][-1]
                closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}
                
                if bias not in ["BULLISH", "BEARISH"]:
                    
                    continue
                    
                sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)
                valid_target = None
                ttype = ""
                recent_sweep_found = False
                swept_price = 0.0
                n_15m = len(closed_15m['closes'])
                
                if bias == "BULLISH":
                    lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    lows = []
                    check_idx = n_15m - 1
                    for s in lows_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
                            if min_before < s['price']: continue
                        lows.append(s)
                    if lows:
                        lows.sort(key=lambda x: current_p - x['price'])
                        valid_target = lows[0]
                        ttype = "قاع سيولة (SSL)"
                        
                    for s in sig.get("all_lows_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                min_recent = min(closed_15m['lows'][check_start : n_15m])
                                if min_recent < s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                                            recent_sweep_found = True
                                            swept_price = s['price']
                                            break
                        if recent_sweep_found: break
                else:
                    highs_raw = [s for s in sig.get("all_highs_tiered", []) if s['price'] > current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
                    highs = []
                    check_idx = n_15m - 1
                    for s in highs_raw:
                        s_idx = n_15m + s['index_from_end']
                        if s_idx < check_idx - 1:
                            max_before = max(closed_15m['highs'][s_idx+1 : check_idx])
                            if max_before > s['price']: continue
                        highs.append(s)
                    if highs:
                        highs.sort(key=lambda x: x['price'] - current_p)
                        valid_target = highs[0]
                        ttype = "قمة سيولة (BSL)"
                        
                    for s in sig.get("all_highs_tiered", []):
                        if s.get("tier") in ["MAJOR", "MODERATE"]:
                            s_idx = n_15m + s['index_from_end']
                            check_start = max(s_idx + 1, n_15m - 10)
                            if check_start < n_15m:
                                max_recent = max(closed_15m['highs'][check_start : n_15m])
                                if max_recent > s['price']:
                                    for i in range(check_start, n_15m):
                                        if closed_15m['highs'][i] > s['price'] and closed_15m['closes'][i] < s['price']:
                                            recent_sweep_found = True
                                            swept_price = s['price']
                                            break
                        if recent_sweep_found: break

                print(f"\n{'='*60}")
                print(f"🪙 تحليل الزوج: {symbol} | السعر اللحظي: {current_p:.4f}")
                print(f"📅 فريم اليوم (1D) -> الاتجاه العام: {'شراء صاعد 🟢 (BULLISH)' if bias == 'BULLISH' else 'بيع هابط 🔴 (BEARISH)'}")

                if recent_sweep_found:
                    print(f"🔍 فريم الربع ساعة (15m) -> ⚡ رصدت سحب سيولة قوي للتو!")
                    print(f"   لقد قام السعر بضرب مستوى السيولة {'(SSL)' if bias == 'BULLISH' else '(BSL)'} عند السعر [{swept_price:.4f}]، ثم ارتد وأغلق بنجاح (Sweep).")
                    print(f"   الآن أغوص لفريم الـ (5m) لفحص هيكل الدخول (Models)...")
                    
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                    res_5m = evaluate_all_entry_models(data_5m, bias)
                    
                    chosen = res_5m.get("chosen_model")
                    if chosen:
                        status_arb = "جاهز للدخول 🚀" if chosen['status'] == "READY" else "قيد التشكل والانتظار ⏳"
                        print(f"\n🎯 الموديل المعتمد: {chosen.get('model')} | الحالة: {status_arb}")
                        print("📋 شروط الموديل التفصيلية:")
                        for cond in chosen.get("conditions", []):
                            status_ico = "✅ تحقق" if cond['status'] == True else ("❌ لم يتحقق" if cond['status'] == False else "⏳ قيد الانتظار")
                            print(f"   {status_ico} | {cond['name']}: {cond['detail']}")
                            
                    if res_5m.get("final_status") == "READY":
                        plan = res_5m.get("chosen_model", {}).get("plan", {})
                        entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                        if entry and sl and tp1:
                            risk_dist = abs(entry - sl)
                            risk_usd = account * RISK_PCT
                            pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                            
                            print_banner(f"🔥 تم الدخول في الصفقة آلياً! {symbol} 🔥")
                            print(f"الاتجاه: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'} | النموذج: {res_5m.get('chosen_model',{}).get('model')}")
                            print(f"نقطة الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف (50%): {tp1:.4f}")
                            print(f"حجم العقد: {pos_size:.4f} | المخاطرة المحسوبة: {risk_usd:.2f}$")
                            
                            active_trades[symbol] = {
                                "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                "risk_usd": risk_usd
                            }
                    else:
                        print("\n⏳ الخلاصة: الموديل لم يكتمل بعد. أراقب الشارت بانتظار الشروط المتبقية (مثلاً: فجوة FVG أو إغلاق تأكيدي).")
                    
                    print(f"{'='*60}\n")
                    continue
                
                if not valid_target:
                    print(f"🔍 فريم الربع ساعة (15m) -> 👁️ أراقب. لا توجد فخاخ سيولة غير ملموسة أعلى/أسفل السعر حالياً.")
                    print(f"{'='*60}\n")
                    continue
                    
                target_lvl = valid_target['price']
                dist = abs(current_p - target_lvl)
                print(f"🔍 فريم الربع ساعة (15m) -> 🎯 أنتظر بصمت أن يقوم السعر بضرب {ttype} غير الملموس عند السعر [{target_lvl:.4f}] (يبعد عنا {dist:.4f}$).")
                print(f"{'='*60}\n")


                res = classify_sweep_or_run(closed_15m, target_lvl, level_is_high=(bias=="BEARISH"), check_from_idx=len(closed_15m['closes'])-1)
                
                if res.get("classification") == "LIQUIDITY_RUN_CONTINUATION":
                    pass
                elif res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                    if curr_session not in ["LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"]:
                        print(f"🪙 {symbol:<9} | الجلسة ميتة ({curr_session}). لا دخول.")
                        continue
                        
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                    res_5m = evaluate_all_entry_models(data_5m, bias)
                    
                    if res_5m.get("final_status") == "READY":
                        plan = res_5m.get("chosen_model", {}).get("plan", {})
                        entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                        if entry and sl and tp1:
                            risk_dist = abs(entry - sl)
                            risk_usd = account * RISK_PCT
                            pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                            
                            print_banner(f"🔥 تم الدخول في الصفقة آلياً! {symbol} 🔥")
                            print(f"الاتجاه: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'} | النموذج: {res_5m.get('chosen_model',{}).get('model')}")
                            print(f"نقطة الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف (50%): {tp1:.4f}")
                            print(f"חجم العقد: {pos_size:.4f} | المخاطرة المحسوبة: {risk_usd:.2f}$")
                            
                            active_trades[symbol] = {
                                "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                "risk_usd": risk_usd
                            }
                    else:
                        print(f"🪙 {symbol:<9} | 🚨 تم سحب السيولة عند {target_lvl:.4f}! | ⏳ أغوص لفريم 5m لأنتظر الفجوة (FVG).")
                else:
                    pass

            time.sleep(60) # تحديث כל דقيقة!
        except KeyboardInterrupt:
            print(f"\nتم الإيقاف اليدوي. الرصيد النهائي: {account:.2f}$")
            sys.exit(0)
        except Exception as e:
            time.sleep(10)

if __name__ == "__main__":
    print_banner("ICT Algo Master 🤖 - Ultimate Autonomous Edition")
    run_live_autonomous()
