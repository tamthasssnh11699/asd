import re

def insert_state_machine_algo(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    new_logic = """                        if recent_sweep_found and not valid_target:
                            print(f"🪙 {symbol:<9} | السعر: {current_p:.4f} | 🧭 {bias:<7} | ⚡ حدث سحب سيولة مؤخراً! أغوص لفريم 5m لأنتظر تشكل فجوة FVG للدخول.")
                            
                            data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                            res_5m = evaluate_all_entry_models(data_5m, bias)
                            
                            if res_5m.get("final_status") == "READY":
                                plan = res_5m.get("chosen_model", {}).get("plan", {})
                                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                                if entry and sl and tp1:
                                    risk_dist = abs(entry - sl)
                                    risk_usd = account * RISK_PCT
                                    pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                                    
                                    print_banner(f"🔥 تم الدخول في الصفقة آلياً! {symbol} 🔥")
                                    print(f"الاتجاه: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'} | النموذج: {res_5m.get('chosen_model',{}).get('model')}")
                                    print(f"نقطة الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف (50%): {tp1:.4f}")
                                    print(f"حجم العقد: {pos_size:.4f} | المخاطرة المحسوبة: {risk_usd:.2f}$")
                                    
                                    active_trades[symbol] = {
                                        "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                        "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                        "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                        "risk_usd": risk_usd
                                    }
                            continue
                        elif not valid_target:
                            print(f"🪙 {symbol:<9} | السعر: {current_p:.4f} | 🧭 {bias:<7} | 👁️ أراقب. لا توجد فخاخ غير ملموسة أسفل/أعلى السعر.")
                            continue"""

    # We replace from 'if not valid_target:' to the end of that block in algo_master.py
    # using a safer method.
    pattern = r'(\s*)if not valid_target:\n\s*print\(f"🪙 \{symbol.*'
    
    # Actually, let's just do a string replace on a known block to avoid regex messes.
    
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
        
    out = []
    skip = False
    for line in lines:
        if "if not valid_target:" in line and "print" not in line:
            # We are at the block we added in fix_state_machine.py
            # wait, that block is weird now. Let's just fix algo_master directly.
            pass
            
insert_state_machine_algo("algo_master.py")
