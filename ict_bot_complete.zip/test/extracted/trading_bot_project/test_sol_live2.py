import sys, time
sys.path.insert(0, ".")
from data_manager import DataManager
from authenticity_engine import AuthenticityEngine
from ict_math_engine import compute_mechanical_bias_anchor

dm = DataManager()
data_15m = dm.get_ohlcv("SOLUSDT", "15m", 200, output_format="dict")
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}
current_p = data_15m['closes'][-1]
ae = AuthenticityEngine()
sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)

bias = "BULLISH"

lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
lows = []
n_closes = len(closed_15m['closes'])
check_idx = n_closes - 1
for s in lows_raw:
    s_idx = n_closes + s['index_from_end']
    if s_idx < check_idx - 1:
        min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
        if min_before < s['price']:
            continue
    lows.append(s)

valid_target = None
if lows:
    lows.sort(key=lambda x: current_p - x['price'])
    valid_target = lows[0]
    ttype = "قاع سيولة (SSL)"

recent_sweep_found = False
for s in sig.get("all_lows_tiered", []):
    if s.get("tier") in ["MAJOR", "MODERATE"]:
        s_idx = n_closes + s['index_from_end']
        check_start = max(s_idx + 1, n_closes - 10)
        if check_start < n_closes:
            min_recent = min(closed_15m['lows'][check_start : n_closes])
            if min_recent < s['price']:
                for i in range(check_start, n_closes):
                    if closed_15m['lows'][i] < s['price'] and closed_15m['closes'][i] > s['price']:
                        recent_sweep_found = True
                        break
        if recent_sweep_found: break

print(f"valid_target: {valid_target}")
print(f"recent_sweep_found: {recent_sweep_found}")

if not valid_target and recent_sweep_found:
    print("⚡ حدث سحب سيولة مؤخراً! أغوص لفريم 5m لأنتظر تشكل فجوة FVG للدخول.")
elif not valid_target:
    print("👁️ أراقب. لا توجد فخاخ غير ملموسة أسفل/أعلى السعر.")
else:
    print("🎯 أنتظر ضرب قاع سيولة")

