import json, datetime, sys, time
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session
import pytz

brain = BrainCore()
ae = AuthenticityEngine()
ny_tz = pytz.timezone('America/New_York')

SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

print("="*90)
print("🎯 جاري تشغيل الباكتيست (Pro Sniper Mode) - الشفافية المطلقة والـ Circuit Breaker")
print("="*90)

# جلب البيانات
market_data = {}
for sym in SYMBOLS:
    market_data[sym] = brain.data_manager.get_ohlcv(sym, "15m", 3500, output_format="dict")

n = len(market_data["BTC/USDT"]["closes"])
start_idx = max(500, n - 2880) # 30 يوماً

account = ACCOUNT_BALANCE
daily_losses = {} # Circuit Breaker
active_trade_end_ts = 0 # Correlation Filter
results = []

for i in range(start_idx, n, 2): # فحص شمعة بشمعة
    current_ts = market_data["BTC/USDT"]["timestamps"][i]
    dt_utc = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
    day_str = dt_utc.strftime('%Y-%m-%d')
    
    # 1. Circuit Breaker
    if daily_losses.get(day_str, 0) >= 2:
        continue # خسرنا مرتين اليوم، أوقف التداول!
        
    # 2. Correlation Filter (لا تدخل إذا كان هناك صفقة شغالة)
    if current_ts < active_trade_end_ts:
        continue
        
    # 3. Session Filter (Killzones Only)
    sess = classify_session(current_ts).get("session", "")
    if sess not in ["LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"]:
        continue

    # البحث عن فرصة في العملات
    for sym in SYMBOLS:
        data = market_data[sym]
        window_data = {k: v[:i+1] for k, v in data.items() if isinstance(v, list)}
        
        try:
            anchor = compute_mechanical_bias_anchor(window_data, lookback=150)
            bias = anchor.get("anchor_direction")
            if bias not in ["BULLISH", "BEARISH"]: continue
            
            # قمم وقيعان قوية فقط (swing_window=3)
            sig = ae.detect_significant_swings(window_data, swing_window=3, lookback_candles=150)
            levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
            
            is_swept = False
            swept_level = 0
            for cand in levels:
                if cand.get("tier") not in ["MAJOR", "MODERATE"]: continue
                res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=i)
                if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                    is_swept, swept_level = True, cand["price"]
                    break
                    
            if is_swept:
                data_5m = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", current_ts, limit=150)
                res_5m = evaluate_all_entry_models(data_5m, bias)
                if res_5m.get("final_status") in ["READY", "PENDING_SETUP"]:
                    plan = res_5m.get("chosen_model", {}).get("plan", {})
                    entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                    
                    if entry and sl and tp1:
                        risk_dist = abs(entry - sl)
                        tp1_dist = abs(tp1 - entry)
                        if risk_dist == 0: continue
                        
                        # 4. Strict R:R Filter (ممنوع الدخول إذا كان الهدف يعطي أقل من 2.5R)
                        rr_expected = tp1_dist / risk_dist
                        if rr_expected < 2.5:
                            # البوت يرفض الصفقة
                            continue
                        
                        is_short = (bias == "BEARISH")
                        
                        # طباعة تحليل الشموع التفصيلي للمستخدم لكي لا يظنه يغش
                        print(f"\n{'='*70}")
                        print(f"🎯 فرصة قناص مكتشفة: {sym} | التاريخ: {dt_utc.strftime('%Y-%m-%d %H:%M UTC')}")
                        print(f"🧭 الاتجاه: {bias} | الجلسة: {sess}")
                        print(f"🪤 تم سحب سيولة عند: {swept_level}")
                        print(f"📏 R:R المتوقع للهدف: {rr_expected:.2f} (تم قبول الصفقة لأنها > 2.5R)")
                        print(f"   [الدخول: {entry:.2f} | الستوب: {sl:.2f} | الهدف: {tp1:.2f}]")
                        
                        print("\n📊 شموع الـ 15 دقيقة التي أكدت السحب (آخر 3 شموع):")
                        for j in range(-3, 0):
                            o, h, l, c = window_data['opens'][j], window_data['highs'][j], window_data['lows'][j], window_data['closes'][j]
                            print(f"   O:{o:.2f} | H:{h:.2f} | L:{l:.2f} | C:{c:.2f}")

                        # محاكاة المستقبل
                        f_data = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", current_ts + 24*3600*1000, limit=288)
                        c_sl, be, tp_hit, entry_hit = sl, False, False, False
                        outcome = "OPEN"
                        exit_price = entry
                        
                        for j in range(5, len(f_data['closes'])):
                            h, l = f_data['highs'][j], f_data['lows'][j]
                            if is_short:
                                if h >= entry and not entry_hit: entry_hit = True
                                if not entry_hit: continue
                                
                                if l <= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                if l < (entry - 1.5*risk) and not be: c_sl, be = entry, True
                                
                                if h >= c_sl:
                                    exit_price = c_sl
                                    if c_sl == sl: outcome = "SL_HIT"
                                    elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                    else: outcome = "DYNAMIC_TRAIL_HIT"
                                    active_trade_end_ts = f_data['timestamps'][j]
                                    break
                                    
                                if f_data['highs'][j-1] > f_data['highs'][j-2] and f_data['highs'][j-1] > f_data['highs'][j]:
                                    swing_high = f_data['highs'][j-1]
                                    if l < f_data['lows'][j-1] and swing_high < c_sl and be: c_sl = swing_high + (risk * 0.1) 
                            else:
                                if l <= entry and not entry_hit: entry_hit = True
                                if not entry_hit: continue
                                
                                if h >= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                if h > (entry + 1.5*risk) and not be: c_sl, be = entry, True
                                
                                if l <= c_sl:
                                    exit_price = c_sl
                                    if c_sl == sl: outcome = "SL_HIT"
                                    elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                    else: outcome = "DYNAMIC_TRAIL_HIT"
                                    active_trade_end_ts = f_data['timestamps'][j]
                                    break
                                    
                                if f_data['lows'][j-1] < f_data['lows'][j-2] and f_data['lows'][j-1] < f_data['lows'][j]:
                                    swing_low = f_data['lows'][j-1]
                                    if h > f_data['highs'][j-1] and swing_low > c_sl and be: c_sl = swing_low - (risk * 0.1)

                        if not entry_hit: 
                            outcome = "ENTRY_NEVER_HIT"
                            active_trade_end_ts = current_ts + 2*3600*1000 # تبريد ساعتين إذا لم يتفعل
                            
                        if outcome not in ["OPEN", "ENTRY_NEVER_HIT"]:
                            risk_usd = account * RISK_PCT
                            pos_size = risk_usd / risk if risk > 0 else 0
                            profit = 0.0
                            
                            if outcome == "SL_HIT": 
                                profit = -risk_usd
                                daily_losses[day_str] = daily_losses.get(day_str, 0) + 1
                                print(f"❌ النتيجة: ضرب الستوب! خسارة: {profit:.2f}$")
                            elif outcome == "BREAK_EVEN_HIT": 
                                profit = 0.0
                                print(f"🛡️ النتيجة: خروج عالدخول (Break-Even). لا ربح ولا خسارة.")
                            elif outcome == "TP1_THEN_BE": 
                                # أخذ 50% أرباح عند الهدف الذي يعطي 2.5R أو أكثر
                                profit = (abs(tp1 - entry) * pos_size) * 0.5
                                print(f"🎯 النتيجة: ربح 50% على الهدف الأول ({profit:.2f}$) وضرب الدخول بالباقي.")
                            elif outcome == "DYNAMIC_TRAIL_HIT":
                                base_profit = (abs(tp1 - entry) * pos_size) * 0.5 if tp_hit else 0.0
                                rem_profit = (abs(exit_price - entry) * pos_size) * 0.5
                                profit = base_profit + rem_profit
                                print(f"🧠 النتيجة: تتبع هيكلي! إجمالي الربح: {profit:.2f}$ (خرجنا بالباقي عند {exit_price:.2f})")
                                
                            account += profit
                            results.append({"date": dt_utc.strftime('%Y-%m-%d %H:%M'), "sym": sym, "out": outcome, "profit": profit})
                        break # نخرج من اللوب الداخلي للعملات إذا وجدنا صفقة 
        except Exception: pass

print("\n" + "="*80)
print(f"إحصائيات القناص النهائية (بعد تطبيق R:R > 2.5 و Circuit Breaker)")
print("="*80)
for r in results:
    print(f"{r['date']} | {r['sym']:<8} | {r['out']:<18} | {r['profit']:>6.2f}$")

wins = sum(1 for r in results if r['profit'] > 0)
losses = sum(1 for r in results if r['profit'] < 0)
print(f"\nإجمالي الصفقات: {len(results)}")
print(f"✅ رابحة: {wins} | ❌ خاسرة: {losses}")
print(f"💰 الرصيد النهائي: {account:.2f}$ (النمو: +{((account-100)/100)*100:.2f}%)")
