# 🔑 متى يبقى مايكل ومتى يطلع — القواعد الحقيقية

## القاعدة الأساسية: **ابقَ طالما الهيكل سليم!**

### المصادر الحرفية:

> **"While the market is moving in your favor, continue to trust that move and hold onto your trade."**
> — 2022 Mentorship Notes

> **"If you're bullish, down-closed candles should support price, will act as support structure. Only permissible that they break is if it is a STL and it is taking out some sell-stops to re-accumulate and go higher"**
> — 2022 Mentorship Notes

> **"If your ITH is broken to the upside and you're bearish, your idea was wrong, move to the sidelines. Don't force it."**
> — 2022 Mentorship Notes

> **"Once it fills an FVG, an ITL is created and should not be taken out. Once it starts rallying it shouldn't come back below the ITL."**
> — 2022 Mentorship Notes

> **"Overwhelming uncertainty eats at you even when you are in profit and makes you panic-sell/close out early. Remember that those candles can be filling imbalances so that smart money can accumulate more of their position."**
> — 2022 Mentorship Notes

> **"You must submit to your ideas and watch them come to fruition"**
> — 2022 Mentorship Notes

> **"If you see a longer term price swing set up (on the hourly for example) you should try to hold it out for the move."**
> — 2022 Mentorship Notes

---

## شروط البقاء (ابقَ في الصفقة طالما):

### للصفقة الصعودية (BULLISH):
```
1. Down-closed candles (شموع هابطة) ما بتنكسر
   → "down-closed candles should support price"
   → هاي هي الـbullish order blocks
   → طالما السعر يحترمها = structure سليم

2. ITL (Intermediate Term Low) ما بينكسر بالإغلاق
   → "Once it fills an FVG, an ITL is created and should not be taken out"
   → ITL = low مع higher low على يمينه ويساره
   → كسر ITL بإغلاق = "significant break in market structure"

3. الارتدادات الصغيرة مسموحة!
   → "Only permissible that they break is if it is a STL 
      and it is taking out some sell-stops to re-accumulate"
   → يعني: كسر swing low صغير (STL) عادي — هاد سحب سيولة للتجميع
   → بس كسر ITL = القصة انتهت
```

### للصفقة الهبوطية (BEARISH):
```
1. Up-closed candles (شموع صعودية) ما بتنكسر
   → "up-closed candles should not be breached"
   → "They will act as resistance"

2. ITH (Intermediate Term High) ما بينكسر بالإغلاق
   → "If your ITH is broken to the upside, your idea was wrong"

3. الارتدادات الصغيرة مسموحة!
   → "those candles can be filling imbalances so that 
      smart money can accumulate more"
```

---

## شروط الخروج (اطلع فقط عندما):

```
1. TP2 الذهبي ضُرب → 🏆 إغلاق بربح ضخم

2. ITL/ITH ينكسر بالإغلاق (مش wick!)
   → "break below an ITL = significant break in market structure"
   → هاد الإبطال الحقيقي — القصة انتهت
   
3. Daily bias ينقلب
   → "If you are trading against what the daily chart is likely to be doing,
      you are asking for failure"
   → إذا Daily أعطى إشارة معاكسة = اطلع

4. نهاية الأفق الزمني
   → "Keep your perspective limited to a 5-day time horizon"
   → بعد 5 أيام: أعد التقييم من الصفر
```

## ما لا يخرج عنده مايكل:

```
❌ لا يخرج بسبب ارتداد صغير
   → "continue to trust that move and hold onto your trade"

❌ لا يخرج بسبب الخوف
   → "Overwhelming uncertainty eats at you... panic-sell"
   → "You must submit to your ideas"

❌ لا يخرج لأنو كسر STL (swing صغير)
   → "Only permissible... taking out sell-stops to re-accumulate"
   → هاد سحب سيولة للتجميع — مش انعكاس!

❌ لا يخرج بسبب الوقت وحده
   → "try to hold it out for the move"
```

---

## كيف نطبق هاد بالـRunner (Position B):

### الحالي:
```
B يتبع fractal lows على 1H → كل fractal = SL ينتقل
المشكلة: fractal على 1H ≈ STL (swing صغير)
مايكل يقول: كسر STL مسموح! هاد سحب سيولة.
```

### الصح حسب مايكل:
```
B لا يتبع fractals عادية — يتبع ITL/ITH!

ITL (Intermediate Term Low) = low مع:
  - higher low على يساره
  - higher low على يمينه
  → هاد أهم وأثقل من أي swing/fractal عادي

B يبقى طالما:
  1. down-closed candles (bullish OBs) سليمة
  2. ITL ما انكسر بإغلاق
  3. Daily bias ما انقلب

B يطلع فقط عندما:
  - ITL/ITH ينكسر بإغلاق → structure break حقيقي
  - أو TP2 ضُرب
  - أو 5 أيام مرت بدون وصول TP2
```

### الفرق عملياً:
```
الحالي: B يتبع كل fractal low → يطلع بعد 14h
المقترح: B يتبع ITL فقط → يبقى 2-3 أيام → يلتقط الحركة الكبيرة!

مثال يونيو 11:
  الحالي: دخل → TP1 ✅ → fractal trail → طلع بعد 14h بـ5.9R
  المقترح: دخل → TP1 ✅ → ITL ما انكسر → بقي → 29.8R!
```
