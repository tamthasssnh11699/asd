# -*- coding: utf-8 -*-
"""
ict_pd_array_runner.py — الـRunner المبني على PD Arrays
═══════════════════════════════════════════════════════════
3 مبادئ ذكية:

1. Premium/Discount الديناميكي:
   → لا trailing طالما السعر بالـDiscount (تراجع صحي)
   → trailing فقط بعد ما يخرج من الـPremium

2. حماية خلف PD Arrays حقيقية:
   → SL خلف آخر FVG غير مغلق أو OB حقيقي
   → مش خلف أي شمعة عشوائية

3. النقل القفزي (Structural):
   → SL يقفز فقط عند تشكل swing مؤكد + displacement بعده
   → مش كل شمعة
"""
import numpy as np


class PDArrayTracker:
    """يتتبع الـPD Arrays الحية — FVGs وOBs — ويعرف أيها لسا صالح."""
    
    def __init__(self):
        self.candles = []
        self.live_fvgs = []      # FVGs غير مغلقة
        self.live_obs = []       # OBs غير مبطلة
        self.structural_lows = []  # قيعان هيكلية مؤكدة
        self.structural_highs = []
    
    def add_candle(self, candle):
        self.candles.append(candle)
        n = len(self.candles)
        if n < 3:
            return
        
        c1, c2, c3 = self.candles[-3], self.candles[-2], self.candles[-1]
        
        # ═══ كشف FVG جديدة ═══
        # Bullish FVG: low[c3] > high[c1]
        if c3['l'] > c1['h']:
            self.live_fvgs.append({
                'type': 'BULL', 'top': c3['l'], 'bottom': c1['h'],
                'ce': (c3['l'] + c1['h']) / 2, 'index': n-2,
                'filled': False
            })
        # Bearish FVG: high[c3] < low[c1]
        if c3['h'] < c1['l']:
            self.live_fvgs.append({
                'type': 'BEAR', 'top': c1['l'], 'bottom': c3['h'],
                'ce': (c1['l'] + c3['h']) / 2, 'index': n-2,
                'filled': False
            })
        
        # ═══ كشف OB جديد ═══
        # Bullish OB: شمعة هابطة ثم صعودية تبتلعها
        if n >= 2:
            prev, curr = self.candles[-2], self.candles[-1]
            if prev['c'] < prev['o'] and curr['c'] > curr['o']:  # down then up
                if curr['c'] > prev['h'] and curr['l'] <= prev['l']:  # engulf
                    self.live_obs.append({
                        'type': 'BULL', 'top': prev['h'], 'bottom': prev['l'],
                        'open': prev['o'], 'index': n-2, 'broken': False
                    })
            if prev['c'] > prev['o'] and curr['c'] < curr['o']:  # up then down
                if curr['c'] < prev['l'] and curr['h'] >= prev['h']:
                    self.live_obs.append({
                        'type': 'BEAR', 'top': prev['h'], 'bottom': prev['l'],
                        'open': prev['o'], 'index': n-2, 'broken': False
                    })
        
        # ═══ تحديث FVGs — هل انغلقت؟ ═══
        for fvg in self.live_fvgs:
            if fvg['filled']:
                continue
            if fvg['type'] == 'BULL' and c3['l'] <= fvg['bottom']:
                fvg['filled'] = True
            elif fvg['type'] == 'BEAR' and c3['h'] >= fvg['top']:
                fvg['filled'] = True
        
        # ═══ تحديث OBs — هل انكسرت؟ ═══
        for ob in self.live_obs:
            if ob['broken']:
                continue
            if ob['type'] == 'BULL' and c3['c'] < ob['bottom']:
                ob['broken'] = True
            elif ob['type'] == 'BEAR' and c3['c'] > ob['top']:
                ob['broken'] = True
        
        # ═══ كشف Swing مؤكد + Displacement ═══
        if n >= 5:
            mid = n - 3
            # Swing Low مؤكد
            if (self.candles[mid]['l'] < self.candles[mid-1]['l'] and
                self.candles[mid]['l'] < self.candles[mid-2]['l'] and
                self.candles[mid]['l'] < self.candles[mid+1]['l'] and
                self.candles[mid]['l'] < self.candles[mid+2]['l']):
                
                # هل بعده displacement؟ (شمعة اتجاهية قوية)
                has_displacement = False
                for k in range(mid+1, min(mid+4, n)):
                    body = abs(self.candles[k]['c'] - self.candles[k]['o'])
                    rng = self.candles[k]['h'] - self.candles[k]['l']
                    if rng > 0 and body / rng > 0.5:
                        # مقارنة بالمحيط
                        prev_bodies = [abs(self.candles[j]['c']-self.candles[j]['o']) for j in range(max(0,k-3),k)]
                        if prev_bodies and body > np.mean(prev_bodies) * 1.5:
                            has_displacement = True
                            break
                
                self.structural_lows.append({
                    'price': self.candles[mid]['l'], 'index': mid,
                    'has_displacement': has_displacement,
                    'confirmed': True
                })
            
            # Swing High مؤكد
            if (self.candles[mid]['h'] > self.candles[mid-1]['h'] and
                self.candles[mid]['h'] > self.candles[mid-2]['h'] and
                self.candles[mid]['h'] > self.candles[mid+1]['h'] and
                self.candles[mid]['h'] > self.candles[mid+2]['h']):
                
                has_displacement = False
                for k in range(mid+1, min(mid+4, n)):
                    body = abs(self.candles[k]['c'] - self.candles[k]['o'])
                    rng = self.candles[k]['h'] - self.candles[k]['l']
                    if rng > 0 and body / rng > 0.5:
                        prev_bodies = [abs(self.candles[j]['c']-self.candles[j]['o']) for j in range(max(0,k-3),k)]
                        if prev_bodies and body > np.mean(prev_bodies) * 1.5:
                            has_displacement = True; break
                
                self.structural_highs.append({
                    'price': self.candles[mid]['h'], 'index': mid,
                    'has_displacement': has_displacement,
                    'confirmed': True
                })
    
    def get_pd_trail_level(self, is_long, entry_price, buffer=0):
        """
        يرجع مستوى trailing مبني على PD Arrays.
        
        الأولوية:
        1. آخر FVG حية (CE أو bottom/top)
        2. آخر OB حي
        3. آخر structural swing مع displacement
        
        يختار الأقرب للسعر (الأوسع حماية).
        """
        candidates = []
        
        if is_long:
            # FVGs صاعدة حية تحت السعر
            for fvg in self.live_fvgs:
                if fvg['type'] == 'BULL' and not fvg['filled'] and fvg['ce'] < entry_price:
                    candidates.append(fvg['bottom'] - buffer)
            
            # OBs صاعدة حية
            for ob in self.live_obs:
                if ob['type'] == 'BULL' and not ob['broken'] and ob['bottom'] < entry_price:
                    candidates.append(ob['bottom'] - buffer)
            
            # Structural lows مع displacement
            for sl in self.structural_lows:
                if sl['has_displacement'] and sl['price'] < entry_price:
                    candidates.append(sl['price'] - buffer)
            
            return max(candidates) if candidates else None
        
        else:
            for fvg in self.live_fvgs:
                if fvg['type'] == 'BEAR' and not fvg['filled'] and fvg['ce'] > entry_price:
                    candidates.append(fvg['top'] + buffer)
            
            for ob in self.live_obs:
                if ob['type'] == 'BEAR' and not ob['broken'] and ob['top'] > entry_price:
                    candidates.append(ob['top'] + buffer)
            
            for sh in self.structural_highs:
                if sh['has_displacement'] and sh['price'] > entry_price:
                    candidates.append(sh['price'] + buffer)
            
            return min(candidates) if candidates else None
    
    def is_narrative_broken(self, is_long, current_close):
        """
        هل القصة انتهت؟
        
        القصة تنتهي فقط عندما:
        - FVG حية تنكسر بإغلاق (مش wick)
        - OB حي ينكسر بإغلاق
        - هاد يعني الـPD Array فشلت = القصة تغيرت
        """
        if is_long:
            # هل آخر FVG صاعدة حية انكسرت؟
            recent_bull_fvgs = [f for f in self.live_fvgs[-3:] if f['type']=='BULL' and not f['filled']]
            for fvg in recent_bull_fvgs:
                if current_close < fvg['bottom']:
                    fvg['filled'] = True
                    return True, f"Bullish FVG broken at {fvg['bottom']:.0f}"
            
            # هل آخر OB صاعد انكسر؟
            recent_bull_obs = [ob for ob in self.live_obs[-3:] if ob['type']=='BULL' and not ob['broken']]
            for ob in recent_bull_obs:
                if current_close < ob['bottom']:
                    ob['broken'] = True
                    return True, f"Bullish OB broken at {ob['bottom']:.0f}"
        else:
            recent_bear_fvgs = [f for f in self.live_fvgs[-3:] if f['type']=='BEAR' and not f['filled']]
            for fvg in recent_bear_fvgs:
                if current_close > fvg['top']:
                    fvg['filled'] = True
                    return True, f"Bearish FVG broken at {fvg['top']:.0f}"
            
            recent_bear_obs = [ob for ob in self.live_obs[-3:] if ob['type']=='BEAR' and not ob['broken']]
            for ob in recent_bear_obs:
                if current_close > ob['top']:
                    ob['broken'] = True
                    return True, f"Bearish OB broken at {ob['top']:.0f}"
        
        return False, "Narrative intact"


def manage_pd_triple(candle_5m, candle_1h, candle_4h, state):
    """إدارة ثلاثية مبنية على PD Arrays."""
    h,l,c,o = candle_5m['h'],candle_5m['l'],candle_5m['c'],candle_5m.get('o',candle_5m['c'])
    is_short=state['is_short']; is_long=not is_short
    events=[]; risk=state['risk']
    
    # Initialize trackers
    if 'pd_1h' not in state: state['pd_1h'] = PDArrayTracker()
    if 'pd_4h' not in state: state['pd_4h'] = PDArrayTracker()
    if candle_1h: state['pd_1h'].add_candle(candle_1h)
    if candle_4h: state['pd_4h'].add_candle(candle_4h)
    
    state['candle_count']=state.get('candle_count',0)+1
    days=state['candle_count']/288
    
    # Premium/Discount check
    # الموجة = من entry إلى أبعد نقطة وصلها السعر
    best_price = state.get('best_price', state.get('pos_a',{}).get('entry', c))
    if is_long and h > best_price: state['best_price'] = h; best_price = h
    elif is_short and l < best_price: state['best_price'] = l; best_price = l
    
    entry = state.get('pos_a',{}).get('entry', c)
    wave_range = abs(best_price - entry)
    if wave_range > 0:
        if is_long:
            retracement_pct = (best_price - c) / wave_range * 100
        else:
            retracement_pct = (c - best_price) / wave_range * 100
        in_discount = retracement_pct > 50  # تراجع أكثر من 50% = discount
    else:
        in_discount = False
        retracement_pct = 0
    
    # ═══ POSITION A: Scalp ═══
    pa=state.get('pos_a',{})
    if pa.get('active'):
        if not pa.get('tp1_hit'):
            if (is_short and h>=pa['sl']) or (is_long and l<=pa['sl']):
                pa['active']=False;pa['pnl']=-state['risk_pct_a'];pa['exit_reason']='SL'
                events.append('❌ A:SL')
            elif pa.get('tp1'):
                if (is_short and l<=pa['tp1']) or (is_long and h>=pa['tp1']):
                    pa['tp1_hit']=True
                    rr=abs(pa['tp1']-pa['entry'])/risk if risk>0 else 0
                    pa['pnl']=rr*state['risk_pct_a'];pa['sl']=pa['entry']
                    events.append('🎯 A:TP1')
        elif pa.get('tp1_hit'):
            if (is_short and h>=pa['sl']) or (is_long and l<=pa['sl']):
                pa['active']=False;pa['exit_reason']='A_TRAIL';events.append('🧠 A:Trail')
            else:
                body=abs(c-o);rng=h-l;atr=state.get('atr',1)
                if rng>0 and body/rng>0.5:
                    if is_long and c>o:
                        ns=l-atr*0.1
                        if ns>pa['sl']:pa['sl']=ns
                    elif is_short and c<o:
                        ns=h+atr*0.1
                        if ns<pa['sl']:pa['sl']=ns
    
    # ═══ POSITION B: Day Runner (1H PD Array trailing) ═══
    pb=state.get('pos_b',{})
    if pb.get('active'):
        if pb.get('tp2_price'):
            if (is_short and l<=pb['tp2_price']) or (is_long and h>=pb['tp2_price']):
                pb['active']=False;rr=abs(pb['tp2_price']-pb['entry'])/risk if risk>0 else 0
                pb['pnl']=rr*state['risk_pct_b'];pb['exit_reason']='TP2'
                events.append('🏆 B:TP2')
        
        if pb.get('active') and not pb.get('be_set'):
            if (is_short and h>=pb['sl']) or (is_long and l<=pb['sl']):
                pb['active']=False;pb['pnl']=-state['risk_pct_b'];pb['exit_reason']='SL'
                events.append('❌ B:SL')
        
        if pb.get('active') and pb.get('be_set'):
            if (is_short and h>=pb['sl']) or (is_long and l<=pb['sl']):
                pb['active']=False
                rr=abs(pb['sl']-pb['entry'])/risk if risk>0 else 0
                ok=(is_long and pb['sl']>pb['entry']) or (is_short and pb['sl']<pb['entry'])
                pb['pnl']=rr*state['risk_pct_b'] if ok else 0
                pb['exit_reason']='B_TRAIL';events.append('🧠 B:PD Trail')
            elif not in_discount:
                # ═══ PD Array Trailing (فقط خارج الـDiscount!) ═══
                atr=state.get('atr',1)
                tl=state['pd_1h'].get_pd_trail_level(is_long,pb['entry'],buffer=atr*0.2)
                if tl:
                    if is_long and tl>pb['sl']:pb['sl']=tl
                    elif is_short and tl<pb['sl']:pb['sl']=tl
            
            # Narrative check
            broken,reason=state['pd_1h'].is_narrative_broken(is_long,c)
            if broken and pb.get('active'):
                pb['active']=False
                rr=abs(c-pb['entry'])/risk if risk>0 else 0
                ok=(is_long and c>pb['entry']) or (is_short and c<pb['entry'])
                pb['pnl']=rr*state['risk_pct_b'] if ok else 0
                pb['exit_reason']='B_NARR';events.append(f'📖 B:{reason[:25]}')
        
        if pa.get('tp1_hit') and not pb.get('be_set') and pb.get('active'):
            pb['sl']=pb['entry'];pb['be_set']=True;events.append('🛡️ B:BE')
    
    # ═══ POSITION C: Swing Runner (4H PD Array — يبقى أيام!) ═══
    pc=state.get('pos_c',{})
    if pc.get('active'):
        if pc.get('tp3_price'):
            if (is_short and l<=pc['tp3_price']) or (is_long and h>=pc['tp3_price']):
                pc['active']=False;rr=abs(pc['tp3_price']-pc['entry'])/risk if risk>0 else 0
                pc['pnl']=rr*state['risk_pct_c'];pc['exit_reason']='TP3_MEGA'
                events.append('💎 C:TP3!')
                if pa.get('active'):
                    pa['active']=False;rr_a=abs(pc['tp3_price']-pa['entry'])/risk if risk>0 else 0
                    pa['pnl']=rr_a*state['risk_pct_a'];pa['exit_reason']='WITH_C'
                if pb.get('active'):
                    pb['active']=False;rr_b=abs(pc['tp3_price']-pb['entry'])/risk if risk>0 else 0
                    pb['pnl']=rr_b*state['risk_pct_b'];pb['exit_reason']='WITH_C'
        
        if pc.get('active') and not pc.get('be_set'):
            if (is_short and h>=pc['sl']) or (is_long and l<=pc['sl']):
                pc['active']=False;pc['pnl']=-state['risk_pct_c'];pc['exit_reason']='SL'
                events.append('❌ C:SL')
        
        if pc.get('active') and pc.get('be_set'):
            if (is_short and h>=pc['sl']) or (is_long and l<=pc['sl']):
                pc['active']=False
                rr=abs(pc['sl']-pc['entry'])/risk if risk>0 else 0
                ok=(is_long and pc['sl']>pc['entry']) or (is_short and pc['sl']<pc['entry'])
                pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                pc['exit_reason']='C_TRAIL';events.append('🧠 C:4H Trail')
            elif days>=5:
                pc['active']=False
                ok=(is_long and c>pc['entry']) or (is_short and c<pc['entry'])
                rr=abs(c-pc['entry'])/risk if risk>0 else 0
                pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                pc['exit_reason']='5DAY';events.append('📅 C:5day')
            elif not in_discount:
                # 4H PD Array trailing — أبطأ بكثير
                atr=state.get('atr',1)
                tl4=state['pd_4h'].get_pd_trail_level(is_long,pc['entry'],buffer=atr*0.4)
                if tl4:
                    if is_long and tl4>pc['sl']:pc['sl']=tl4
                    elif is_short and tl4<pc['sl']:pc['sl']=tl4
            
            broken4,reason4=state['pd_4h'].is_narrative_broken(is_long,c)
            if broken4 and pc.get('active'):
                pc['active']=False
                rr=abs(c-pc['entry'])/risk if risk>0 else 0
                ok=(is_long and c>pc['entry']) or (is_short and c<pc['entry'])
                pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                pc['exit_reason']='C_4H_NARR';events.append(f'📖 C:4H {reason4[:20]}')
        
        if pa.get('tp1_hit') and not pc.get('be_set') and pc.get('active'):
            pc['sl']=pc['entry'];pc['be_set']=True;events.append('🛡️ C:BE')
    
    all_closed=(not pa.get('active',False)) and (not pb.get('active',False)) and (not pc.get('active',False))
    if all_closed:
        state['pnl_pct']=(pa.get('pnl',0) or 0)+(pb.get('pnl',0) or 0)+(pc.get('pnl',0) or 0)
        state['exit_reason_a']=pa.get('exit_reason','?')
        state['exit_reason_b']=pb.get('exit_reason','?')
        state['exit_reason_c']=pc.get('exit_reason','?')
    return events,all_closed
