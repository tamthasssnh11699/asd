# 🧠 الحقيقة الجوهرية: مايكل عنده نموذج واحد — مش 6 منفصلين

## ما اكتشفته من البحث:

### النموذج الأساسي لمايكل (2022 Mentorship) = **تسلسل واحد من 4 خطوات**:

```
1. Liquidity Sweep    (السعر يسحب مستوى سيولة — session high/low، swing، EQH/EQL)
2. Market Structure Shift  (كسر swing بالاتجاه المعاكس مع displacement)
3. Fair Value Gap     (الـdisplacement يترك FVG خلفه)
4. Entry on Retest    (السعر يرجع يلمس الـFVG → الدخول)
```

**المصدر:** innercircletrader.net: "The strategy is built on three pillars: daily bias, session liquidity sweep, lower-timeframe entry trigger off a PD Array"

**المصدر:** TradingView ICT 2022 indicator: "it requires four specific steps to occur IN ORDER: Liquidity Sweep → MSS → Displacement (FVG) → Retest & Signal"

**المصدر:** liquidityscan.io: "The 2022 Mentorship Model is a four-step sequence"

### ما يفعله الكود الحالي بالمقابل:
```
6 نماذج منفصلة (A, B, C, D, E, F) + GENERIC_FALLBACK
كل واحد عنده شروطه الخاصة
كل واحد يُقيَّم بشكل مستقل
إذا فشل واحد → ينتقل للتالي
لا يوجد تسلسل زمني موحد
```

### المشكلة:
- **الـ6 نماذج مش من مايكل بهالأسماء.** هي تفكيك مصطنع لنفس النموذج.
- **كل نموذج بيستنا شروطه بشكل معزول** بدل ما يكونوا جزء من قصة واحدة.
- **نفس الحدث (sweep) ممكن يتكرر في 3 نماذج** بأشكال مختلفة بدون ربط.

### الحل الصحيح:
**نموذج واحد بتسلسل واحد:**
```python
class ICT2022Model:
    def evaluate(self, data_5m, data_15m, data_1d, bias, session):
        # 1. هل حصل liquidity sweep مؤخراً؟
        sweep = self.detect_sweep(data_15m, bias)
        if not sweep: return WAITING_FOR_SWEEP
        
        # 2. هل حصل MSS بعد الـsweep؟ (displacement + close through swing)
        mss = self.detect_mss_after_sweep(data_5m, sweep)
        if not mss: return WAITING_FOR_MSS
        
        # 3. هل الـdisplacement ترك FVG؟
        fvg = self.find_fvg_from_displacement(data_5m, mss)
        if not fvg: return WAITING_FOR_FVG
        
        # 4. هل السعر رجع للـFVG؟
        retest = self.check_retest(data_5m, fvg)
        if not retest: return WAITING_FOR_RETEST
        
        # 5. بناء الخطة
        return self.build_plan(fvg, sweep, mss, bias)
```

### عن الـDisplacement:
**المصدر:** ictkillzone.com: "significantly larger than the 3–5 preceding candles, at minimum 2x"
**المصدر:** FibAlgo: "body 60-70% of total range"
**المصدر:** innercircletrader.net: "body-to-range ratio above ~75%"

**الحل للـthreshold:**
- بدل 1.5 ATR ثابت (رقم مخترع)
- نستخدم: **body > 2× متوسط جسم آخر 5 شموع** (من كلام مايكل: "significantly larger than 3-5 preceding candles")
- + **body/range ≥ 60%** (من FibAlgo المرجعي: "at least 60-70%")
- + **يجب أن يترك FVG** (بدون FVG = ليس displacement حقيقي)
