import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"

full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 8000, output_format="dict")
n = len(full_data["closes"])
candidates = []
reported_days = set()

for i in range(2000, n, 50): 
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"): continue

    current_ts = window_data["timestamps"][-1]
    day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
    if day_str in reported_days: continue

    try:
        sig = ae.detect_significant_swings(window_data, swing_window=1, lookback_candles=100)
    except Exception:
        continue

    if daily_bias == "BULLISH":
        important_levels = [s for s in sig.get("all_lows_tiered", [])]
        for candidate in important_levels:
            res = classify_sweep_or_run(window_data, candidate["price"], level_is_high=False, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                reported_days.add(day_str)
                break
    else:
        important_levels = [s for s in sig.get("all_highs_tiered", [])]
        for candidate in important_levels:
            res = classify_sweep_or_run(window_data, candidate["price"], level_is_high=True, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                reported_days.add(day_str)
                break

candidates.sort(key=lambda c: c["timestamp"])
if len(candidates) > 30: candidates = candidates[-30:]

print("تحليل أقصى تحرك للسعر (MFE) لنرى هل ضيع البوت أرباحاً كبيرة؟")
for idx, cand in enumerate(candidates):
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    for k in range(0, 4):
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    if outcome and outcome.get("outcome") in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
                        sl_dist = abs(entry - sl)
                        tp1_dist = abs(entry - tp1)
                        tp1_rr = tp1_dist / sl_dist if sl_dist > 0 else 0
                        
                        mfe = outcome.get("max_favorable_excursion")
                        max_rr = 0
                        if mfe:
                            max_dist = abs(entry - mfe)
                            max_rr = max_dist / sl_dist if sl_dist > 0 else 0
                            
                        print(f"[{cand['datetime_utc'][:10]}] {bias} | TP1 R:R = {tp1_rr:.2f}R | أقصى ارتداد (Max RR) قبل ضرب الدخول = {max_rr:.2f}R")
                        break
        except Exception: pass
