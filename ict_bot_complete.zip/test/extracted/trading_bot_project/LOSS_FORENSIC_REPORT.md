# 🔬 تشريح الخسائر بالميلي — 9 صفقات خاسرة

## الأسباب الجذرية المكتشفة:

### 🔴 مشكلة #1: SL ضيق جداً (4 من 9 صفقات)
| الصفقة | SL distance | ما حصل |
|--------|------------|--------|
| #1 مارس 1 | **0.286%** ($242) | راح 1.32R لصالحنا ثم SL! |
| #2 مارس 2 | **0.243%** ($209) | راح 1.01R لصالحنا ثم SL! |
| #5 مارس 16 | **0.265%** ($222) | SL فوري |
| #9 مارس 31 | **0.163%** ($133) | راح 1.13R لصالحنا ثم SL! |

**السبب:** الـSL يُوضع فوق الـsweep wick extreme مباشرة.
لكن الـsweep wick في بعض الحالات **قريبة جداً** من الـFVG CE (نقطة الدخول).

**المصدر الرسمي:** مايكل في 2022 Ep6 (27:18): "الستوب فوق swing high"
ومايكل في 2022 Ep6 (36:06): "وإذا كانت المخاطرة كبيرة: لا تأخذ الصفقة"

**الحل من مايكل:**
- SL يجب أن يكون خلف **swing** مش خلف sweep wick فقط
- إذا الـswing والـsweep wick متقاربين، الـSL يذهب خلف الأبعد
- minimum SL distance مبني على ATR (مش رقم ثابت)

### 🔴 مشكلة #2: تركنا مصاري على الطاولة (3 من 9)
| الصفقة | Max favorable | ثم ما حصل |
|--------|-------------|-----------|
| #1 | **1.32R** في صالحنا | رجع وضرب SL |
| #2 | **1.01R** في صالحنا | رجع وضرب SL |
| #9 | **1.13R** في صالحنا | رجع وضرب SL بعد 2 شموع |

**3 صفقات** راحت **أكثر من 1R في صالحنا** ثم رجعت وضربت الستوب!

**لو كان فيه:**
- TP1 عند 1R (partial close 50%)
- BE بعد TP1
→ هالـ3 صفقات كانت **ربحانة** بدل خسرانة

**المصدر:** مايكل يستخدم partials:
- 2022 Notes: "partials should be taken below each low"
- innercircletrader.net Fib: "Taking partials at -1.0"

### 🔴 مشكلة #3: SL ضرب بطريقة عم يتكرر النمط
الـ4 صفقات BEARISH الخاسرة (#1, #2, #5, #6): السعر نزل في صالحنا، ثم رجع وأخذ الـSL.

**النمط المتكرر:**
```
Entry → يهبط 0.3-1.3R → يطلع يضرب SL → يرجع يكمل هبوط!
```
هاد نمطي — الـSL واقع بالمنطقة يلي فيها "noise" عادي.

### 🔴 مشكلة #4: TP1 بعيد جداً في بعض الحالات
الـTP1 مطلوب R:R ≥ 2.0. لكن مع SL ضيق:
- SL $200 × RR 2.0 = TP1 بعيد $400
- بينما السعر يتحرك $250-350 بس (أقل من TP1)

**الحل:** مايكل يقول "low hanging fruit" — أقرب هدف سيولة.
إذا الهدف الأقرب مش بعيد كفاية لـ2R → **لا صفقة** (مش نوسع الـTP)

### 🟡 مشكلة #5: ما فيه Trailing/Runner
حالياً بس Entry → TP1 أو SL. ما فيه:
- TP1 partial (50%)
- BE بعد TP1
- Trailing stop
- TP2 (Draw on Liquidity)

## الحلول المطلوبة (من مصادر مايكل):

### 1. SL أوسع وأذكى
```python
# الحالي (خاطئ):
sl = sweep_wick_extreme - small_buffer

# الصحيح (مايكل Ep6 27:18):
sl = min(sweep_wick_extreme, nearest_swing_below_entry) - buffer
# + minimum: sl_distance >= 0.5 * ATR(14) على الأقل
# + إذا sl_distance < 0.3% → لا صفقة (مش نقرب الSL)
```

### 2. TP1 واقعي + Partials
```python
# المصدر: 2022 Notes: "partials at each low"
# المصدر: innercircletrader.net: "-1.0 fib = 1x the leg"
tp1 = أقرب_مستوى_سيولة_حقيقي
if rr_to_tp1 < 1.5:
    no_trade()  # مش كافي
# عند TP1: close 50%, move SL to entry (BE)
# الباقي 50% = trailing stop خلف آخر swing
```

### 3. Trailing Stop (مايكل Method 1)
```python
# المصدر: الدستور 14.5: "Structure Trail Method 1"
# 2022 Notes: "trailing stop below previous bullish order block's low"
بعد TP1:
  - SL ينتقل لـBE (سعر الدخول)
  - كل ما يتشكل swing جديد بالاتجاه → SL ينتقل خلفه
  - SL لا يتراجع أبداً (RULE 6)
```

### 4. TP2 (Draw on Liquidity)
```python
# المصدر: قسم 14.3: "Draw on Liquidity from Daily"
# المصدر: 2022 Notes: "target old highs/buyside liquidity"
tp2 = أبعد_مستوى_سيولة_على_HTF  # Daily EQH/EQL أو session high/low
# أو OPEN_TRAILING إذا ما فيه مستوى واضح
```
