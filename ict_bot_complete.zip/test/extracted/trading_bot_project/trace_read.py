# -*- coding: utf-8 -*-
"""
trace_read.py — أداة تتبّع "قراءة الشارت" لتحليل algo_master.py
══════════════════════════════════════════════════════════════════
الهدف: تاخد كل رقم طلّعو البوت (FVG / OB / Sweep / Structure / الموديل)
وترجّعو لأبسط حجة: شموع OHLC اللي انبنى عليها. هيك بتقدر تفتح
شارت OKX وتتأكد بعينك إذا قرايت البوت صح، ولا عم "يشلّف" بالاستنتاج
حتى لو الأرقام من الشارت.

التشغيل:
    python3 trace_read.py SOL          # يتتبّع قراءة SOL على كل الطبقات
    python3 trace_read.py BTC --n 8    # سياق أكبر حول كل شمعة
    python3 trace_read.py BNB          # يتتبّع BNB (بتشوف بهدلة الـBSL)
"""
import sys, argparse, pytz
sys.path.insert(0, "/tmp/fakepkgs")
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import requests, numpy as np
from datetime import datetime, timezone
import brain_core
class FakeBrain:
    class data_manager:
        @staticmethod
        def fetch_ohlcv_up_to(*a, **k):
            raise RuntimeError("not used")
brain_core.BrainCore = FakeBrain
import algo_master as am
from ict_math_engine import (detect_fair_value_gaps, detect_order_blocks,
                             classify_sweep_or_run, detect_mss)
from authenticity_engine import AuthenticityEngine
NY = pytz.timezone("America/New_York")
ae = AuthenticityEngine()

def fetch(symbol, bar, limit=250):
    okx = {"1w": "1W", "1d": "1D", "4h": "4H"}.get(bar, bar)
    r = requests.get("https://www.okx.com/api/v5/market/history-candles",
                     params={"instId": symbol.replace("/", "-"), "bar": okx,
                             "limit": str(limit)}, timeout=25).json()
    raw = list(reversed(r["data"]))
    return {"timestamps": [int(x[0]) for x in raw], "opens": [float(x[1]) for x in raw],
            "highs": [float(x[2]) for x in raw], "lows": [float(x[3]) for x in raw],
            "closes": [float(x[4]) for x in raw], "volumes": [float(x[5]) for x in raw],
            "symbol": symbol, "timeframe": bar, "count": len(raw), "source": "okx"}

def cdl(d, abs_i, label=""):
    """طباعة شمعة واحدة بـOHLC من index مطلق."""
    n = len(d["closes"])
    if abs_i < 0 or abs_i >= n:
        return
    t = datetime.fromtimestamp(d["timestamps"][abs_i] / 1000, tz=NY)
    rel = abs_i - n
    o, h, l, c = d["opens"][abs_i], d["highs"][abs_i], d["lows"][abs_i], d["closes"][abs_i]
    rng = h - l
    body = abs(c - o)
    kind = "🟢" if c >= o else "🔴"
    print(f"   [{rel:>4}] {t.strftime('%m-%d %H:%M')} {kind} O{h5(o):>9.2f} H{h5(h):>9.2f} L{h5(l):>9.2f} C{h5(c):>9.2f}  | body {body/rng*100:4.0f}% من الرينج" + (f"  ← {label}" if label else ""))

def h5(x): return x  # alias for formatting

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("symbol", nargs="?", default="SOL")
    ap.add_argument("--n", type=int, default=5, help="عدد شموع السياق حول كل شمعة")
    a = ap.parse_args()
    sym = a.symbol.upper()
    if "/" not in sym:
        sym = f"{sym}/USDT"
    N = a.n

    print(f"\n{'='*78}\n  🔬 تتبّع قراءة الشارت لـ {sym} — كل رقم مع شموعه المصدرية\n{'='*78}")
    d15 = fetch(sym, "15m"); d5 = fetch(sym, "5m")
    n15, n5 = len(d15["closes"]), len(d5["closes"])
    bias = am.analyze_bias(fetch(sym, "1d"), fetch(sym, "4h"), fetch(sym, "1w"))["dir_1d"]
    print(f"  الانحياز: {bias} | سعر 15m={d15['closes'][-1]:.2f} | سعر 5m={d5['closes'][-1]:.2f}\n")

    # ── A) خريطة السيولة → شمعة السوينغ المصدرية ──
    print(f"{'─'*78}\n  A) خريطة السيولة (15m): كل BSL/SSL مع شمعة السوينغ يلي طلّعتو\n{'─'*78}")
    sig = ae.detect_significant_swings(d15, swing_window=3, lookback_candles=150)
    lm = am.analyze_liquidity_map(d15, "15m")
    allsw = list(sig.get("all_highs_tiered", [])) + list(sig.get("all_lows_tiered", []))
    for side, rows in [("BSL", lm["bsl"]), ("SSL", lm["ssl"])]:
        for r in rows:
            # نلاقي شمعة السوينغ يلي سعرها = r['price']
            match = None
            for s in allsw:
                if abs(s["price"] - r["price"]) < 1e-6:
                    match = s; break
            ai = (n15 + match["index_from_end"]) if match else None
            tag = f"{side} {r['price']:.2f} [{r['tier']}] (بعدو {r['dist']:.2f} عن السعر)"
            print(f"\n  ▸ {tag}")
            if ai is not None:
                lo = max(0, ai - 1); hi = min(n15, ai + 2)
                for k in range(lo, hi):
                    cdl(d15, k, "شمعة السوينغ" if k == ai else "")

    # ── B) السحب → شمعة الفتيل + شمعة السوينغ المسحوب ──
    print(f"\n{'─'*78}\n  B) السحب (Sweep) على 15m: شمعة الفتيل اللي اخترق ورجع\n{'─'*78}")
    sw = am.detect_recent_sweep(d15, bias, "15m")
    if sw:
        # نقلّد detect_recent_sweep بالضبط: نفحص كل السوينغات، نختار الـGENUINE الأقرب للسعر
        cand = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
        cur = d15["closes"][-1]
        best = None
        win = 12
        check_start = max(n15 - win, 0)
        for s in cand:
            if s.get("tier") not in ("MAJOR", "MODERATE", "MINOR"):
                continue
            lvl = s["price"]; sidx = n15 + s["index_from_end"]
            cs = max(sidx + 1, check_start)
            if cs >= n15:
                continue
            if bias == "BULLISH":
                extreme = min(d15["lows"][cs:n15]); swept = extreme < lvl
            else:
                extreme = max(d15["highs"][cs:n15]); swept = extreme > lvl
            if not swept:
                continue
            res = classify_sweep_or_run(d15, lvl, level_is_high=(bias == "BEARISH"), check_from_idx=cs)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                cand_d = {"level": lvl, "dist": abs(cur - lvl),
                          "wick": res["wick_price"], "wick_i": n15 + res["candle_index_from_end"],
                          "swing_i": sidx}
                if best is None or cand_d["dist"] < best["dist"]:
                    best = cand_d
        if best:
            print(f"\n  ▸ سحب {sw['side']} عند {best['level']:.2f} | فتيل لحد {best['wick']:.2f} | التصنيف: GENUINE_REVERSAL_SWEEP")
            print("    ┌ شمعة السوينغ المسحوبة (المستوى):")
            cdl(d15, best["swing_i"], "شمعة السوينغ")
            print("    └ شمعة الفتيل (الاختراق + رجعة الإغلاق):")
            for k in range(max(0, best["wick_i"] - 1), min(n15, best["wick_i"] + 2)):
                cdl(d15, k, "شمعة الفتيل" if k == best["wick_i"] else "")
        else:
            print(f"\n  ▸ لا سحب GENUINE في آخر {win} شمعة.")
    else:
        # نفس منطق algo_master المصحّح: ننتظر BSL فوق السعر (هابط) أو SSL تحت السعر (صاعد)
        cur = d15["closes"][-1]
        if bias == "BULLISH":
            cands = [s for s in sig.get("all_lows_tiered", []) if s["price"] < cur]; side = "SSL"
        else:
            cands = [s for s in sig.get("all_highs_tiered", []) if s["price"] > cur]; side = "BSL"
        cands.sort(key=lambda s: abs(s["price"] - cur))
        tgt = cands[0] if cands else None
        if tgt:
            print(f"\n  ▸ لا سحب بعد. البوت منستنا يسحب {side} عند {tgt['price']:.2f} (بعدو {abs(tgt['price']-cur):.2f} عن السعر)")
            print(f"    ✅ فحص منطقي: الانحياز {bias} → الـ{side} المقترح بجهة صحيحة "
                  f"({'فوق' if tgt['price']>cur else 'تحت'}) السعر ({cur:.2f}). مضبوط.")
        else:
            print(f"\n  ▸ لا سحب بعد. ما فيو {side} مؤكّد بجهة السعر الصحيحة بعد (السعر لسا ما حطّ مستوى سيولة مناسب).")

    # ── C) FVG → الشموع التلاتة المكوّنة ──
    print(f"\n{'─'*78}\n  C) مناطق الـFVG (15m): كل FVG مع الشموع التلاتة اللي شكّلتو\n{'─'*78}")
    fvgs = detect_fair_value_gaps(d15, lookback=n15, require_displacement=True)
    for f in fvgs["bullish_fvgs"][-3:] + fvgs["bearish_fvgs"][-3:]:
        ai = n15 + f["index_from_end"]   # الشمعة التالتة (idx)
        print(f"\n  ▸ FVG {'صاعد 🟢' if f in fvgs['bullish_fvgs'] else 'هابط 🔴'}: "
              f"{f['bottom']:.2f}–{f['top']:.2f} (CE {f['ce']:.2f}, ملء {f['filled_pct']}%)")
        # الشموع المكوّنة: idx-2, idx-1, idx (للصاعد: قاع idx-2 > قمة idx)
        for k in range(ai - 2, ai + 1):
            if k < 0 or k >= n15: continue
            role = "①شمعة 1 (قاعها = سقف الـFVG)" if k == ai-2 else ("②شمعة 2 (الاندفاع)" if k == ai-1 else "③شمعة 3 (قمتها = قاع الـFVG)")
            cdl(d15, k, role)

    # ── D) OB → شمعة الـOB ──
    print(f"\n{'─'*78}\n  D) Order Blocks (15m): كل OB مع شمعة الـOB المصدرية\n{'─'*78}")
    obs = detect_order_blocks(d15, lookback=n15)
    for ob in obs["bullish_obs"][-3:] + obs["bearish_obs"][-3:]:
        ai = n15 + ob["index_from_end"]
        print(f"\n  ▸ OB {'صاعد 🟢' if ob in obs['bullish_obs'] else 'هابط 🔴'}: "
              f"{ob['bottom']:.2f}–{ob['top']:.2f}" + (" (+FVG قريب)" if ob.get('fvg_nearby') else ""))
        for k in range(max(0, ai - 1), min(n15, ai + 2)):
            cdl(d15, k, "شمعة الـOB" if k == ai else "")

    # ── E) الهيكل MSS → شمعة الكسر ──
    print(f"\n{'─'*78}\n  E) الهيكل (MSS) على 15m: شمعة الكسر + المستوى المكسور\n{'─'*78}")
    mss = detect_mss(d15)
    if mss.get("breaks_found"):
        b = mss["breaks_found"][-1]
        ai = n15 + (b.get("break_candle_index_from_end") or 0)
        print(f"\n  ▸ آخر كسر {b['direction']} عند {b['broken_level']:.2f} | اندفاع={b.get('displacement_confirmed')}")
        for k in range(max(0, ai - 1), min(n15, ai + 2)):
            cdl(d15, k, "شمعة الكسر" if k == ai else "")

    # ── F) الموديل B (5m) → إعادة اشتقاق السحب+الاندفاع+FVG ──
    print(f"\n{'─'*78}\n  F) الموديل B (5m): إعادة اشتقاق السحب + الاندفاع + الـFVG بـOHLC\n{'─'*78}")
    is_long = (bias == "BULLISH")
    lows5 = np.asarray(d5["lows"]); highs5 = np.asarray(d5["highs"]); closes5 = np.asarray(d5["closes"])
    n5 = len(closes5); sw = 2
    sidx_list = [i for i in range(sw, n5 - sw) if (lows5[i] == min(lows5[i-sw:i+sw+1]) if is_long else highs5[i] == max(highs5[i-sw:i+sw+1]))]
    swept = None
    for sidx in reversed(sidx_list[-6:]):
        lvl = float(lows5[sidx]) if is_long else float(highs5[sidx])
        res = classify_sweep_or_run(d5, lvl, level_is_high=(not is_long), check_from_idx=sidx + 1)
        if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
            swept = (sidx, lvl, res); break
    if swept:
        sidx, lvl, res = swept
        print(f"\n  ▸ سحب الموديل B: قاع سوينغ (SSL) عند {lvl:.2f} على شمعة idx {sidx-n5}")
        for k in range(max(0, sidx - 2), min(n5, sidx + 3)):
            cdl(d5, k, "شمعة السوينغ المسحوبة" if k == sidx else ("شمعة الفتيل" if k == (n5 + res['candle_index_from_end']) else ""))
        # الاندفاع
        wi = n5 + res["candle_index_from_end"]
        disp_i = None
        for k in range(wi + 1, min(n5, wi + 6)):
            if is_long and closes5[k] > closes5[k-1] + (highs5[k]-lows5[k]) * 0.6:
                disp_i = k; break
            if (not is_long) and closes5[k] < closes5[k-1] - (highs5[k]-lows5[k]) * 0.6:
                disp_i = k; break
        if disp_i is not None:
            print(f"\n  ▸ شمعة الاندفاع (Displacement) بعد السحب:")
            cdl(d5, disp_i, "اندفاع")
        # FVG بعد الاندفاع
        fvgs5 = detect_fair_value_gaps(d5, lookback=n5, require_displacement=True)
        print(f"\n  ▸ الـFVG الناتجة بعد الاندفاع (على 5m):")
        cnt = 0
        for f in fvgs5["bullish_fvgs"][-3:] + fvgs5["bearish_fvgs"][-3:]:
            ai = n5 + f["index_from_end"]
            if ai < (disp_i or 0): continue
            cnt += 1
            print(f"    • FVG {'صاعد' if f in fvgs5['bullish_fvgs'] else 'هابط'}: {f['bottom']:.2f}–{f['top']:.2f} (CE {f['ce']:.2f})")
            for k in range(ai - 2, ai + 1):
                if 0 <= k < n5: cdl(d5, k, "شمعة FVG" if k == ai else "")
            if cnt >= 3: break
    else:
        print("  ▸ الموديل B ما لقى سحب حقيقي على 5m بعد.")

    print(f"\n{'='*78}\n  انتهى التتبّع. افتح شارت OKX على نفس الفريم وقارن الشموع — إذا طابقو، قراية البوت صح.\n{'='*78}\n")

if __name__ == "__main__":
    main()
