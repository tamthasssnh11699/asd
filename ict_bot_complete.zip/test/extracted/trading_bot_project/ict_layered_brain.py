# -*- coding: utf-8 -*-
"""
ict_layered_brain.py — الدماغ الطبقي الذكي
═══════════════════════════════════════════
يفهم القصة. يقرأ السوق كمتداول. مش كآلة حاسبة.

المصادر المعتمدة:
- ICT Core Content Month 2: "Daily=الحي, 4H=الشارع, 15M=العنوان"
- innercircletrader.net: IRL/ERL, Dealing Range, IPDA
- 2022 Mentorship: Complete Strategy, Daily Bias, Entry
- 2024 Mentorship: IOFED, Macro Windows

البنية: 4 طبقات متزامنة (مش خطية!)
  Layer 1: BIAS (Daily+4H) — مرة/يوم
  Layer 2: NARRATIVE (15M) — كل 15 دقيقة  
  Layer 3: TRIGGER (5M) — كل 5 دقائق
  Layer 4: EXECUTION (5M/1M) — لحظة الحقيقة
"""
import numpy as np
from ict_math_engine import detect_ict_three_candle_swings, _atr


# ═══════════════════════════════════════════
#  DEALING RANGE — العمود الفقري
# ═══════════════════════════════════════════
# المصدر: innercircletrader.net IRL/ERL guide:
# "The dealing range is the area between an established Swing High
#  (that swept old high liquidity) and an established Swing Low
#  (that swept old low liquidity)"
#
# المصدر: tradingedges.org:
# "The rule is that the range's swing high and swing low must be
#  UNAMBIGUOUS. If you're arguing with yourself about which high
#  is 'the' high, you haven't found a real range yet."

def find_dealing_range(data):
    """
    يجد الـDealing Range الحالي — أهم مستويين بالشارت.
    
    Dealing Range = Swing High اللي سحب سيولة + Swing Low اللي سحب سيولة
    
    IRL = أي FVG داخل الـrange (هدف السعر القريب)
    ERL = أطراف الـrange (هدف السعر البعيد)
    
    المصدر: "Price moves from ERL → IRL → ERL → IRL"
    """
    swings = detect_ict_three_candle_swings(data)
    n = len(data.get('closes', []))
    if n < 20:
        return None
    
    highs_arr = np.asarray(data['highs'], dtype=float)
    lows_arr = np.asarray(data['lows'], dtype=float)
    
    # نبحث عن أعلى قمة وأدنى قاع ضمن آخر lookback
    swing_highs = sorted(swings['swing_highs'], key=lambda s: s['price'], reverse=True)
    swing_lows = sorted(swings['swing_lows'], key=lambda s: s['price'])
    
    if not swing_highs or not swing_lows:
        return None
    
    range_high = swing_highs[0]  # أعلى swing high
    range_low = swing_lows[0]    # أدنى swing low
    
    if range_high['price'] <= range_low['price']:
        return None
    
    rng = range_high['price'] - range_low['price']
    current = float(data['closes'][-1])
    equilibrium = range_low['price'] + rng * 0.5
    
    # Premium/Discount
    # المصدر: "Above 50% = Premium. Below 50% = Discount"
    if current > equilibrium:
        zone = "PREMIUM"
    elif current < equilibrium:
        zone = "DISCOUNT"
    else:
        zone = "EQUILIBRIUM"
    
    # ERL: سيولة خارج الـrange
    erl_high = range_high['price']  # BSL (buy stops above)
    erl_low = range_low['price']    # SSL (sell stops below)
    
    return {
        'high': range_high,
        'low': range_low,
        'range': round(rng, 2),
        'equilibrium': round(equilibrium, 6),
        'zone': zone,
        'erl_high': erl_high,
        'erl_low': erl_low,
        'current': current,
        'pct_in_range': round((current - range_low['price']) / rng * 100, 1) if rng > 0 else 50,
    }


# ═══════════════════════════════════════════
#  LAYER 1: BIAS — القائد
# ═══════════════════════════════════════════
# المصدر: innercircletrader.net Daily Bias:
# "Without a correct daily bias, the rest of the ICT method does not work"
# 
# 3 مدخلات:
# 1. Daily order flow (HH/HL vs LH/LL)
# 2. Imbalances to rebalance (FVGs على Daily)
# 3. Draw on Liquidity (أين يريد السعر أن يذهب)

def read_bias(data_daily, data_4h):
    """
    يقرأ الانحياز من Daily + 4H.
    
    المصدر: innercircletrader.net:
    "Order flow, imbalances, draw on liquidity"
    "4H should not be in obvious conflict with daily"
    
    المصدر: IRL/ERL guide:
    "If price has taken IRL and ERL is above → bullish"
    """
    if not data_daily or len(data_daily.get('closes', [])) < 10:
        return {'direction': 'UNKNOWN', 'confidence': 0, 'reason': 'NO_DATA'}
    
    swings = detect_ict_three_candle_swings(data_daily)
    sh = swings['swing_highs']
    sl = swings['swing_lows']
    
    if len(sh) < 2 or len(sl) < 2:
        return {'direction': 'UNKNOWN', 'confidence': 0, 'reason': 'NOT_ENOUGH_SWINGS'}
    
    # Order flow: آخر قمتين وقاعين
    last_2_highs = sorted(sh, key=lambda s: s['index'])[-2:]
    last_2_lows = sorted(sl, key=lambda s: s['index'])[-2:]
    
    hh = last_2_highs[-1]['price'] > last_2_highs[-2]['price']  # Higher High
    hl = last_2_lows[-1]['price'] > last_2_lows[-2]['price']    # Higher Low
    lh = last_2_highs[-1]['price'] < last_2_highs[-2]['price']  # Lower High
    ll = last_2_lows[-1]['price'] < last_2_lows[-2]['price']    # Lower Low
    
    # المصدر: "HH+HL = bullish, LH+LL = bearish"
    if hh and hl:
        direction = 'BULLISH'
        confidence = 80
    elif lh and ll:
        direction = 'BEARISH'
        confidence = 80
    elif hh and ll:
        direction = 'MIXED'
        confidence = 30
    elif lh and hl:
        direction = 'MIXED'
        confidence = 30
    else:
        direction = 'UNKNOWN'
        confidence = 0
    
    # Draw on Liquidity: أين أقرب سيولة
    dealing = find_dealing_range(data_daily)
    if dealing:
        if dealing['zone'] == 'DISCOUNT' and direction == 'BULLISH':
            confidence += 15  # Discount + bullish = strong
        elif dealing['zone'] == 'PREMIUM' and direction == 'BEARISH':
            confidence += 15  # Premium + bearish = strong
    
    # 4H confirmation
    if data_4h and len(data_4h.get('closes', [])) > 10:
        sw4 = detect_ict_three_candle_swings(data_4h)
        sh4 = sorted(sw4['swing_highs'], key=lambda s: s['index'])[-2:] if len(sw4['swing_highs']) >= 2 else []
        sl4 = sorted(sw4['swing_lows'], key=lambda s: s['index'])[-2:] if len(sw4['swing_lows']) >= 2 else []
        
        if sh4 and sl4:
            h4_bull = sh4[-1]['price'] > sh4[-2]['price'] and sl4[-1]['price'] > sl4[-2]['price']
            h4_bear = sh4[-1]['price'] < sh4[-2]['price'] and sl4[-1]['price'] < sl4[-2]['price']
            
            if (direction == 'BULLISH' and h4_bull) or (direction == 'BEARISH' and h4_bear):
                confidence += 10  # 4H confirms
            elif (direction == 'BULLISH' and h4_bear) or (direction == 'BEARISH' and h4_bull):
                confidence -= 20  # 4H conflicts!
    
    return {
        'direction': direction,
        'confidence': min(100, confidence),
        'structure': {'hh': hh, 'hl': hl, 'lh': lh, 'll': ll},
        'dealing_range': dealing,
        'reason': f"{'HH+HL' if hh and hl else 'LH+LL' if lh and ll else 'MIXED'} | "
                  f"Zone={dealing['zone'] if dealing else '?'} | "
                  f"Confidence={min(100,confidence)}",
    }


# ═══════════════════════════════════════════
#  LAYER 2: NARRATIVE — القصة (15M)
# ═══════════════════════════════════════════
# المصدر: 2022 Strategy:
# "15-minute for liquidity and imbalances"
#
# هذا الفريم يخبرنا: "شو عم يصير بالقصة الحالية؟"
# - هل في sweep حصل؟
# - أين السيولة التالية؟
# - هل الـdealing range اتكسر؟

def read_narrative(data_15m, bias_direction):
    """يقرأ القصة الحالية على 15M بسياق الـbias."""
    if not data_15m or len(data_15m.get('closes', [])) < 20:
        return {'state': 'NO_DATA'}
    
    ctx_n = len(data_15m['closes'])
    atr_vals = _atr(data_15m['highs'], data_15m['lows'], data_15m['closes'])
    current_atr = float(atr_vals[-1]) if ctx_n > 15 and atr_vals[-1] > 0 else 1.0
    
    is_long = bias_direction == 'BULLISH'
    swings = detect_ict_three_candle_swings(data_15m)
    
    # ═══ البحث عن SWEEP ═══
    target_swings = swings['swing_lows'] if is_long else swings['swing_highs']
    
    best_sweep = None
    best_quality = 0
    
    for sw in target_swings:
        si = sw['index']
        if si >= ctx_n - 2:
            continue
        
        for i in range(si + 1, min(si + 15, ctx_n)):
            if is_long:
                wicked = data_15m['lows'][i] < sw['price']
                closed_back = data_15m['closes'][i] > sw['price']
                penetration = sw['price'] - data_15m['lows'][i] if wicked else 0
            else:
                wicked = data_15m['highs'][i] > sw['price']
                closed_back = data_15m['closes'][i] < sw['price']
                penetration = data_15m['highs'][i] - sw['price'] if wicked else 0
            
            if not (wicked and closed_back):
                continue
            
            # جودة السحب — ديناميكية
            quality = 0
            pen_atr = penetration / current_atr if current_atr > 0 else 0
            quality += min(30, pen_atr * 60)
            
            candle_range = data_15m['highs'][i] - data_15m['lows'][i]
            if candle_range > 0:
                if is_long:
                    rejection = (data_15m['closes'][i] - data_15m['lows'][i]) / candle_range
                else:
                    rejection = (data_15m['highs'][i] - data_15m['closes'][i]) / candle_range
                quality += rejection * 30
            
            age = i - si
            quality += min(20, age * 2)
            
            recency = (i - max(0, ctx_n - 15)) / max(1, 15)
            quality += recency * 20
            
            if quality > best_quality:
                best_quality = quality
                best_sweep = {
                    'level': sw['price'],
                    'sweep_index': i,
                    'sweep_ts': data_15m['timestamps'][i] if i < len(data_15m.get('timestamps', [])) else None,
                    'side': 'SSL' if is_long else 'BSL',
                    'wick_extreme': float(data_15m['lows'][i]) if is_long else float(data_15m['highs'][i]),
                    'quality': round(quality, 1),
                }
    
    # ═══ TP2: Draw on Liquidity من 15M ═══
    dealing_15 = find_dealing_range(data_15m)
    
    return {
        'state': 'SWEEP_FOUND' if best_sweep else 'WAITING',
        'sweep': best_sweep,
        'dealing_range': dealing_15,
        'atr': current_atr,
    }


# ═══════════════════════════════════════════
#  LAYER 3: TRIGGER — التأكيد (5M)
# ═══════════════════════════════════════════
# المصدر: 2022 Strategy:
# "5-minute for confirmation and execution"
# "Watch for MSS on lower timeframes"

def read_trigger(data_5m, narrative, bias_direction):
    """يبحث عن displacement+FVG بعد الـsweep على 5M."""
    if not data_5m or not narrative or narrative['state'] != 'SWEEP_FOUND':
        return {'ready': False}
    
    sweep = narrative['sweep']
    is_long = bias_direction == 'BULLISH'
    n = len(data_5m['closes'])
    
    if n < 20:
        return {'ready': False}
    
    # حدد أين يبدأ البحث (بعد الـsweep)
    sweep_ts = sweep.get('sweep_ts')
    search_from = 0
    if sweep_ts:
        for i, ts in enumerate(data_5m.get('timestamps', [])):
            if ts >= sweep_ts:
                search_from = i
                break
    if search_from == 0:
        search_from = max(0, n - 30)
    
    # ═══ displacement ديناميكي ═══
    atr_vals = _atr(data_5m['highs'], data_5m['lows'], data_5m['closes'])
    
    # حساب "rhythm" — متوسط جسم آخر 20 شمعة
    recent_bodies = [abs(data_5m['closes'][i] - data_5m['opens'][i]) for i in range(max(0, n-20), n)]
    avg_body = np.mean(recent_bodies) if recent_bodies else 1.0
    
    # التقلب: هل السوق هادي ولا عنيف
    current_atr = float(atr_vals[-1]) if n > 15 and atr_vals[-1] > 0 else abs(data_5m['closes'][-1] * 0.003)
    vol_ratio = np.mean([data_5m['highs'][i] - data_5m['lows'][i] for i in range(max(0,n-20), n)]) / current_atr if current_atr > 0 else 1.0
    
    if vol_ratio > 1.3:
        mult_threshold = 2.5
        body_pct_threshold = 0.70
    elif vol_ratio < 0.7:
        mult_threshold = 1.8
        body_pct_threshold = 0.55
    else:
        mult_threshold = 2.0
        body_pct_threshold = 0.60
    
    best_disp = None
    best_conviction = 0
    
    for i in range(max(search_from, 6), n):
        body = abs(data_5m['closes'][i] - data_5m['opens'][i])
        rng = data_5m['highs'][i] - data_5m['lows'][i]
        if rng <= 0 or body <= 0:
            continue
        
        body_pct = body / rng
        
        # مقارنة بآخر 5 شموع
        prev_bodies = [abs(data_5m['closes'][j] - data_5m['opens'][j]) for j in range(max(0, i-5), i)]
        if not prev_bodies or np.mean(prev_bodies) <= 0:
            continue
        body_multiple = body / np.mean(prev_bodies)
        
        if body_multiple < mult_threshold or body_pct < body_pct_threshold:
            continue
        
        direction = "BULLISH" if data_5m['closes'][i] > data_5m['opens'][i] else "BEARISH"
        if direction != bias_direction:
            continue
        
        # هل تركت FVG؟
        fvg = None
        if i >= 1 and i < n - 1:
            if is_long and data_5m['lows'][i+1] > data_5m['highs'][i-1]:
                fvg = {
                    'top': float(data_5m['lows'][i+1]),
                    'bottom': float(data_5m['highs'][i-1]),
                    'ce': float((data_5m['lows'][i+1] + data_5m['highs'][i-1]) / 2),
                    'direction': 'BULLISH',
                }
            elif not is_long and data_5m['highs'][i+1] < data_5m['lows'][i-1]:
                fvg = {
                    'top': float(data_5m['lows'][i-1]),
                    'bottom': float(data_5m['highs'][i+1]),
                    'ce': float((data_5m['lows'][i-1] + data_5m['highs'][i+1]) / 2),
                    'direction': 'BEARISH',
                }
        
        if not fvg:
            continue
        
        # حساب الاقتناع
        conviction = 0
        conviction += min(30, (body_multiple - mult_threshold) / mult_threshold * 60)
        conviction += min(30, (body_pct - body_pct_threshold) / (1 - body_pct_threshold) * 60)
        conviction += 25  # FVG bonus
        
        # إغلاق قرب الـextreme
        if is_long:
            close_strength = (data_5m['closes'][i] - data_5m['lows'][i]) / rng
        else:
            close_strength = (data_5m['highs'][i] - data_5m['closes'][i]) / rng
        conviction += close_strength * 15
        
        if conviction > best_conviction:
            best_conviction = conviction
            best_disp = {
                'index': i,
                'direction': direction,
                'body_multiple': round(body_multiple, 2),
                'body_pct': round(body_pct * 100, 1),
                'conviction': round(min(100, conviction), 1),
                'fvg': fvg,
            }
    
    if not best_disp:
        return {'ready': False, 'reason': 'NO_DISPLACEMENT_WITH_FVG'}
    
    # هل الـFVG لسا نشطة؟
    fvg = best_disp['fvg']
    disp_idx = best_disp['index']
    for i in range(disp_idx + 2, n):
        if is_long and data_5m['lows'][i] <= fvg['bottom']:
            return {'ready': False, 'reason': 'FVG_ALREADY_FILLED'}
        if not is_long and data_5m['highs'][i] >= fvg['top']:
            return {'ready': False, 'reason': 'FVG_ALREADY_FILLED'}
    
    return {
        'ready': True,
        'displacement': best_disp,
        'fvg': fvg,
    }


# ═══════════════════════════════════════════
#  LAYER 4: EXECUTION — بناء الخطة
# ═══════════════════════════════════════════

def build_plan(data_5m, data_htf, trigger, narrative, bias):
    """يبني خطة كاملة: entry + SL + TP1 + TP2."""
    if not trigger or not trigger['ready']:
        return None
    
    fvg = trigger['fvg']
    sweep = narrative['sweep']
    is_long = bias['direction'] == 'BULLISH'
    n = len(data_5m['closes'])
    
    # ═══ ENTRY: CE (midpoint of FVG) ═══
    # المصدر: "CE is the most reactive level inside the gap"
    entry = fvg['ce']
    
    # ═══ STOP LOSS: هيكلي ═══
    atr_vals = _atr(data_5m['highs'], data_5m['lows'], data_5m['closes'])
    current_atr = float(atr_vals[-1]) if n > 15 and atr_vals[-1] > 0 else abs(entry * 0.003)
    
    # جمع نقاط الإبطال
    candidates = [sweep['wick_extreme']]
    
    swings_5m = detect_ict_three_candle_swings(data_5m)
    if is_long:
        lower_swings = [s['price'] for s in swings_5m['swing_lows'] if s['price'] < entry]
        if lower_swings:
            candidates.append(min(lower_swings))
        candidates.append(fvg['bottom'])
        sl_base = min(candidates)
    else:
        upper_swings = [s['price'] for s in swings_5m['swing_highs'] if s['price'] > entry]
        if upper_swings:
            candidates.append(max(upper_swings))
        candidates.append(fvg['top'])
        sl_base = max(candidates)
    
    # Buffer ديناميكي
    buffer = current_atr * 0.15
    sl = sl_base - buffer if is_long else sl_base + buffer
    
    risk = abs(entry - sl)
    
    # فحص: هل المخاطرة منطقية؟
    if risk < current_atr * 0.5:
        return None  # ضيق جداً
    if risk > current_atr * 8:
        return None  # واسع جداً
    
    # ═══ TP1: Low Hanging Fruit ═══
    tp1_candidates = []
    
    target_swings = swings_5m['swing_highs'] if is_long else swings_5m['swing_lows']
    for sw in target_swings:
        if (is_long and sw['price'] > entry) or (not is_long and sw['price'] < entry):
            dist = abs(sw['price'] - entry)
            rr = dist / risk if risk > 0 else 0
            if rr >= 1.5:
                tp1_candidates.append({'price': sw['price'], 'kind': 'SWING', 'rr': round(rr, 2), 'dist': dist})
    
    # Fib -1.0
    impulse = abs(entry - sweep['wick_extreme'])
    fib1 = entry + impulse if is_long else entry - impulse
    fib1_rr = impulse / risk if risk > 0 else 0
    if fib1_rr >= 1.5:
        tp1_candidates.append({'price': round(fib1, 6), 'kind': 'FIB_-1.0', 'rr': round(fib1_rr, 2), 'dist': impulse})
    
    tp1_candidates.sort(key=lambda c: c['dist'])
    tp1 = tp1_candidates[0] if tp1_candidates else None
    if not tp1:
        return None
    
    # ═══ TP2: Draw on Liquidity (HTF) ═══
    tp2 = None
    if data_htf and len(data_htf.get('closes', [])) > 10:
        htf_swings = detect_ict_three_candle_swings(data_htf)
        htf_targets = htf_swings['swing_highs'] if is_long else htf_swings['swing_lows']
        
        for sw in htf_targets:
            if (is_long and sw['price'] > entry + risk * 3) or (not is_long and sw['price'] < entry - risk * 3):
                dist = abs(sw['price'] - entry)
                rr = dist / risk if risk > 0 else 0
                if not tp2 or dist < abs(tp2['price'] - entry):
                    tp2 = {'price': sw['price'], 'kind': 'HTF_DRAW', 'rr': round(rr, 2)}
    
    if not tp2:
        fib2 = entry + impulse * 2 if is_long else entry - impulse * 2
        fib2_rr = (impulse * 2) / risk if risk > 0 else 0
        if fib2_rr >= 3:
            tp2 = {'price': round(fib2, 6), 'kind': 'FIB_-2.0', 'rr': round(fib2_rr, 2)}
    
    if not tp2:
        tp2 = {'mode': 'OPEN_TRAILING', 'kind': 'TRAIL'}
    
    return {
        'entry': round(entry, 6),
        'sl': round(sl, 6),
        'tp1': tp1,
        'tp2': tp2,
        'risk': round(risk, 2),
        'atr': round(current_atr, 2),
        'sl_atr': round(risk / current_atr, 2) if current_atr > 0 else 0,
        'conviction': trigger['displacement']['conviction'],
        'sweep_quality': narrative['sweep']['quality'],
    }


# ═══════════════════════════════════════════
#  TRADE MANAGER — إدارة ذكية
# ═══════════════════════════════════════════
# المصدر: 2022 Notes:
# "trailing stop below previous bullish OB's low"
# "down-closed candles should support price" (bullish)
#
# الـTrailing على 15M structure (مش 5M!)
# المصدر: ICT Core Content: "higher TFs give conviction, lower give precision"

def manage_trade(candle, state, candle_15m=None):
    """
    يدير الصفقة شمعة بشمعة.
    
    candle = {o, h, l, c} على 5M
    candle_15m = {o, h, l, c} على 15M (للـtrailing)
    state = حالة الصفقة
    """
    h, l, c, o = candle['h'], candle['l'], candle['c'], candle.get('o', candle['c'])
    is_short = state['is_short']
    events = []
    closed = False
    
    # ═══ قبل TP1 ═══
    if not state.get('tp1_hit'):
        if (is_short and h >= state['sl']) or (not is_short and l <= state['sl']):
            state['exit_price'] = state['sl']
            state['exit_reason'] = 'SL_HIT'
            state['pnl_pct'] = -abs(state['entry'] - state['sl']) / state['entry'] * 100
            events.append('❌ SL')
            return events, True
        
        tp1_price = state.get('tp1')
        if tp1_price:
            if (is_short and l <= tp1_price) or (not is_short and h >= tp1_price):
                state['tp1_hit'] = True
                state['tp1_pnl'] = abs(tp1_price - state['entry']) / state['entry'] * 100 * 0.5
                state['sl'] = state['entry']  # BE
                state['trail_level'] = state['entry']
                events.append('🎯 TP1+BE')
    
    # ═══ بعد TP1: Runner مع فترة تنفس ═══
    # المصدر: مايكل 2022 Notes:
    # "down-closed candles should support price"
    # Structure يحتاج وقت ليتشكل — مش فوراً بعد TP1
    # خلال فترة التنفس: SL عند BE = محميين بلا مخاطرة
    elif state.get('tp1_hit') and not closed:
        # عدّاد شموع بعد TP1
        state['candles_after_tp1'] = state.get('candles_after_tp1', 0) + 1
        
        # TP2 — دائماً مراقب (حتى خلال فترة التنفس)
        tp2 = state.get('tp2')
        if isinstance(tp2, dict) and tp2.get('price'):
            if (is_short and l <= tp2['price']) or (not is_short and h >= tp2['price']):
                state['exit_price'] = tp2['price']
                state['exit_reason'] = 'TP2_GOLDEN'
                tp2_pnl = abs(tp2['price'] - state['entry']) / state['entry'] * 100 * 0.5
                state['pnl_pct'] = state.get('tp1_pnl', 0) + tp2_pnl
                events.append('🏆 TP2!')
                return events, True
        
        # Trailing stop check
        if (is_short and h >= state['sl']) or (not is_short and l <= state['sl']):
            state['exit_price'] = state['sl']
            state['exit_reason'] = 'TRAIL_EXIT'
            trail_pnl = abs(state['sl'] - state['entry']) / state['entry'] * 100 * 0.5
            state['pnl_pct'] = state.get('tp1_pnl', 0) + trail_pnl
            events.append('🧠 Trail')
            return events, True
        
        # ═══ الـTrailing: يتبع structure حقيقي فقط ═══
        # المصدر: "trailing stop below previous down-closed candle"
        # "Structure حقيقي" = شمعة اتجاهية بجسم قوي (>40% من range)
        # + buffer واسع (0.15 ATR) لامتصاص الـnoise
        
        # ═══ TRAILING الذكي: structure فقط ═══
        # المصدر: "trailing stop below previous down-closed candle"
        # المصدر: blofin.com: "Structure-based trailing with 0.5x ATR buffer"
        # شمعة اتجاهية بجسم قوي = structure حقيقي
        # buffer واسع = يمتص الـnoise
        atr = state.get('atr', abs(state['entry'] * 0.001))
        buffer = atr * 0.15
        
        if not is_short:
            # Long: شمعة صعودية بجسم حقيقي (مش doji)
            body = c - o
            rng = h - l
            if body > 0 and rng > 0 and body / rng > 0.4:
                new_support = l - buffer
                if new_support > state.get('trail_level', state['entry']):
                    if new_support > state['sl']:
                        state['sl'] = new_support
                        state['trail_level'] = new_support
                        events.append(f'📈 Trail→{new_support:.0f}')
        else:
            body = o - c
            rng = h - l
            if body > 0 and rng > 0 and body / rng > 0.4:
                new_resistance = h + buffer
                if new_resistance < state.get('trail_level', state['entry']):
                    if new_resistance < state['sl']:
                        state['sl'] = new_resistance
                        state['trail_level'] = new_resistance
                        events.append(f'📉 Trail→{new_resistance:.0f}')
    
    return events, False
