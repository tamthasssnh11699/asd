import sys
sys.path.insert(0, ".")
from data_manager import DataManager
from ict_math_engine import detect_mss, compute_mechanical_bias_anchor

dm = DataManager()
data = dm.get_ohlcv("SOLUSDT", "15m", 150, output_format="dict")
mss = detect_mss(data, swing_window=3)
print("Swing Highs:")
for h in mss.get('swing_highs', [])[-5:]:
    print(f"Index {h['index']}: {h['price']}")
print("Swing Lows:")
for l in mss.get('swing_lows', [])[-5:]:
    print(f"Index {l['index']}: {l['price']}")

bias = compute_mechanical_bias_anchor(data)
print("\nBIAS:")
print(bias)
