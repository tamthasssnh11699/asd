# -*- coding: utf-8 -*-
"""
ict_trade_engine.py — محرك الصفقة الكامل بمنهجية مايكل
═══════════════════════════════════════════════════════════
الدخول + الستوب + TP1 + TP2 + إدارة الصفقة + Trailing + الخروج

كل قرار مرجعه مصدر رسمي. لا أرقام مخترعة.

المصادر:
- 2022 Mentorship Notes (Ep2-Ep8)
- innercircletrader.net: OTE, Fib Settings, MSS, OB, FVG guides
- 2024 Mentorship Lecture 1-2
"""
import numpy as np
from ict_math_engine import detect_ict_three_candle_swings, _atr


class ICTTradeEngine:
    """
    يتولى كل شي بعد ما النموذج يقرر "في setup":
    1. أين الدخول بالضبط
    2. أين الستوب بالضبط  
    3. أين TP1 (الهدف القريب — low hanging fruit)
    4. أين TP2 (Draw on Liquidity — الهدف الذهبي على HTF)
    5. إدارة الصفقة شمعة بشمعة
    """
    
    # ══════════════════════════════════════════════════════
    # ENTRY PLACEMENT
    # ══════════════════════════════════════════════════════
    @staticmethod
    def compute_entry(fvg, is_long):
        """
        المصدر: innercircletrader.net FVG guide:
        "Consequent encroachment is the 50% midpoint of the FVG.
         It is often the most reactive level inside the gap"
        
        المصدر: 2024 Mentorship Lecture 2:
        "Enter at the CE of the IFVG"
        
        لكن: مايكل أيضاً يذكر الدخول عند حافة الـFVG (IOFED):
        innercircletrader.net: "IOFED is the very edge of the FVG —
         the earliest possible entry"
        
        الحل الذكي: نقدم خيارين:
        - aggressive_entry = IOFED (حافة FVG — أقرب للسعر = SL أوسع نسبياً)
        - standard_entry = CE (منتصف FVG — المكان الأكثر تفاعلاً)
        """
        ce = (fvg['top'] + fvg['bottom']) / 2
        
        if is_long:
            # Bullish: IOFED = أعلى حافة FVG (أول نقطة السعر يلمسها عند النزول)
            iofed = fvg['top']
        else:
            # Bearish: IOFED = أدنى حافة FVG
            iofed = fvg['bottom']
        
        return {
            'standard': round(ce, 6),      # CE — الأكثر تفاعلاً
            'aggressive': round(iofed, 6),  # IOFED — أبكر دخول ممكن
        }
    
    # ══════════════════════════════════════════════════════
    # STOP LOSS PLACEMENT
    # ══════════════════════════════════════════════════════
    @staticmethod
    def compute_stop_loss(data_5m, sweep, fvg, entry_price, is_long):
        """
        المصدر: innercircletrader.net "Complete ICT Trading Strategy 2022":
        "stop loss beyond the swept extreme"
        
        المصدر: innercircletrader.net OTE guide:
        "trail the stop to break-even after the first 1:1 of risk-to-reward"
        
        المصدر: innercircletrader.net Fib Settings:
        "stop loss should sit 10 to 20 pips below the 1.0 fibonacci level"
        "Stops parked exactly at the level get hunted on the wick.
         The buffer is non-negotiable."
        
        المصدر: 2022 Notes:
        "trailing stop losses below the previous down-closed candle/
         bullish order block's low"
        
        الحل الذكي — طبقات:
        1. الأساس: خلف الـswept extreme (الـwick الأبعد)
        2. التأكيد: خلف أقرب swing حقيقي تحت/فوق الدخول
        3. اختيار الأبعد (الأوسع) بينهما → حماية أفضل
        4. إضافة buffer ديناميكي (مش ثابت)
        5. فحص minimum distance (إذا ضيق جداً → لا صفقة)
        """
        n = len(data_5m['closes'])
        atr_vals = _atr(data_5m['highs'], data_5m['lows'], data_5m['closes'])
        current_atr = atr_vals[-1] if len(atr_vals) > 0 and atr_vals[-1] > 0 else abs(entry_price * 0.003)
        
        # الطبقة 1: خلف swept extreme
        swept_extreme = sweep['wick_extreme']
        
        # الطبقة 2: خلف أقرب swing حقيقي
        swings = detect_ict_three_candle_swings(data_5m)
        
        if is_long:
            relevant_swings = [s['price'] for s in swings['swing_lows'] 
                             if s['price'] < entry_price]
            nearest_swing = max(relevant_swings) if relevant_swings else None
            
            # اختر الأبعد (الأوسع = أكثر حماية)
            # المصدر: "the widest one defines the structural invalidation"
            candidates = [swept_extreme]
            if nearest_swing is not None:
                candidates.append(nearest_swing)
            sl_base = min(candidates)  # أدنى نقطة = أوسع حماية لـLong
        else:
            relevant_swings = [s['price'] for s in swings['swing_highs']
                             if s['price'] > entry_price]
            nearest_swing = min(relevant_swings) if relevant_swings else None
            
            candidates = [swept_extreme]
            if nearest_swing is not None:
                candidates.append(nearest_swing)
            sl_base = max(candidates)  # أعلى نقطة = أوسع حماية لـShort
        
        # الطبقة 3: buffer ديناميكي
        # المصدر: "10 to 20 pips" على Forex. للكريبتو: نسبة من ATR
        # 15% من ATR = buffer كافي لامتصاص الـwick الإضافي
        buffer = current_atr * 0.15
        
        if is_long:
            sl_price = sl_base - buffer
        else:
            sl_price = sl_base + buffer
        
        # الطبقة 4: minimum distance check
        # المصدر: مايكل Ep6 36:06: "وإذا كانت المخاطرة كبيرة: لا تأخذ الصفقة"
        # العكس أيضاً صحيح: إذا المخاطرة صغيرة جداً = SL سيُضرب بالnoise
        min_sl_distance = current_atr * 0.5  # نصف ATR = minimum معقول
        actual_distance = abs(entry_price - sl_price)
        
        if actual_distance < min_sl_distance:
            # نوسع الـSL لـminimum بدل ما نرفض الصفقة
            # (مايكل يقول "you want a lot of range when starting out")
            if is_long:
                sl_price = entry_price - min_sl_distance
            else:
                sl_price = entry_price + min_sl_distance
            actual_distance = min_sl_distance
        
        return {
            'price': round(sl_price, 6),
            'distance': round(actual_distance, 2),
            'distance_pct': round(actual_distance / entry_price * 100, 4),
            'atr': round(current_atr, 2),
            'sl_in_atr': round(actual_distance / current_atr, 2),
            'method': 'WIDEST_OF_SWEEP_AND_SWING + ATR_BUFFER',
        }
    
    # ══════════════════════════════════════════════════════
    # TARGET PLACEMENT
    # ══════════════════════════════════════════════════════
    @staticmethod
    def compute_targets(data_5m, data_htf, entry_price, sl_price, sweep, is_long):
        """
        المصدر: 2022 Mentorship Notes Ep2:
        "We want to use the closest target (low-hanging fruit)"
        "partials should be taken below each low (sell side liquidity)"
        "Targets can be placed below 50% of that swing move"
        
        المصدر: innercircletrader.net Fib Settings:
        "-0.27 — short-term internal target"
        "-1.0 — 1× the leg target"
        "-2.0 — full standard deviation, prior session highs/lows"
        "Taking partials at -1.0 and trailing the rest toward -2.0"
        
        المصدر: 2022 Notes:
        "Exit – where the liquidity is – prior buy stops"
        "The Draw on Liquidity is found on the Daily Chart"
        
        ═══ الهيكل: TP1 قريب + TP2 بعيد (Draw on Liquidity) ═══
        
        TP1 (50% position — low hanging fruit):
        - أقرب مستوى سيولة على فريم الدخول (5m/15m)
        - أو Fib -1.0 extension من الـimpulse leg
        - أيهما أقرب (conservative)
        
        TP2 (50% position — Draw on Liquidity / Runner):
        - مستوى سيولة على HTF (Daily/4H)
        - أو Fib -2.0 إلى -2.5 extension
        - Session high/low
        - Previous day high/low
        - هذا الهدف "الذهبي" اللي بيعطي RR 4-5+
        """
        risk = abs(entry_price - sl_price)
        if risk <= 0:
            return {'tp1': None, 'tp2': None, 'error': 'ZERO_RISK'}
        
        # ═══ TP1: Low Hanging Fruit (LTF) ═══
        swings_5m = detect_ict_three_candle_swings(data_5m)
        n5 = len(data_5m['closes'])
        
        tp1_candidates = []
        
        # مصدر 1: أقرب swing على 5m
        target_swings = swings_5m['swing_highs'] if is_long else swings_5m['swing_lows']
        for sw in target_swings:
            if (is_long and sw['price'] > entry_price) or \
               (not is_long and sw['price'] < entry_price):
                dist = abs(sw['price'] - entry_price)
                rr = dist / risk
                if rr >= 1.5:  # minimum 1.5R لـTP1
                    tp1_candidates.append({
                        'price': sw['price'], 'kind': 'SWING_LTF',
                        'rr': round(rr, 2), 'dist': dist,
                    })
        
        # مصدر 2: Fib -1.0 extension
        # المصدر: "symmetrical projection, typical 1× the leg target"
        sweep_extreme = sweep['wick_extreme']
        impulse_leg = abs(entry_price - sweep_extreme)
        if is_long:
            fib_1_0 = entry_price + impulse_leg
        else:
            fib_1_0 = entry_price - impulse_leg
        
        fib_rr = impulse_leg / risk
        if fib_rr >= 1.5:
            tp1_candidates.append({
                'price': round(fib_1_0, 6), 'kind': 'FIB_-1.0',
                'rr': round(fib_rr, 2), 'dist': impulse_leg,
            })
        
        # اختر الأقرب (low hanging fruit)
        tp1_candidates.sort(key=lambda c: c['dist'])
        tp1 = tp1_candidates[0] if tp1_candidates else None
        
        # ═══ TP2: Draw on Liquidity (HTF) — الهدف الذهبي ═══
        tp2 = None
        tp2_candidates = []
        
        if data_htf and len(data_htf.get('closes', [])) > 10:
            swings_htf = detect_ict_three_candle_swings(data_htf)
            htf_targets = swings_htf['swing_highs'] if is_long else swings_htf['swing_lows']
            
            for sw in htf_targets:
                if (is_long and sw['price'] > entry_price + risk * 3) or \
                   (not is_long and sw['price'] < entry_price - risk * 3):
                    dist = abs(sw['price'] - entry_price)
                    rr = dist / risk
                    tp2_candidates.append({
                        'price': sw['price'], 'kind': 'HTF_SWING_DRAW',
                        'rr': round(rr, 2), 'dist': dist,
                    })
        
        # Fib -2.0 extension (Draw on Liquidity projection)
        if is_long:
            fib_2_0 = entry_price + impulse_leg * 2
        else:
            fib_2_0 = entry_price - impulse_leg * 2
        
        fib2_rr = (impulse_leg * 2) / risk
        if fib2_rr >= 3:
            tp2_candidates.append({
                'price': round(fib_2_0, 6), 'kind': 'FIB_-2.0',
                'rr': round(fib2_rr, 2), 'dist': impulse_leg * 2,
            })
        
        if tp2_candidates:
            # اختر الأقرب من HTF targets اللي يعطي RR عالي
            tp2_candidates.sort(key=lambda c: c['dist'])
            tp2 = tp2_candidates[0]
        else:
            # ما فيه مستوى HTF واضح → OPEN_TRAILING
            tp2 = {'mode': 'OPEN_TRAILING', 'kind': 'STRUCTURAL_TRAIL',
                    'detail': 'No clear HTF draw — trail behind structure'}
        
        return {'tp1': tp1, 'tp2': tp2}
    
    # ══════════════════════════════════════════════════════
    # TRADE MANAGEMENT — شمعة بشمعة
    # ══════════════════════════════════════════════════════
    @staticmethod
    def manage_trade(candle, trade_state):
        """
        المصدر: 2022 Mentorship Notes:
        "trailing stop losses below the previous down-closed candle/
         bullish order block's low"
        "If your ITH is broken to the upside and you're bearish,
         your idea was wrong, move to the sidelines"
        
        المصدر: innercircletrader.net OTE guide:
        "trail the stop to break-even after the first 1:1"
        
        المصدر: innercircletrader.net Fib Settings:
        "Taking partials at -1.0 and trailing the rest toward -2.0"
        
        ═══ المراحل ═══
        
        Phase 0: قبل الدخول (Limit Order معلق)
        Phase 1: بعد الدخول، قبل TP1
          - SL ثابت. لا حركة.
          - مايكل لا يحرك الستوب قبل TP1 (يتقبل المخاطرة)
        
        Phase 2: TP1 ضُرب
          - 50% يُغلق = ربح مضمون
          - SL ينتقل لـBE (سعر الدخول بالضبط)
          - المصدر: "Closing trades at 50% of the new highs and lows"
        
        Phase 3: Runner (50% المتبقي)
          - Trailing stop خلف آخر swing مؤكد
          - المصدر: "trailing stop below previous bullish OB's low"
          - كل swing جديد بالاتجاه → SL يتقدم خلفه
          - SL لا يتراجع أبداً
          - إذا TP2 ضُرب → إغلاق كامل + ربح ذهبي
          - إذا trailing ضُرب → إغلاق بربح جزئي
        
        Phase 4: Invalidation (متى ننسحب فوراً)
          - المصدر: "If your ITH is broken... your idea was wrong"
          - إذا السعر كسر الـsweep extreme بإغلاق → القصة انتهت
        """
        t = trade_state
        h, l, c = candle['h'], candle['l'], candle['c']
        is_short = t['is_short']
        events = []
        closed = False
        
        # ═══ Phase 1: قبل TP1 ═══
        if not t.get('tp1_hit'):
            # SL check
            if (is_short and h >= t['sl']) or (not is_short and l <= t['sl']):
                t['exit_price'] = t['sl']
                t['exit_reason'] = 'SL_HIT_BEFORE_TP1'
                t['pnl_pct'] = -abs(t['entry'] - t['sl']) / t['entry'] * 100
                events.append('❌ SL HIT — full loss')
                closed = True
                return events, closed
            
            # TP1 check
            if t.get('tp1'):
                if (is_short and l <= t['tp1']) or (not is_short and h >= t['tp1']):
                    t['tp1_hit'] = True
                    t['tp1_pnl'] = abs(t['tp1'] - t['entry']) / t['entry'] * 100 * 0.5
                    # Move to BE
                    t['sl'] = t['entry']
                    t['phase'] = 'RUNNER'
                    events.append(f"🎯 TP1 HIT — 50% closed @ {t['tp1']:.2f}, SL→BE")
        
        # ═══ Phase 2+3: Runner (بعد TP1) ═══
        elif t.get('tp1_hit') and not closed:
            # TP2 check (الهدف الذهبي)
            if t.get('tp2') and t['tp2'].get('price'):
                tp2_price = t['tp2']['price']
                if (is_short and l <= tp2_price) or (not is_short and h >= tp2_price):
                    t['tp2_hit'] = True
                    t['exit_price'] = tp2_price
                    t['exit_reason'] = 'TP2_HIT_GOLDEN'
                    tp2_pnl = abs(tp2_price - t['entry']) / t['entry'] * 100 * 0.5
                    t['pnl_pct'] = t['tp1_pnl'] + tp2_pnl
                    events.append(f"🏆 TP2 HIT — runner closed @ {tp2_price:.2f}")
                    closed = True
                    return events, closed
            
            # Trailing stop check
            if (is_short and h >= t['sl']) or (not is_short and l <= t['sl']):
                t['exit_price'] = t['sl']
                t['exit_reason'] = 'TRAILING_STOP'
                trail_pnl = abs(t['sl'] - t['entry']) / t['entry'] * 100 * 0.5
                t['pnl_pct'] = t['tp1_pnl'] + trail_pnl
                events.append(f"🧠 Trailing stop hit @ {t['sl']:.2f}")
                closed = True
                return events, closed
            
            # Update trailing stop — خلف آخر swing مؤكد
            # المصدر: "trailing stop below previous down-closed candle"
            # نستخدم البيانات المتراكمة لحد هلق
            if not is_short:
                # Long: trail خلف آخر higher low
                if l > t.get('last_trail_low', 0) and l > t['entry']:
                    if t.get('prev_low') and l > t['prev_low']:
                        # Swing low مؤكد (HL)
                        new_sl = t['prev_low']
                        if new_sl > t['sl']:
                            t['sl'] = new_sl
                            events.append(f"📈 Trail → {new_sl:.2f}")
                    t['prev_low'] = l
                    t['last_trail_low'] = l
            else:
                # Short: trail خلف آخر lower high
                if h < t.get('last_trail_high', float('inf')) and h < t['entry']:
                    if t.get('prev_high') and h < t['prev_high']:
                        new_sl = t['prev_high']
                        if new_sl < t['sl']:
                            t['sl'] = new_sl
                            events.append(f"📉 Trail → {new_sl:.2f}")
                    t['prev_high'] = h
                    t['last_trail_high'] = h
        
        return events, closed


def build_complete_trade(setup_result, data_5m, data_htf=None):
    """
    من setup → خطة كاملة جاهزة للتنفيذ.
    يأخذ نتيجة evaluate_ict_2022_model ويبني الخطة الكاملة.
    """
    if not setup_result or setup_result['stage'] not in ('READY', 'WAITING_FOR_FVG_RETEST'):
        return None
    if not setup_result.get('plan') or not setup_result.get('sweep') or not setup_result.get('fvg'):
        return None
    
    fvg = setup_result['fvg']
    sweep = setup_result['sweep']
    is_long = setup_result['plan']['direction'] == 'BUY_LIMIT'
    
    engine = ICTTradeEngine()
    
    # 1. Entry
    entry_options = engine.compute_entry(fvg, is_long)
    entry_price = entry_options['standard']  # CE as default
    
    # 2. Stop Loss
    sl_result = engine.compute_stop_loss(data_5m, sweep, fvg, entry_price, is_long)
    sl_price = sl_result['price']
    
    # 3. Targets
    targets = engine.compute_targets(data_5m, data_htf, entry_price, sl_price, sweep, is_long)
    
    if not targets.get('tp1'):
        return None
    
    tp1 = targets['tp1']
    tp2 = targets['tp2']
    
    risk = abs(entry_price - sl_price)
    
    return {
        'direction': 'BUY_LIMIT' if is_long else 'SELL_LIMIT',
        'entry': entry_price,
        'entry_options': entry_options,
        'sl': sl_price,
        'sl_detail': sl_result,
        'tp1': tp1,
        'tp2': tp2,
        'risk': round(risk, 2),
        'rr_tp1': tp1['rr'],
        'rr_tp2': tp2.get('rr', 'TRAILING'),
        'narrative': setup_result.get('plan', {}).get('basis', ''),
    }
