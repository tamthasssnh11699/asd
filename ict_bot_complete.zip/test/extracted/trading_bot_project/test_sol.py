import sys
sys.path.insert(0, ".")
from data_manager import DataManager
from ict_math_engine import compute_mechanical_bias_anchor

dm = DataManager()
data = dm.get_ohlcv("SOL-USDT", "15m", 100, output_format="dict")
if not data:
    data = dm.get_ohlcv("SOL/USDT", "15m", 100, output_format="dict")

print(f"Latest candle: time={data['timestamps'][-1]}, open={data['opens'][-1]}, high={data['highs'][-1]}, low={data['lows'][-1]}, close={data['closes'][-1]}")
print(f"Previous candle: time={data['timestamps'][-2]}, open={data['opens'][-2]}, high={data['highs'][-2]}, low={data['lows'][-2]}, close={data['closes'][-2]}")

bias = compute_mechanical_bias_anchor(data)
print(bias)
