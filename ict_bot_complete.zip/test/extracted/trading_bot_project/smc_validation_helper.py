# -*- coding: utf-8 -*-
"""
SMC Validation Helper — uses the smartmoneyconcepts library as an
independent cross-check against our ict_math_engine functions.

NOT used in production — purely for testing/validation.
"""
import pandas as pd
import numpy as np
from smartmoneyconcepts import smc


def dict_to_df(data):
    """Convert our OHLCV dict to pandas DataFrame expected by smc."""
    df = pd.DataFrame({
        'open': data.get('opens', data.get('closes', [])),
        'high': data['highs'],
        'low': data['lows'],
        'close': data['closes'],
        'volume': data.get('volumes', [100]*len(data['closes'])),
    })
    return df


def validate_fvg_against_smc(data):
    """Cross-check our FVG detection against smartmoneyconcepts."""
    from ict_math_engine import detect_fair_value_gaps
    
    df = dict_to_df(data)
    n = len(df)
    
    # Our detection
    ours = detect_fair_value_gaps(data, lookback=n, require_displacement=False)
    our_bull = set()
    for f in ours['bullish_fvgs']:
        idx = f['index_from_end'] + n
        our_bull.add(idx)
    our_bear = set()
    for f in ours['bearish_fvgs']:
        idx = f['index_from_end'] + n
        our_bear.add(idx)
    
    # SMC detection
    smc_result = smc.fvg(df)
    smc_bull = set()
    smc_bear = set()
    for i in range(len(smc_result)):
        row = smc_result.iloc[i]
        if row['FVG'] == 1:
            smc_bull.add(i)
        elif row['FVG'] == -1:
            smc_bear.add(i)
    
    return {
        'our_bullish': our_bull,
        'our_bearish': our_bear,
        'smc_bullish': smc_bull,
        'smc_bearish': smc_bear,
        'bull_match': our_bull == smc_bull,
        'bear_match': our_bear == smc_bear,
        'bull_only_ours': our_bull - smc_bull,
        'bull_only_smc': smc_bull - our_bull,
        'bear_only_ours': our_bear - smc_bear,
        'bear_only_smc': smc_bear - our_bear,
    }


def validate_swing_against_smc(data, swing_length=1):
    """Cross-check our three-candle swings against smc (with swing_length=1 for 3-candle)."""
    from ict_math_engine import detect_ict_three_candle_swings
    
    df = dict_to_df(data)
    
    # Our detection
    ours = detect_ict_three_candle_swings(data)
    our_highs = set(s['index'] for s in ours['swing_highs'])
    our_lows = set(s['index'] for s in ours['swing_lows'])
    
    # SMC detection with swing_length=1 (should be equivalent to 3-candle)
    smc_result = smc.swing_highs_lows(df, swing_length=swing_length)
    smc_highs = set()
    smc_lows = set()
    for i in range(len(smc_result)):
        row = smc_result.iloc[i]
        if row['HighLow'] == 1:
            smc_highs.add(i)
        elif row['HighLow'] == -1:
            smc_lows.add(i)
    
    return {
        'our_highs': our_highs,
        'our_lows': our_lows,
        'smc_highs': smc_highs,
        'smc_lows': smc_lows,
        'highs_match': our_highs == smc_highs,
        'lows_match': our_lows == smc_lows,
    }
