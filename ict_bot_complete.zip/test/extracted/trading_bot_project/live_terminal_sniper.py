import sys, time, datetime
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
import pytz

brain = BrainCore()
ae = AuthenticityEngine()
WATCHING_SYMBOLS = ["ETH/USDT", "BTC/USDT", "SOL/USDT", "XRP/USDT"]
ny_tz = pytz.timezone('America/New_York')

# ذاكرة البوت الحية
active_trades = {}
ignored_signals = set()

def print_banner(msg):
    print(f"\n{'='*70}")
    print(f"  {msg}")
    print(f"{'='*70}")

def scan_markets():
    for symbol in WATCHING_SYMBOLS:
        try:
            # 1. جلب البيانات اللحظية
            data_15m = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", int(time.time()*1000), limit=200)
            if not data_15m or not data_15m['closes']: continue
            
            # 2. تحديد الاتجاه رياضياً
            anchor = compute_mechanical_bias_anchor(data_15m, lookback=150)
            bias = anchor.get("anchor_direction")
            if bias not in ["BULLISH", "BEARISH"]: continue
            
            # 3. رصد السحب (Sweep)
            sig = ae.detect_significant_swings(data_15m, swing_window=1, lookback_candles=150)
            is_swept, swept_level = False, 0
            
            levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
            for cand in levels:
                res = classify_sweep_or_run(data_15m, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=len(data_15m['closes'])-1)
                if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                    is_swept, swept_level = True, cand["price"]
                    break
            
            # 4. التأكيد والدخول
            if is_swept:
                data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                res_5m = evaluate_all_entry_models(data_5m, bias)
                status = res_5m.get("final_status")
                
                sig_id = f"{symbol}_{swept_level}"
                if status == "READY" and sig_id not in ignored_signals and symbol not in active_trades:
                    plan = res_5m.get("chosen_model", {}).get("plan", {})
                    entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                    
                    if entry and sl and tp1:
                        print_banner(f"🚨 فرصة قنص حية تم رصدها: {symbol}")
                        print(f"القرار: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'}")
                        print(f"الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف: {tp1:.4f}")
                        print(">> جاري تفعيل المراقبة اللحظية لهذه الصفقة...")
                        
                        active_trades[symbol] = {
                            "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                            "current_sl": sl, "be_activated": False, "tp1_hit": False,
                            "is_short": bias == "BEARISH", "risk": abs(entry - sl)
                        }
                        ignored_signals.add(sig_id)

        except Exception as e:
            pass

def update_active_trades():
    for symbol, t in list(active_trades.items()):
        try:
            # جلب آخر شمعة دقيقة/5دقائق للحركة اللحظية
            data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=20)
            if not data_5m or not data_5m['closes']: continue
            
            h = data_5m['highs'][-1]
            l = data_5m['lows'][-1]
            c = data_5m['closes'][-1]
            now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz).strftime('%H:%M:%S')
            
            # طباعة السعر اللحظي
            print(f"[{now_ny}] 👁️ مراقبة {symbol} | السعر: {c:.4f} | الستوب الحالي: {t['current_sl']:.4f}")
            
            risk = t['risk']
            entry = t['entry']
            
            if t['is_short']:
                # 1. هل انضرب الستوب؟
                if h >= t['current_sl']:
                    if t['current_sl'] == t['sl']: print_banner(f"❌ {symbol}: ضرب الستوب لوس الأصلي!")
                    elif t['current_sl'] == entry: print_banner(f"🛡️ {symbol}: خروج على الدخول (Break-Even) بأمان.")
                    else: print_banner(f"🧠 {symbol}: ضرب الستوب المتتبع! خروج بأرباح ممتازة.")
                    del active_trades[symbol]
                    continue
                
                # 2. هل انضرب الهدف الجزئي؟
                if l <= t['tp1'] and not t['tp1_hit']:
                    print_banner(f"🎯 {symbol}: ضرب الهدف الأول! تم أخذ 80% من الأرباح. تأمين الصفقة.")
                    t['tp1_hit'] = True
                    t['be_activated'] = True
                    t['current_sl'] = entry
                    
                # 3. التأمين المبدئي 1.5R
                if l <= (entry - 1.5*risk) and not t['be_activated']:
                    print(f"🛡️ [{now_ny}] {symbol}: السعر تجاوز 1.5R. نقل الستوب للدخول.")
                    t['be_activated'] = True
                    t['current_sl'] = entry
                    
                # 4. التتبع الهيكلي (Trailing)
                if len(data_5m['highs']) >= 3 and data_5m['highs'][-2] > data_5m['highs'][-3] and data_5m['highs'][-2] > data_5m['highs'][-1]:
                    swing_high = data_5m['highs'][-2]
                    if l < data_5m['lows'][-2] and swing_high < t['current_sl'] and t['be_activated']:
                        t['current_sl'] = swing_high + (risk * 0.1)
                        print(f"🧠 [{now_ny}] {symbol}: تشكلت قمة هابطة! نقل الستوب لوس إلى {t['current_sl']:.4f}.")
            
            else: # LONG
                # 1. هل انضرب الستوب؟
                if l <= t['current_sl']:
                    if t['current_sl'] == t['sl']: print_banner(f"❌ {symbol}: ضرب الستوب لوس الأصلي!")
                    elif t['current_sl'] == entry: print_banner(f"🛡️ {symbol}: خروج على الدخول (Break-Even) بأمان.")
                    else: print_banner(f"🧠 {symbol}: ضرب الستوب المتتبع! خروج بأرباح ممتازة.")
                    del active_trades[symbol]
                    continue
                
                # 2. هل انضرب الهدف الجزئي؟
                if h >= t['tp1'] and not t['tp1_hit']:
                    print_banner(f"🎯 {symbol}: ضرب الهدف الأول! تم أخذ 80% من الأرباح. تأمين الصفقة.")
                    t['tp1_hit'] = True
                    t['be_activated'] = True
                    t['current_sl'] = entry
                    
                # 3. التأمين المبدئي 1.5R
                if h >= (entry + 1.5*risk) and not t['be_activated']:
                    print(f"🛡️ [{now_ny}] {symbol}: السعر تجاوز 1.5R. نقل الستوب للدخول.")
                    t['be_activated'] = True
                    t['current_sl'] = entry
                    
                # 4. التتبع الهيكلي (Trailing)
                if len(data_5m['lows']) >= 3 and data_5m['lows'][-2] < data_5m['lows'][-3] and data_5m['lows'][-2] < data_5m['lows'][-1]:
                    swing_low = data_5m['lows'][-2]
                    if h > data_5m['highs'][-2] and swing_low > t['current_sl'] and t['be_activated']:
                        t['current_sl'] = swing_low - (risk * 0.1)
                        print(f"🧠 [{now_ny}] {symbol}: تشكل قاع صاعد! نقل الستوب لوس إلى {t['current_sl']:.4f}.")

        except Exception as e:
            pass

print_banner("✅ تم تشغيل ICT Terminal Sniper بنجاح!")
print("جاري فحص الأسواق والبحث عن سيولة... (اضغط Ctrl+C للإيقاف)")

cycle = 0
while True:
    try:
        # فحص السوق كل 5 دورات (كل 5 دقائق تقريبا)
        if cycle % 5 == 0:
            scan_markets()
            
        # تحديث الصفقات المفتوحة (دقيقة بدقيقة)
        if active_trades:
            update_active_trades()
        else:
            if cycle % 5 == 0:
                print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] لا توجد صفقات مفعلة. أراقب الشارتات بصمت ⏳...")
        
        cycle += 1
        time.sleep(60) # تحديث كل 60 ثانية
        
    except KeyboardInterrupt:
        print("\nتم إيقاف البوت. وداعاً!")
        sys.exit(0)

