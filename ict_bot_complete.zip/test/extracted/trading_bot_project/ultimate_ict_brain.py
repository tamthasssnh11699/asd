import numpy as np
import datetime
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run, detect_order_blocks, detect_fair_value_gaps, find_structural_sl_anchors, find_tp_targets
from authenticity_engine import AuthenticityEngine

def _last_atr(data, period=14):
    h = np.asarray(data.get("highs", []), dtype=float)
    l = np.asarray(data.get("lows", []), dtype=float)
    c = np.asarray(data.get("closes", []), dtype=float)
    if len(c) < period + 1:
        return (h[-1] - l[-1]) if len(h) > 0 else 0.0
    tr = np.maximum(h[1:] - l[1:], np.abs(h[1:] - c[:-1]))
    tr = np.maximum(tr, np.abs(l[1:] - c[:-1]))
    return float(np.mean(tr[-period:]))

class UltimateICTBrain:
    def __init__(self, data_manager):
        self.dm = data_manager
        self.ae = AuthenticityEngine()

    def _get_htf_context(self, symbol, current_ts):
        data_1d = self.dm.fetch_ohlcv_up_to(symbol, "1d", current_ts, limit=150)
        data_4h = self.dm.fetch_ohlcv_up_to(symbol, "4h", current_ts, limit=150)
        
        bias_1d = compute_mechanical_bias_anchor(data_1d, lookback=100).get("anchor_direction", "CHOP") if data_1d and data_1d['closes'] else "CHOP"
        bias_4h = compute_mechanical_bias_anchor(data_4h, lookback=100).get("anchor_direction", "CHOP") if data_4h and data_4h['closes'] else "CHOP"
        
        if bias_1d == bias_4h and bias_1d in ["BULLISH", "BEARISH"]:
            return bias_1d, "STRONG"
        elif bias_1d in ["BULLISH", "BEARISH"]:
            return bias_1d, "MODERATE"
        elif bias_4h in ["BULLISH", "BEARISH"]:
            return bias_4h, "WEAK" 
        return "CHOP", "NONE"

    def _find_sweep_trigger(self, data_15m, bias):
        sig = self.ae.detect_significant_swings(data_15m, swing_window=2, lookback_candles=150)
        
        if bias == "BULLISH":
            levels = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
            for cand in levels:
                res = classify_sweep_or_run(data_15m, cand["price"], level_is_high=False, check_from_idx=len(data_15m['closes'])-1)
                if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -3:
                    return {"found": True, "level": cand["price"], "type": "SSL_SWEEP"}
        elif bias == "BEARISH":
            levels = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
            for cand in levels:
                res = classify_sweep_or_run(data_15m, cand["price"], level_is_high=True, check_from_idx=len(data_15m['closes'])-1)
                if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -3:
                    return {"found": True, "level": cand["price"], "type": "BSL_SWEEP"}
        return {"found": False}

    def _build_entry_plan(self, data_5m, bias, sweep_level):
        is_long = (bias == "BULLISH")
        closes = data_5m['closes']
        last_price = closes[-1]
        atr = _last_atr(data_5m)
        buffer_dist = max(atr * 0.3, last_price * 0.002)

        fvgs = detect_fair_value_gaps(data_5m, lookback=20, require_displacement=True)
        valid_fvgs = fvgs.get("bullish_fvgs", []) if is_long else fvgs.get("bearish_fvgs", [])
        
        if not valid_fvgs:
            return {"status": "PENDING_SETUP", "reason": "No FVG formed yet after the sweep."}
            
        fvg = valid_fvgs[-1]
        entry_price = fvg['ce']

        sl_price = sweep_level - buffer_dist if is_long else sweep_level + buffer_dist

        targets = find_tp_targets(data_5m, entry_price, sl_price, is_long=is_long, lookback=150)
        
        tp1_data = targets.get("tp1")
        if not tp1_data:
            return {"status": "NO_QUALIFIED_TARGETS", "reason": "Could not find internal liquidity providing at least 1.5R."}

        tp1_price = tp1_data["price"]
        tp2_price = targets.get("tp2", {}).get("price", "Open (Trail)")

        return {
            "status": "READY",
            "plan": {
                "direction": "BUY_LIMIT" if is_long else "SELL_LIMIT",
                "entry": round(entry_price, 4),
                "stop_loss": round(sl_price, 4),
                "tp1": round(tp1_price, 4),
                "tp2": tp2_price,
                "risk": abs(entry_price - sl_price),
                "rr_to_tp1": tp1_data.get("rr", 0)
            }
        }

    def analyze_market(self, symbol, current_ts=None):
        if not current_ts:
            current_ts = int(datetime.datetime.now(datetime.timezone.utc).timestamp() * 1000)
            
        bias, strength = self._get_htf_context(symbol, current_ts)
        if bias == "CHOP":
            return {"action": "HOLD", "reason": "Market is ranging on Higher Timeframes."}

        data_15m = self.dm.fetch_ohlcv_up_to(symbol, "15m", current_ts, limit=200)
        if not data_15m or not data_15m['closes']:
            return {"action": "ERROR", "reason": "No data"}
            
        sweep_info = self._find_sweep_trigger(data_15m, bias)
        if not sweep_info["found"]:
            return {"action": "HOLD", "reason": f"Waiting for a {bias} liquidity sweep."}

        data_5m = self.dm.fetch_ohlcv_up_to(symbol, "5m", current_ts, limit=150)
        setup = self._build_entry_plan(data_5m, bias, sweep_info["level"])
        
        if setup["status"] != "READY":
            return {"action": "PENDING", "reason": setup["reason"]}

        return {
            "action": "EXECUTE",
            "symbol": symbol,
            "bias": bias,
            "strength": strength,
            "sweep_level": sweep_info["level"],
            "plan": setup["plan"]
        }

if __name__ == "__main__":
    from data_manager import DataManager
    class MockBrain:
        def __init__(self):
            self.data_manager = DataManager()
    
    brain = MockBrain()
    ultimate = UltimateICTBrain(brain.data_manager)
    
    print("🧠 جاري تشغيل [العقل الشامل والمستقل - Ultimate ICT Brain] على الأسواق الحية...")
    for sym in ["BTC/USDT", "ETH/USDT", "SOL/USDT"]:
        res = ultimate.analyze_market(sym)
        if res["action"] == "EXECUTE":
            p = res['plan']
            print(f"🚨 فرصة ناضجة [{sym}]: {p['direction']} | دخول: {p['entry']} | ستوب: {p['stop_loss']} | هدف1: {p['tp1']} (R:R={p['rr_to_tp1']}) | هدف2: {p['tp2']}")
        else:
            print(f"⏳ {sym} -> {res['action']} ({res['reason']})")
