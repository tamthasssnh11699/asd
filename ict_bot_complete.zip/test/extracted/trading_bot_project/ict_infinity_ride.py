# -*- coding: utf-8 -*-
"""
ict_infinity_ride.py — محرك الركوب اللانهائي
═══════════════════════════════════════════════
لا سقف رقمي. لا خوف من الارتدادات.
3 مستشعرات ذكية تعمل بالتوازي:

1. Dynamic DOL Tracker: طالما HTF DOL ما اتلمس = ابقَ
2. Discount Cushion Filter: ارتداد للـDiscount + ارتد من PD Array = صحي
3. ITL Shield Jumping: SL يقفز فقط خلف ITL مؤكد مع displacement
"""
import numpy as np


class InfinityRideEngine:
    """
    يركب الموجة بلا حدود — يخرج فقط عندما القصة تتغير.
    
    المستشعرات الثلاثة:
    
    sensor_dol: هل وصلنا لهدف السيولة الكبير؟
      → لا = ابقَ. نعم = أغلق الكل.
    
    sensor_cushion: هل الارتداد صحي ولا انعكاسي؟
      → صحي (في Discount + ارتد من PD Array) = ابقَ
      → انعكاسي (أغلق تحت PD Array) = احذر
    
    sensor_itl: هل الحصن المؤسساتي صامد؟
      → ITL ما انكسر = structure سليم = ابقَ
      → ITL انكسر بإغلاق + displacement = اطلع
    """
    
    def __init__(self):
        self.candles_1h = []
        self.candles_4h = []
        self.itls = []      # Intermediate Term Lows
        self.iths = []      # Intermediate Term Highs
        self.fvgs = []      # Fair Value Gaps الحية
        self.obs = []       # Order Blocks الحية
        self.wave_high = 0  # أعلى نقطة بالموجة الحالية
        self.wave_low = float('inf')
    
    def feed_1h(self, c):
        """يغذي بيانات 1H — لكشف PD Arrays والـcushion."""
        self.candles_1h.append(c)
        n = len(self.candles_1h)
        if n < 3: return
        
        c1,c2,c3 = self.candles_1h[-3], self.candles_1h[-2], self.candles_1h[-1]
        
        # FVG
        if c3['l'] > c1['h']:
            self.fvgs.append({'t':'B','top':c3['l'],'bot':c1['h'],'live':True})
        if c3['h'] < c1['l']:
            self.fvgs.append({'t':'S','top':c1['l'],'bot':c3['h'],'live':True})
        
        # OB
        if n >= 2:
            p,cu = self.candles_1h[-2], self.candles_1h[-1]
            if p['c']<p['o'] and cu['c']>cu['o'] and cu['c']>p['h']:
                self.obs.append({'t':'B','top':p['h'],'bot':p['l'],'live':True})
            if p['c']>p['o'] and cu['c']<cu['o'] and cu['c']<p['l']:
                self.obs.append({'t':'S','top':p['h'],'bot':p['l'],'live':True})
        
        # Update FVG fills
        for f in self.fvgs:
            if f['live']:
                if f['t']=='B' and c3['c']<f['bot']: f['live']=False
                elif f['t']=='S' and c3['c']>f['top']: f['live']=False
        for o in self.obs:
            if o['live']:
                if o['t']=='B' and c3['c']<o['bot']: o['live']=False
                elif o['t']=='S' and c3['c']>o['top']: o['live']=False
    
    def feed_4h(self, c):
        """يغذي 4H — لكشف ITL/ITH الحقيقية."""
        self.candles_4h.append(c)
        n = len(self.candles_4h)
        if n < 5: return
        
        mid = n - 3
        cs = self.candles_4h
        
        # ITL: قاع أدنى من 4 جيران (شمعتين كل جهة على 4H = structure ثقيل)
        if (cs[mid]['l'] < cs[mid-1]['l'] and cs[mid]['l'] < cs[mid-2]['l'] and
            cs[mid]['l'] < cs[mid+1]['l'] and cs[mid]['l'] < cs[mid+2]['l']):
            
            # هل بعده displacement؟
            has_disp = False
            for k in range(mid+1, min(mid+3, n)):
                body = abs(cs[k]['c']-cs[k]['o'])
                rng = cs[k]['h']-cs[k]['l']
                if rng > 0 and body/rng > 0.5:
                    prev_b = [abs(cs[j]['c']-cs[j]['o']) for j in range(max(0,k-2),k)]
                    if prev_b and body > np.mean(prev_b)*1.5:
                        has_disp = True; break
            
            self.itls.append({
                'price': cs[mid]['l'], 'index': mid,
                'has_displacement': has_disp, 'broken': False
            })
        
        # ITH
        if (cs[mid]['h'] > cs[mid-1]['h'] and cs[mid]['h'] > cs[mid-2]['h'] and
            cs[mid]['h'] > cs[mid+1]['h'] and cs[mid]['h'] > cs[mid+2]['h']):
            
            has_disp = False
            for k in range(mid+1, min(mid+3, n)):
                body = abs(cs[k]['c']-cs[k]['o'])
                rng = cs[k]['h']-cs[k]['l']
                if rng > 0 and body/rng > 0.5:
                    prev_b = [abs(cs[j]['c']-cs[j]['o']) for j in range(max(0,k-2),k)]
                    if prev_b and body > np.mean(prev_b)*1.5:
                        has_disp = True; break
            
            self.iths.append({
                'price': cs[mid]['h'], 'index': mid,
                'has_displacement': has_disp, 'broken': False
            })
    
    # ═══════════════════════════════════════
    # SENSOR 1: Dynamic DOL Tracker
    # ═══════════════════════════════════════
    def sensor_dol_reached(self, is_long, current_price, dol_price):
        """هل وصلنا لهدف السيولة الكبير؟"""
        if dol_price is None:
            return False
        if is_long:
            return current_price >= dol_price
        else:
            return current_price <= dol_price
    
    # ═══════════════════════════════════════
    # SENSOR 2: Discount Cushion Filter
    # ═══════════════════════════════════════
    def sensor_discount_cushion(self, is_long, current_high, current_low, current_close, entry):
        """
        هل الارتداد صحي؟
        
        صحي = السعر بالـDiscount + ارتد من PD Array (FVG/OB)
        يعني: "صناع السوق يشترون المزيد"
        
        خطير = السعر أغلق تحت/فوق آخر PD Array حية
        يعني: "الهيكل بدأ ينكسر"
        """
        # حساب Premium/Discount للموجة الحالية
        if is_long:
            if current_high > self.wave_high: self.wave_high = current_high
            wave = self.wave_high - entry
            if wave > 0:
                retrace = (self.wave_high - current_close) / wave
                in_discount = retrace > 0.5
            else:
                in_discount = False; retrace = 0
            
            # هل ارتد من PD Array حية؟
            bounced_from_pd = False
            for f in reversed(self.fvgs[-5:]):
                if f['t']=='B' and f['live']:
                    if current_low <= f['top'] and current_close > f['bot']:
                        bounced_from_pd = True; break
            for o in reversed(self.obs[-5:]):
                if o['t']=='B' and o['live']:
                    if current_low <= o['top'] and current_close > o['bot']:
                        bounced_from_pd = True; break
            
            return {
                'in_discount': in_discount,
                'bounced_from_pd': bounced_from_pd,
                'retrace_pct': round(retrace * 100, 1) if wave > 0 else 0,
                'healthy': in_discount and bounced_from_pd,
                'verdict': 'HEALTHY_RETRACE' if (in_discount and bounced_from_pd) else 
                          ('DISCOUNT_NO_BOUNCE' if in_discount else 'NOT_IN_DISCOUNT')
            }
        else:
            if current_low < self.wave_low: self.wave_low = current_low
            wave = entry - self.wave_low
            if wave > 0:
                retrace = (current_close - self.wave_low) / wave
                in_discount = retrace > 0.5
            else:
                in_discount = False; retrace = 0
            
            bounced_from_pd = False
            for f in reversed(self.fvgs[-5:]):
                if f['t']=='S' and f['live']:
                    if current_high >= f['bot'] and current_close < f['top']:
                        bounced_from_pd = True; break
            for o in reversed(self.obs[-5:]):
                if o['t']=='S' and o['live']:
                    if current_high >= o['bot'] and current_close < o['top']:
                        bounced_from_pd = True; break
            
            return {
                'in_discount': in_discount, 'bounced_from_pd': bounced_from_pd,
                'retrace_pct': round(retrace * 100, 1) if wave > 0 else 0,
                'healthy': in_discount and bounced_from_pd,
                'verdict': 'HEALTHY_RETRACE' if (in_discount and bounced_from_pd) else
                          ('DISCOUNT_NO_BOUNCE' if in_discount else 'NOT_IN_DISCOUNT')
            }
    
    # ═══════════════════════════════════════
    # SENSOR 3: ITL Shield Jumping
    # ═══════════════════════════════════════
    def sensor_itl_shield(self, is_long, current_close, buffer=0):
        """
        هل الحصن المؤسساتي (ITL/ITH) صامد؟
        
        Returns: (intact, trail_level, reason)
        """
        if is_long:
            # Check if any ITL is broken
            for itl in reversed(self.itls[-5:]):
                if not itl['broken'] and current_close < itl['price']:
                    itl['broken'] = True
                    return False, None, f"ITL BROKEN at {itl['price']:.0f}"
            
            # Get trail level = behind last unbroken ITL
            valid_itls = [i for i in self.itls if not i['broken'] and i['has_displacement']]
            if valid_itls:
                trail = valid_itls[-1]['price'] - buffer
                return True, trail, "ITL holding"
            
            return True, None, "No confirmed ITL yet"
        else:
            for ith in reversed(self.iths[-5:]):
                if not ith['broken'] and current_close > ith['price']:
                    ith['broken'] = True
                    return False, None, f"ITH BROKEN at {ith['price']:.0f}"
            
            valid_iths = [i for i in self.iths if not i['broken'] and i['has_displacement']]
            if valid_iths:
                trail = valid_iths[-1]['price'] + buffer
                return True, trail, "ITH holding"
            
            return True, None, "No confirmed ITH yet"


def manage_infinity(c5, c1h, c4h, state):
    """
    المحرك اللانهائي — يركب الموجة حتى تنتهي القصة.
    
    A (60%): Scalp → TP1 → quick trail
    B (30%): Runner → 3 sensors تحكمه:
      - DOL reached? → close
      - Healthy retrace? → hold
      - ITL broken? → close
    C (10%): Swing → 4H ITL → 5 days max
    """
    h,l,c,o = c5['h'],c5['l'],c5['c'],c5.get('o',c5['c'])
    is_short=state['is_short']; is_long=not is_short
    events=[]; risk=state['risk']; atr=state.get('atr',1)
    
    if 'engine' not in state:
        state['engine'] = InfinityRideEngine()
        state['engine'].wave_high = state.get('pos_a',{}).get('entry',c)
        state['engine'].wave_low = state.get('pos_a',{}).get('entry',c)
    
    eng = state['engine']
    if c1h: eng.feed_1h(c1h)
    if c4h: eng.feed_4h(c4h)
    
    state['candle_count']=state.get('candle_count',0)+1
    days=state['candle_count']/288
    entry = state.get('pos_a',{}).get('entry',c)
    
    # ═══ A: Scalp ═══
    pa=state.get('pos_a',{})
    if pa.get('active'):
        if not pa.get('tp1_hit'):
            if (is_short and h>=pa['sl']) or (is_long and l<=pa['sl']):
                pa['active']=False;pa['pnl']=-state['risk_pct_a'];pa['exit_reason']='SL';events.append('❌ A:SL')
            elif pa.get('tp1'):
                if (is_short and l<=pa['tp1']) or (is_long and h>=pa['tp1']):
                    pa['tp1_hit']=True;rr=abs(pa['tp1']-pa['entry'])/risk if risk>0 else 0
                    pa['pnl']=rr*state['risk_pct_a'];pa['sl']=pa['entry'];events.append('🎯 A:TP1')
        elif pa.get('tp1_hit'):
            if (is_short and h>=pa['sl']) or (is_long and l<=pa['sl']):
                pa['active']=False;pa['exit_reason']='A_TR';events.append('🧠 A')
            else:
                body=abs(c-o);rng=h-l
                if rng>0 and body/rng>0.5:
                    if is_long and c>o:
                        ns=l-atr*0.1
                        if ns>pa['sl']:pa['sl']=ns
                    elif is_short and c<o:
                        ns=h+atr*0.1
                        if ns<pa['sl']:pa['sl']=ns
    
    # ═══ B: Infinity Runner (3 sensors) ═══
    pb=state.get('pos_b',{})
    if pb.get('active'):
        # DOL check
        dol = pb.get('tp2_price')
        if dol and eng.sensor_dol_reached(is_long, h if is_long else l, dol):
            pb['active']=False;rr=abs(dol-pb['entry'])/risk if risk>0 else 0
            pb['pnl']=rr*state['risk_pct_b'];pb['exit_reason']='DOL';events.append('🏆 B:DOL!')
            if pa.get('active'):
                pa['active']=False;rr_a=abs(dol-pa.get('entry',c))/risk if risk>0 else 0
                pa['pnl']=rr_a*state['risk_pct_a'];pa['exit_reason']='W_B'
        
        if pb.get('active') and not pb.get('be_set'):
            if (is_short and h>=pb['sl']) or (is_long and l<=pb['sl']):
                pb['active']=False;pb['pnl']=-state['risk_pct_b'];pb['exit_reason']='SL';events.append('❌ B:SL')
        
        if pb.get('active') and pb.get('be_set'):
            # SL check
            if (is_short and h>=pb['sl']) or (is_long and l<=pb['sl']):
                pb['active']=False
                rr=abs(pb['sl']-pb['entry'])/risk if risk>0 else 0
                ok=(is_long and pb['sl']>pb['entry']) or (is_short and pb['sl']<pb['entry'])
                pb['pnl']=rr*state['risk_pct_b'] if ok else 0
                pb['exit_reason']='B_TR';events.append('🧠 B')
            else:
                # ═══ 3 SENSORS ═══
                
                # Sensor 2: Discount Cushion
                cushion = eng.sensor_discount_cushion(is_long, h, l, c, entry)
                
                # Sensor 3: ITL Shield
                intact, trail_level, itl_reason = eng.sensor_itl_shield(is_long, c, buffer=atr*0.3)
                
                if not intact:
                    # ITL broken = القصة انتهت
                    # لكن: هل الارتداد صحي؟ إذا bounce من PD Array = ممكن STL sweep
                    if cushion['healthy']:
                        # Healthy retrace + ITL break = ننتظر شمعة تأكيد
                        pass  # لا نخرج فوراً — ننتظر
                    else:
                        # ITL broken بدون bounce = خروج حقيقي
                        pb['active']=False
                        rr=abs(c-pb['entry'])/risk if risk>0 else 0
                        ok=(is_long and c>pb['entry']) or (is_short and c<pb['entry'])
                        pb['pnl']=rr*state['risk_pct_b'] if ok else 0
                        pb['exit_reason']='ITL_BRK';events.append(f'🧱 B:{itl_reason[:20]}')
                
                # Trail behind ITL (فقط إذا مش بالـDiscount)
                if pb.get('active') and trail_level is not None and not cushion['in_discount']:
                    if is_long and trail_level > pb['sl']:
                        pb['sl'] = trail_level; events.append(f'📈 B:ITL→{trail_level:.0f}')
                    elif is_short and trail_level < pb['sl']:
                        pb['sl'] = trail_level; events.append(f'📉 B:ITL→{trail_level:.0f}')
        
        if pa.get('tp1_hit') and not pb.get('be_set') and pb.get('active'):
            pb['sl']=pb['entry'];pb['be_set']=True;events.append('🛡️ B:BE')
    
    # ═══ C: Swing (4H ITL — يبقى أيام) ═══
    pc=state.get('pos_c',{})
    if pc.get('active'):
        if pc.get('tp3_price'):
            if (is_short and l<=pc['tp3_price']) or (is_long and h>=pc['tp3_price']):
                pc['active']=False;rr=abs(pc['tp3_price']-pc['entry'])/risk if risk>0 else 0
                pc['pnl']=rr*state['risk_pct_c'];pc['exit_reason']='TP3';events.append('💎 C:TP3!')
                for px in [pa,pb]:
                    if px.get('active'):
                        px['active']=False;rr_x=abs(pc['tp3_price']-px.get('entry',c))/risk if risk>0 else 0
                        px['pnl']=rr_x*state.get('risk_pct_a' if px is pa else 'risk_pct_b',0);px['exit_reason']='W_C'
        
        if pc.get('active') and not pc.get('be_set'):
            if (is_short and h>=pc['sl']) or (is_long and l<=pc['sl']):
                pc['active']=False;pc['pnl']=-state['risk_pct_c'];pc['exit_reason']='SL';events.append('❌ C:SL')
        
        if pc.get('active') and pc.get('be_set'):
            if (is_short and h>=pc['sl']) or (is_long and l<=pc['sl']):
                pc['active']=False
                rr=abs(pc['sl']-pc['entry'])/risk if risk>0 else 0
                ok=(is_long and pc['sl']>pc['entry']) or (is_short and pc['sl']<pc['entry'])
                pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                pc['exit_reason']='C_TR';events.append('🧠 C')
            elif days>=5:
                pc['active']=False;ok=(is_long and c>pc['entry']) or (is_short and c<pc['entry'])
                rr=abs(c-pc['entry'])/risk if risk>0 else 0
                pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                pc['exit_reason']='5D';events.append('📅 C')
            else:
                intact4,trail4,r4=eng.sensor_itl_shield(is_long,c,buffer=atr*0.5)
                if not intact4:
                    cushion4=eng.sensor_discount_cushion(is_long,h,l,c,entry)
                    if not cushion4['healthy']:
                        pc['active']=False
                        rr=abs(c-pc['entry'])/risk if risk>0 else 0
                        ok=(is_long and c>pc['entry']) or (is_short and c<pc['entry'])
                        pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                        pc['exit_reason']='C_ITL';events.append(f'🧱 C:{r4[:15]}')
                if pc.get('active') and trail4 is not None:
                    cushion4=eng.sensor_discount_cushion(is_long,h,l,c,entry)
                    if not cushion4['in_discount']:
                        if is_long and trail4>pc['sl']:pc['sl']=trail4
                        elif is_short and trail4<pc['sl']:pc['sl']=trail4
        
        if pa.get('tp1_hit') and not pc.get('be_set') and pc.get('active'):
            pc['sl']=pc['entry'];pc['be_set']=True;events.append('🛡️ C:BE')
    
    done=(not pa.get('active',False)) and (not pb.get('active',False)) and (not pc.get('active',False))
    if done:
        state['pnl_pct']=(pa.get('pnl',0) or 0)+(pb.get('pnl',0) or 0)+(pc.get('pnl',0) or 0)
        state['exit_reason_a']=pa.get('exit_reason','?')
        state['exit_reason_b']=pb.get('exit_reason','?')
        state['exit_reason_c']=pc.get('exit_reason','?')
    return events,done
