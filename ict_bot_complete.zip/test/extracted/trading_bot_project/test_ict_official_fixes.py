# -*- coding: utf-8 -*-
"""
Adversarial tests for ICT official fixes.
Based on Michael Huddleston's official definitions from:
- 2022 Mentorship Ep5 (14:29): Swing = 3 candle pattern
- 2022 Mentorship Ep2/Ep6: FVG lifecycle, displacement
- innercircletrader.net: OB 4 conditions, MSS requires prior sweep
- backtrex.com: MSS vs BOS distinction

Test protocol:
1. Minimum positive: simplest case that must pass
2. Near miss: similar shape but missing a key condition → must reject
3. Invalidation: valid event later destroyed → must update
4. Temporal mutation: adding candles must not corrupt past judgments
5. Context collision: multiple events → must link correct ones
6. Long/Short symmetry
7. Boundary/equality edge cases
8. Determinism: same data twice = same result
"""
import unittest
import numpy as np

# We'll import from the modified ict_math_engine after fixes
# For now these are the EXPECTED behaviors that the fixes must satisfy


class TestICTThreeCandleSwing(unittest.TestCase):
    """
    Source: ICT Mentorship Month 1 Notes + 2022 Ep5 (14:29-15:03)
    "Swing High – Three candle pattern. The up candle."
    "Swing Low – Three candle pattern. The down candle."
    Middle candle high > left AND right candle highs = swing high
    Middle candle low < left AND right candle lows = swing low
    STRICT: equal neighbor is NOT a valid swing (no >=, must be >)
    """
    
    def _swings(self, highs, lows):
        from ict_math_engine import detect_ict_three_candle_swings
        return detect_ict_three_candle_swings({
            'highs': highs, 'lows': lows,
            'timestamps': list(range(len(highs)))
        })
    
    # --- Minimum Positive ---
    def test_basic_swing_high(self):
        r = self._swings([1, 3, 2], [0, 1, 0])
        self.assertEqual(len(r['swing_highs']), 1)
        self.assertEqual(r['swing_highs'][0]['index'], 1)
        self.assertEqual(r['swing_highs'][0]['price'], 3)
    
    def test_basic_swing_low(self):
        r = self._swings([3, 2, 3], [2, 0, 1])
        self.assertEqual(len(r['swing_lows']), 1)
        self.assertEqual(r['swing_lows'][0]['index'], 1)
        self.assertEqual(r['swing_lows'][0]['price'], 0)
    
    # --- Near Miss: equal neighbor → NOT a swing ---
    def test_equal_high_neighbor_rejected(self):
        """If right candle high equals middle, NOT a strict swing high"""
        r = self._swings([1, 3, 3], [0, 1, 0])
        self.assertEqual(len(r['swing_highs']), 0)
    
    def test_equal_low_neighbor_rejected(self):
        """If right candle low equals middle, NOT a strict swing low"""
        r = self._swings([3, 2, 3], [2, 0, 0])
        self.assertEqual(len(r['swing_lows']), 0)
    
    # --- Last candle cannot be confirmed ---
    def test_last_candle_cannot_be_swing(self):
        """Need right-side confirmation"""
        r = self._swings([1, 2, 4], [2, 1, 0])
        sh = [s for s in r['swing_highs'] if s['index'] == 2]
        sl = [s for s in r['swing_lows'] if s['index'] == 2]
        self.assertEqual(len(sh), 0)
        self.assertEqual(len(sl), 0)
    
    # --- First candle cannot be confirmed ---
    def test_first_candle_cannot_be_swing(self):
        """Need left-side confirmation"""
        r = self._swings([4, 2, 1], [0, 1, 2])
        sh = [s for s in r['swing_highs'] if s['index'] == 0]
        self.assertEqual(len(sh), 0)
    
    # --- Multiple swings ---
    def test_multiple_swings(self):
        r = self._swings([1,5,2,6,3], [0,1,0,1,0])
        highs = [s['index'] for s in r['swing_highs']]
        self.assertIn(1, highs)
        self.assertIn(3, highs)
    
    # --- Symmetry Long/Short ---
    def test_symmetry(self):
        """Bullish and bearish should be symmetric"""
        h = [100,105,102,98,95,99]
        l = [98,103,100,96,93,97]
        r = self._swings(h, l)
        self.assertTrue(len(r['swing_highs']) >= 1)
        self.assertTrue(len(r['swing_lows']) >= 1)
    
    # --- Determinism ---
    def test_determinism(self):
        h = [1,5,2,8,3,7,4]
        l = [0,2,1,3,2,4,3]
        r1 = self._swings(h, l)
        r2 = self._swings(h, l)
        self.assertEqual(r1, r2)


class TestFVGLifecycle(unittest.TestCase):
    """
    Source: innercircletrader.net FVG guide
    "Not every FVG is tradeable"
    A fully filled FVG must be marked inactive.
    """
    
    def _make_data(self, n=15):
        return {
            'opens': [100.0]*n, 'highs': [102.0]*n, 'lows': [98.0]*n,
            'closes': [100.0]*n, 'volumes': [100]*n,
            'timestamps': list(range(n))
        }
    
    def test_fully_filled_fvg_has_is_active_false(self):
        """FVG filled 100% must have is_active=False"""
        from ict_math_engine import detect_fair_value_gaps
        d = self._make_data(15)
        # Create bullish FVG at candles 5,6,7
        d['opens'][6] = 100; d['closes'][6] = 106
        d['highs'][6] = 107; d['lows'][6] = 100
        d['highs'][5] = 101; d['lows'][5] = 99
        d['highs'][7] = 108; d['lows'][7] = 103
        # Later candle fills it completely
        d['lows'][9] = 99; d['highs'][9] = 104
        
        out = detect_fair_value_gaps(d, lookback=15, require_displacement=False)
        fvgs = [f for f in out['bullish_fvgs'] if f['filled_pct'] >= 99]
        if fvgs:
            self.assertIn('is_active', fvgs[0])
            self.assertFalse(fvgs[0]['is_active'])


class TestClassifySweepLatest(unittest.TestCase):
    """
    Source: ICT methodology - sweep is the LATEST event, not the first.
    If Run happens first then Sweep later, must return Sweep.
    """
    
    def test_returns_latest_not_first(self):
        from ict_math_engine import classify_sweep_or_run
        data = {
            'timestamps': [1, 2],
            'opens': [99, 101], 'highs': [102, 103],
            'lows': [98, 99], 'closes': [101, 99],
            'volumes': [100, 100]
        }
        # Candle 0: close=101 > 100 → Run
        # Candle 1: high=103 > 100 but close=99 < 100 → Sweep
        r = classify_sweep_or_run(data, 100.0, True, 0)
        # Should return the Sweep (candle 1), not the Run (candle 0)
        self.assertEqual(r['classification'], 'GENUINE_REVERSAL_SWEEP')

    def test_boundary_close_not_genuine(self):
        """Close exactly at level = ambiguous, not genuine sweep"""
        from ict_math_engine import classify_sweep_or_run
        data = {
            'timestamps': [1], 'opens': [99],
            'highs': [102], 'lows': [98], 'closes': [100],
            'volumes': [100]
        }
        r = classify_sweep_or_run(data, 100.0, True, 0)
        # Close exactly at level should NOT be called genuine
        self.assertNotEqual(r.get('classification'), 'GENUINE_REVERSAL_SWEEP')


class TestOBInvalidation(unittest.TestCase):
    """
    Source: innercircletrader.net OB guide
    "Stop loss too tight on the OB extreme"
    An OB with price closing decisively past it = invalidated
    """
    
    def test_invalidated_ob_not_active(self):
        from ict_math_engine import detect_order_blocks
        d = {
            'opens': [100]*18, 'highs': [104]*18, 'lows': [96]*18,
            'closes': [100]*18, 'volumes': [100]*18, 'timestamps': list(range(18))
        }
        # Create bullish OB candidate at candle 8-9
        d['opens'][8] = 101; d['closes'][8] = 99
        d['highs'][8] = 102; d['lows'][8] = 98
        d['opens'][9] = 99; d['closes'][9] = 103
        d['highs'][9] = 104; d['lows'][9] = 97
        # Later: decisive close below OB bottom
        d['opens'][14] = 99; d['closes'][14] = 95
        d['highs'][14] = 100; d['lows'][14] = 94
        
        out = detect_order_blocks(d, lookback=18)
        for ob in out['bullish_obs']:
            if ob.get('invalidated'):
                self.assertFalse(ob.get('is_active', True))


class TestBearishOTEPct(unittest.TestCase):
    """
    Source: innercircletrader.net Fibonacci Settings
    "In a bearish trend the ideal fibonacci entry levels sit ABOVE 50%"
    Bearish retracement measured from LOW upward.
    """
    
    def test_bearish_retracement_from_low(self):
        from ict_math_engine import compute_premium_discount
        r = compute_premium_discount(0, 100, 78.6, is_bullish_setup=False)
        self.assertTrue(r['in_ote_zone'])
        # Bearish: retracement measured from low upward = 78.6%
        self.assertAlmostEqual(r['retracement_pct'], 78.6, delta=1.0)


if __name__ == '__main__':
    unittest.main(verbosity=2)


class TestGenericFallbackDisabled(unittest.TestCase):
    """GENERIC_STRUCTURAL_FALLBACK must NOT return READY."""
    
    def test_fallback_not_ready(self):
        from ict_entry_checklist_engine import evaluate_generic_structural_fallback
        d = {
            'opens': [100]*30, 'highs': [104]*30, 'lows': [96]*30,
            'closes': [101]*30, 'volumes': [100]*30, 'timestamps': list(range(30))
        }
        # Create OB-like pattern
        d['opens'][10]=101; d['closes'][10]=99; d['highs'][10]=102; d['lows'][10]=98
        d['opens'][11]=99; d['closes'][11]=103; d['highs'][11]=104; d['lows'][11]=97
        r = evaluate_generic_structural_fallback(d, "BULLISH", lookback=30)
        self.assertNotEqual(r['status'], 'READY',
            "GENERIC_STRUCTURAL_FALLBACK must not return READY — it's not an ICT model")


class TestModelBIdxFix(unittest.TestCase):
    """Model B must correctly resolve negative idx from find_recent_sweep."""
    
    def test_negative_idx_resolves_timestamp(self):
        """After fix, negative idx should still find correct timestamp."""
        ts = [1000, 2000, 3000, 4000, 5000]
        data = {'timestamps': ts, 'highs': [102]*5, 'lows': [98]*5,
                'closes': [101]*5, 'opens': [100]*5, 'volumes': [100]*5}
        
        # Simulate what _scan_sweep does: find_recent_sweep returns idx=-2
        from ict_math_engine import find_recent_sweep
        # We can't easily trigger a sweep on flat data, so test the fix logic directly
        idx = -2
        if -len(ts) <= idx < len(ts):
            resolved = ts[idx]
        else:
            resolved = None
        self.assertEqual(resolved, 4000)  # ts[-2] = 4000


class TestValidateOHLCV(unittest.TestCase):
    """_validate_ohlcv must catch bad data."""
    
    def test_good_data_passes(self):
        from algo_master import _validate_ohlcv
        d = {'timestamps': [1,2], 'opens': [10,11], 'highs': [12,13],
             'lows': [9,10], 'closes': [11,12]}
        ok, _ = _validate_ohlcv(d)
        self.assertTrue(ok)
    
    def test_nan_rejected(self):
        from algo_master import _validate_ohlcv
        d = {'timestamps': [1,2], 'opens': [float('nan'),11], 'highs': [12,13],
             'lows': [9,10], 'closes': [11,12]}
        ok, reason = _validate_ohlcv(d)
        self.assertFalse(ok)
        self.assertIn('NON_FINITE', reason)
    
    def test_high_below_low_rejected(self):
        from algo_master import _validate_ohlcv
        d = {'timestamps': [1,2], 'opens': [10,11], 'highs': [8,13],
             'lows': [9,10], 'closes': [10,12]}
        ok, reason = _validate_ohlcv(d)
        self.assertFalse(ok)
    
    def test_duplicate_timestamps_rejected(self):
        from algo_master import _validate_ohlcv
        d = {'timestamps': [1,1], 'opens': [10,11], 'highs': [12,13],
             'lows': [9,10], 'closes': [11,12]}
        ok, reason = _validate_ohlcv(d)
        self.assertFalse(ok)
        self.assertIn('NOT_SORTED', reason)


class TestWeeklyBiasIntegration(unittest.TestCase):
    """analyze_bias must now include Weekly context."""
    
    def test_weekly_conflict_warning(self):
        from unittest.mock import patch
        import algo_master as a
        
        def anchor(direction):
            return {'anchor_direction': direction, 'strength': 'STRONG',
                    'sequence_direction': direction,
                    'last_confirmed_break_direction': direction}
        
        D = {'closes': [1]}
        with patch.object(a, 'compute_mechanical_bias_anchor',
                         side_effect=[anchor('BULLISH'), anchor('BEARISH'), anchor('BULLISH')]):
            with patch.object(a, 'classify_htf_structural_challenge',
                            return_value={'classification': 'NO_CHALLENGE'}):
                r = a.analyze_bias(D, D, D)
        
        self.assertEqual(r['dir_1w'], 'BULLISH')
        self.assertEqual(r['dir_1d'], 'BEARISH')  # 2nd call
        self.assertIn('WEEKLY_DAILY_CONFLICT', r['context_warnings'])


class TestSMCFVGValidation(unittest.TestCase):
    """Cross-validate our FVG detection against smartmoneyconcepts library."""
    
    def test_fvg_matches_smc_on_injected_data(self):
        """Our FVG detection (adjusted for index convention) should match SMC."""
        import numpy as np
        np.random.seed(123)
        n = 30
        opens = [100.0]; highs = [101.0]; lows = [99.0]; closes = [100.5]
        for i in range(1, n):
            o = closes[-1]; c = o + np.random.randn()*1.5
            h = max(o,c)+0.5; l = min(o,c)-0.5
            opens.append(o); highs.append(h); lows.append(l); closes.append(c)
        
        # Inject clear bullish FVG
        opens[15]=closes[14]; closes[15]=opens[15]+6
        highs[15]=closes[15]+0.3; lows[15]=opens[15]-0.1
        lows[16]=closes[15]+0.5; highs[16]=lows[16]+2
        opens[16]=lows[16]+0.5; closes[16]=lows[16]+1
        
        data = {'opens':opens,'highs':highs,'lows':lows,'closes':closes,
                'volumes':[100]*n,'timestamps':list(range(n))}
        
        from smc_validation_helper import validate_fvg_against_smc
        r = validate_fvg_against_smc(data)
        
        # Our indices are C3 (third candle), SMC uses C2 (middle candle) → shift by 1
        our_shifted = {x-1 for x in r['our_bullish']}
        # The injected FVG (index 16 in our convention = 15 in SMC) should appear in both
        self.assertIn(15, our_shifted, "Injected bullish FVG not found by our detector")
        self.assertIn(15, r['smc_bullish'], "Injected bullish FVG not found by SMC")


if __name__ == '__main__':
    unittest.main(verbosity=2)


class TestTPGeometryCheck(unittest.TestCase):
    """find_tp_targets must reject invalid geometry."""
    
    def test_long_sl_above_entry_rejected(self):
        from ict_math_engine import find_tp_targets
        d = {'opens':[100]*20,'highs':[110]*20,'lows':[90]*20,
             'closes':[105]*20,'volumes':[100]*20,'timestamps':list(range(20))}
        r = find_tp_targets(d, 100, 105, True)  # Long but SL=105 > entry=100
        self.assertEqual(r.get('error'), 'INVALID_TRADE_GEOMETRY')
        self.assertIsNone(r['tp1'])
    
    def test_short_sl_below_entry_rejected(self):
        from ict_math_engine import find_tp_targets
        d = {'opens':[100]*20,'highs':[110]*20,'lows':[90]*20,
             'closes':[105]*20,'volumes':[100]*20,'timestamps':list(range(20))}
        r = find_tp_targets(d, 100, 95, False)  # Short but SL=95 < entry=100
        self.assertEqual(r.get('error'), 'INVALID_TRADE_GEOMETRY')
        self.assertIsNone(r['tp1'])


class TestUnifiedSweep(unittest.TestCase):
    """algo_master.detect_recent_sweep must delegate to find_recent_sweep."""
    
    def test_sweep_uses_unified_function(self):
        """After fix, algo_master.detect_recent_sweep should be a wrapper."""
        import algo_master
        import inspect
        src = inspect.getsource(algo_master.detect_recent_sweep)
        # Should contain find_recent_sweep call (unified)
        self.assertIn('find_recent_sweep', src,
            "algo_master.detect_recent_sweep should delegate to find_recent_sweep")
        # Should NOT contain the old duplicate logic
        self.assertNotIn('detect_significant_swings', src,
            "algo_master.detect_recent_sweep should not duplicate swing detection")


class TestIsExecutableModel(unittest.TestCase):
    """is_executable_model should not bypass real structural conditions."""
    
    def test_observation_only_not_executable(self):
        from algo_master import is_executable_model
        chosen = {
            "model": "GENERIC_STRUCTURAL_FALLBACK",
            "status": "OBSERVATION_ONLY",
            "plan": {"entry": 100, "stop_loss": 95, "tp": 110},
            "conditions": [{"name": "X", "status": True}]
        }
        # OBSERVATION_ONLY should not be executable
        self.assertFalse(is_executable_model(chosen))
    
    def test_ready_with_plan_is_executable(self):
        from algo_master import is_executable_model
        chosen = {
            "model": "MODEL_B",
            "status": "READY",
            "plan": {"entry": 100, "stop_loss": 95, "tp": 110},
            "conditions": [{"name": "X", "status": True}]
        }
        self.assertTrue(is_executable_model(chosen))


if __name__ == '__main__':
    unittest.main(verbosity=2)
