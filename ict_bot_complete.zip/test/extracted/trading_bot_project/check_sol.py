import ccxt
import pandas as pd
from datetime import datetime, timezone

exchange = ccxt.okx()
ohlcv = exchange.fetch_ohlcv('SOL/USDT', '15m', limit=20)
df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')

print("Recent 15m candles for SOLUSDT from OKX:")
print(df.tail(10))
