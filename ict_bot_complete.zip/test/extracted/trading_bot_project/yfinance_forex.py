import yfinance as yf
import datetime, json, sys
sys.path.insert(0, ".")
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from ict_entry_checklist_engine import evaluate_all_entry_models

print("جاري جلب بيانات الفوركس/الذهب من YFinance لاختبار الصفقات الثلاث...")

trades = [
    {"id": "T1", "sym": "EURUSD=X", "name": "EUR/USD", "ts": "2025-01-14", "bias": "BEARISH"}, # User said entry 1.0845, sl 1.0862, tp 1.0780 -> This is SHORT (Bearish)
    {"id": "T2", "sym": "GBPJPY=X", "name": "GBP/JPY", "ts": "2025-01-16", "bias": "LONG"},   # User entry 195.45, sl 195.90, tp 198.80 -> Error in user SL, but let's see what bot says for LONG
    {"id": "T3", "sym": "GC=F", "name": "XAU/USD", "ts": "2025-01-20", "bias": "LONG"}        # User entry 2345, sl 2338, tp 2362
]

for t in trades:
    print(f"\n{'='*60}")
    print(f"فحص صفقة المتداول البشري {t['id']} ({t['name']}) بتاريخ {t['ts']}")
    
    # 1. جلب البيانات اليومية لتحديد الاتجاه (Daily Bias) كما يفعل البوت
    try:
        # Get daily data leading up to the trade date
        end_date = datetime.datetime.strptime(t['ts'], "%Y-%m-%d") + datetime.timedelta(days=1)
        start_date = end_date - datetime.timedelta(days=100)
        
        df_daily = yf.download(t['sym'], start=start_date.strftime("%Y-%m-%d"), end=end_date.strftime("%Y-%m-%d"), interval="1d", progress=False)
        
        if df_daily.empty:
            print("لم يتم العثور على بيانات لهذه العملة في YFinance.")
            continue
            
        data_1d = {
            "closes": df_daily['Close'].values.tolist(),
            "highs": df_daily['High'].values.tolist(),
            "lows": df_daily['Low'].values.tolist(),
            "timestamps": [int(x.timestamp()*1000) for x in df_daily.index]
        }
        
        # 2. تشغيل المحرك الميكانيكي (ICT Math Engine) ليرى الاتجاه العام الحقيقي
        anchor = compute_mechanical_bias_anchor(data_1d, lookback=60)
        bot_bias = anchor.get("anchor_direction", "CHOP")
        
        print(f"🧠 رأي المتداول البشري: كان يبحث عن صفقات {t['bias']}")
        print(f"🤖 رأي البوت המيكانيكي (Daily Bias): {bot_bias}")
        
        if t['bias'] == "LONG" and bot_bias == "BEARISH":
            print("❌ قرار البوت: [HOLD] - المتداول البشري يحاول الشراء في ترند هابط. البوت يرفض الدخول لحماية החساب.")
        elif t['bias'] in ["SHORT", "BEARISH"] and bot_bias == "BULLISH":
            print("❌ قرار البوت: [HOLD] - المتداول البشري يحاول البيع في ترند صاعد. البوت يرفض الدخول لحماية الحساب.")
        else:
            print("✅ قرار البوت: الاتجاه متوافق. البوت سيسمح بالانتقال لفحص الفريمات الأصغر (15m و 5m) للبحث عن פجوة وسحب.")
            
    except Exception as e:
        print(f"خطأ في معالجة الداتا: {e}")

