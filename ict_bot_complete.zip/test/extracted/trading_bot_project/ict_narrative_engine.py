# -*- coding: utf-8 -*-
"""
ict_narrative_engine.py — المحرك السردي الذكي
═══════════════════════════════════════════════
كود بيفكر. بيفهم القصة. مش بيقارن أرقام.

كل قرار مبني على سؤال: "شو عم يصير بالسوق هلق؟"
مش "هل الرقم أكبر من 1.5؟"

المبادئ:
1. السياق يحكم كل شي — نفس الرقم ممكن يكون إشارة ممتازة
   أو ضجيج، حسب وين ومتى وشو صار قبل
2. كل حدث مرتبط بالأحداث قبله — سلسلة سببية
3. الثقة ليست ثنائية (نعم/لا) — هي طيف
4. ما فيه "أرقام سحرية" — كل عتبة مشتقة من السياق الحالي
"""
import numpy as np
from ict_math_engine import detect_ict_three_candle_swings, _atr


class MarketContext:
    """يقرأ السوق ويفهم شو عم يصير — مش بس أرقام."""
    
    def __init__(self, data, timeframe_label="5m"):
        self.data = data
        self.tf = timeframe_label
        self.n = len(data.get('closes', []))
        self.highs = np.asarray(data.get('highs', []), dtype=float)
        self.lows = np.asarray(data.get('lows', []), dtype=float)
        self.opens = np.asarray(data.get('opens', []), dtype=float)
        self.closes = np.asarray(data.get('closes', []), dtype=float)
        self.timestamps = data.get('timestamps', [])
        
        # فهم الحالة الحالية
        self.atr_values = _atr(self.highs, self.lows, self.closes) if self.n > 15 else np.zeros(self.n)
        self.current_atr = float(self.atr_values[-1]) if self.n > 15 and self.atr_values[-1] > 0 else float(abs(self.closes[-1]) * 0.003)
        self.current_price = float(self.closes[-1]) if self.n > 0 else 0
        self.swings = detect_ict_three_candle_swings(data) if self.n > 3 else {'swing_highs': [], 'swing_lows': []}
        
        # فهم "الإيقاع" الحالي — كم السوق عم يتحرك بالمتوسط
        self._compute_rhythm()
    
    def _compute_rhythm(self):
        """يفهم إيقاع السوق — هل هادي ولا عنيف؟"""
        if self.n < 10:
            self.avg_body = self.current_atr * 0.3
            self.avg_range = self.current_atr * 0.5
            self.volatility_regime = "UNKNOWN"
            return
        
        recent = min(20, self.n)
        bodies = np.abs(self.closes[-recent:] - self.opens[-recent:])
        ranges = self.highs[-recent:] - self.lows[-recent:]
        
        self.avg_body = float(np.mean(bodies))
        self.avg_range = float(np.mean(ranges))
        self.median_body = float(np.median(bodies))
        
        # مقارنة الـATR الحالي بالمتوسط — هل السوق أهدأ أو أعنف من العادة
        if self.current_atr > 0:
            range_ratio = self.avg_range / self.current_atr
            if range_ratio > 1.3:
                self.volatility_regime = "HIGH"
            elif range_ratio < 0.7:
                self.volatility_regime = "LOW"
            else:
                self.volatility_regime = "NORMAL"
        else:
            self.volatility_regime = "UNKNOWN"


class NarrativeDisplacement:
    """
    يكتشف displacement بفهم — مش بأرقام ثابتة.
    
    السؤال: "هل هاي الشمعة حدث استثنائي بالنسبة لما حولها؟"
    مش: "هل body > 1.5 ATR؟"
    
    المصادر:
    - ictkillzone.com: "significantly larger than 3-5 preceding candles"
    - innercircletrader.net: "body-to-range ratio above ~75%"
    - 2022 Notes: "displacement = energetic/pronounced move"
    - fxnx.com: "prompt, energetic reaction"
    """
    
    @staticmethod
    def detect(ctx, lookback=30):
        """
        يكتشف displacement بالسياق:
        
        شرط 1: هل الشمعة "أكبر بشكل ملحوظ" من محيطها؟
          → مش رقم ثابت. بنقارن بمتوسط آخر 5 شموع.
          → "ملحوظ" = فوق 2× المتوسط (مرجع: "at minimum 2x")
          → لكن بسوق هادي، حتى 1.8× ممكن يكون ملحوظ
          → وبسوق عنيف، 2× عادي — لازم 2.5×+
        
        شرط 2: هل الشمعة "اتجاهية"؟ (body dominates range)
          → body/range ≥ 60% (مرجع: FibAlgo "60-70%")
          → لكن بسوق هادي حيث كل الشموع فتائل: 55% كافي
          → بسوق trending حيث كل الشموع أجسام: 70%+ مطلوب
        
        شرط 3: هل تركت أثر؟ (FVG)
          → displacement حقيقي يخلق imbalance
          → "Without displacement, there is no valid FVG entry"
        """
        n = ctx.n
        if n < 10:
            return []
        
        start = max(6, n - lookback)
        results = []
        
        for i in range(start, n):
            body = abs(ctx.closes[i] - ctx.opens[i])
            rng = ctx.highs[i] - ctx.lows[i]
            if rng <= 0 or body <= 0:
                continue
            
            body_pct = body / rng
            
            # ═══ سياقي: ما هو "ملحوظ" هنا؟ ═══
            prev_start = max(0, i - 5)
            prev_bodies = [abs(ctx.closes[j] - ctx.opens[j]) for j in range(prev_start, i)]
            if not prev_bodies or np.mean(prev_bodies) <= 0:
                continue
            
            avg_prev_body = np.mean(prev_bodies)
            body_multiple = body / avg_prev_body
            
            # العتبة تتكيف مع حالة السوق:
            # سوق هادي (volatility LOW): 1.8× كافي لأنو أي حركة بتكون ملحوظة
            # سوق عادي: 2.0× (المرجع القياسي)
            # سوق عنيف (HIGH): 2.5× لأنو الشموع الكبيرة عادية
            if ctx.volatility_regime == "LOW":
                multiple_threshold = 1.8
                body_pct_threshold = 0.55
            elif ctx.volatility_regime == "HIGH":
                multiple_threshold = 2.5
                body_pct_threshold = 0.70
            else:
                multiple_threshold = 2.0
                body_pct_threshold = 0.60
            
            if body_multiple < multiple_threshold:
                continue
            if body_pct < body_pct_threshold:
                continue
            
            # ═══ هل تركت FVG؟ ═══
            leaves_fvg = False
            fvg_details = None
            if i >= 1 and i < n - 1:
                if ctx.closes[i] > ctx.opens[i]:  # bullish
                    if ctx.lows[i + 1] > ctx.highs[i - 1]:
                        leaves_fvg = True
                        fvg_details = {
                            'direction': 'BULLISH',
                            'top': float(ctx.lows[i + 1]),
                            'bottom': float(ctx.highs[i - 1]),
                            'ce': float((ctx.lows[i + 1] + ctx.highs[i - 1]) / 2),
                        }
                else:  # bearish
                    if ctx.highs[i + 1] < ctx.lows[i - 1]:
                        leaves_fvg = True
                        fvg_details = {
                            'direction': 'BEARISH',
                            'top': float(ctx.lows[i - 1]),
                            'bottom': float(ctx.highs[i + 1]),
                            'ce': float((ctx.lows[i - 1] + ctx.highs[i + 1]) / 2),
                        }
            
            # ═══ حساب "قوة الاقتناع" — مش ثنائي ═══
            # كل ما كان أكبر وأنظف = أقوى اقتناع
            conviction = 0.0
            conviction += min(1.0, (body_multiple - multiple_threshold) / multiple_threshold) * 30
            conviction += min(1.0, (body_pct - body_pct_threshold) / (1.0 - body_pct_threshold)) * 30
            if leaves_fvg:
                conviction += 25
            # هل أغلق قرب الـextreme؟ (مرجع: "closes near its extreme")
            if ctx.closes[i] > ctx.opens[i]:  # bullish
                close_to_high = (ctx.closes[i] - ctx.lows[i]) / rng
            else:
                close_to_high = (ctx.highs[i] - ctx.closes[i]) / rng
            conviction += close_to_high * 15
            
            direction = "BULLISH" if ctx.closes[i] > ctx.opens[i] else "BEARISH"
            
            results.append({
                'index': i,
                'index_from_end': i - n,
                'direction': direction,
                'body': round(body, 4),
                'body_multiple': round(body_multiple, 2),
                'body_pct': round(body_pct * 100, 1),
                'leaves_fvg': leaves_fvg,
                'fvg': fvg_details,
                'conviction': round(min(100, conviction), 1),
                'is_valid': leaves_fvg,  # بدون FVG مش displacement حقيقي
                'context_note': f"{ctx.volatility_regime} vol, threshold={multiple_threshold}x/{body_pct_threshold*100:.0f}%",
            })
        
        return results


class NarrativeSweep:
    """
    يكتشف sweep بفهم — مش بس "wick تجاوز وclose رجع".
    
    السؤال: "هل السوق سحب سيولة حقيقية بشكل متعمد؟"
    
    يفحص:
    1. هل المستوى كان سيولة حقيقية (مرئية ومهمة)؟
    2. هل الاختراق كان حاد وسريع (مش تدريجي)؟
    3. هل الإغلاق رجع بقوة (rejection حقيقي)؟
    4. هل في displacement بعده (confirmation)؟
    """
    
    @staticmethod
    def detect(ctx, bias, search_window=15):
        """يبحث عن sweep بالسياق الكامل."""
        is_long = bias == "BULLISH"
        n = ctx.n
        
        # الخطوة 1: حدد مستويات السيولة (swing lows/highs)
        target_swings = ctx.swings['swing_lows'] if is_long else ctx.swings['swing_highs']
        
        if not target_swings:
            return None
        
        best_sweep = None
        best_quality = 0
        
        search_start = max(0, n - search_window)
        
        for sw in target_swings:
            sw_idx = sw['index']
            if sw_idx >= n - 2:  # لازم يكون في شموع بعده
                continue
            
            # ابحث عن sweep لهذا المستوى
            for i in range(max(sw_idx + 1, search_start), n):
                if is_long:
                    wicked_beyond = ctx.lows[i] < sw['price']
                    closed_back = ctx.closes[i] > sw['price']
                    penetration = sw['price'] - ctx.lows[i] if wicked_beyond else 0
                else:
                    wicked_beyond = ctx.highs[i] > sw['price']
                    closed_back = ctx.closes[i] < sw['price']
                    penetration = ctx.highs[i] - sw['price'] if wicked_beyond else 0
                
                if not (wicked_beyond and closed_back):
                    continue
                
                # ═══ تقييم جودة السحب ═══
                quality = 0
                
                # 1. عمق الاختراق — اختراق عميق = أكثر اقتناعاً
                penetration_in_atr = penetration / ctx.current_atr if ctx.current_atr > 0 else 0
                quality += min(25, penetration_in_atr * 50)
                
                # 2. سرعة الرفض — الشمعة أغلقت بعيد عن الـextreme
                candle_range = ctx.highs[i] - ctx.lows[i]
                if candle_range > 0:
                    if is_long:
                        rejection_strength = (ctx.closes[i] - ctx.lows[i]) / candle_range
                    else:
                        rejection_strength = (ctx.highs[i] - ctx.closes[i]) / candle_range
                    quality += rejection_strength * 25
                
                # 3. هل المستوى "مرئي"؟ (swing واضح مش swing تافه)
                # swing قديم (أكثر من 20 شمعة) = أكثر أهمية
                age = i - sw_idx
                if age > 20:
                    quality += 15
                elif age > 10:
                    quality += 10
                
                # 4. هل في equal lows/highs؟ (double bottom/top = سيولة مكدسة)
                near_levels = [s['price'] for s in target_swings 
                              if abs(s['price'] - sw['price']) < ctx.current_atr * 0.3
                              and s['index'] != sw_idx]
                if near_levels:
                    quality += 20  # سيولة مكدسة!
                
                # 5. حداثة — الأحدث أهم
                recency = (i - search_start) / max(1, n - search_start)
                quality += recency * 15
                
                if quality > best_quality:
                    best_quality = quality
                    best_sweep = {
                        'level': sw['price'],
                        'sweep_index': i,
                        'sweep_ts': ctx.timestamps[i] if i < len(ctx.timestamps) else None,
                        'side': 'SSL' if is_long else 'BSL',
                        'wick_extreme': float(ctx.lows[i]) if is_long else float(ctx.highs[i]),
                        'penetration': round(penetration, 4),
                        'quality': round(quality, 1),
                        'rejection_strength': round(rejection_strength if candle_range > 0 else 0, 2),
                        'has_stacked_liquidity': len(near_levels) > 0,
                    }
        
        return best_sweep


class NarrativeStopLoss:
    """
    يحدد الستوب بفهم — "أين تنتهي القصة؟"
    
    مش رقم ثابت. بل: إذا السعر وصل هون = التحليل كله كان غلط.
    
    المصدر: arongroups.co: "structural invalidation, not arbitrary pip distance"
    المصدر: مايكل Ep6: "You want a lot of range when starting out"
    المصدر: innercircletrader.net: "beyond the swept extreme"
    """
    
    @staticmethod
    def compute(ctx, sweep, fvg, entry_price, is_long):
        """يحدد SL بالسياق."""
        
        # ═══ جمع كل نقاط الإبطال المحتملة ═══
        invalidation_levels = []
        
        # 1. خلف sweep wick (الأساسي — "beyond the swept extreme")
        invalidation_levels.append({
            'price': sweep['wick_extreme'],
            'reason': 'SWEEP_EXTREME',
            'weight': 3,
        })
        
        # 2. خلف أبعد swing في الاتجاه المعاكس (structural invalidation)
        if is_long:
            lower_swings = [s['price'] for s in ctx.swings['swing_lows'] 
                          if s['price'] < entry_price]
            if lower_swings:
                invalidation_levels.append({
                    'price': min(lower_swings),
                    'reason': 'DEEPEST_SWING',
                    'weight': 2,
                })
        else:
            higher_swings = [s['price'] for s in ctx.swings['swing_highs']
                           if s['price'] > entry_price]
            if higher_swings:
                invalidation_levels.append({
                    'price': max(higher_swings),
                    'reason': 'DEEPEST_SWING',
                    'weight': 2,
                })
        
        # 3. خلف FVG far edge (أقل مستوى حماية — لكن هيكلي)
        if fvg:
            if is_long:
                invalidation_levels.append({
                    'price': fvg['bottom'],
                    'reason': 'FVG_FAR_EDGE',
                    'weight': 1,
                })
            else:
                invalidation_levels.append({
                    'price': fvg['top'],
                    'reason': 'FVG_FAR_EDGE',
                    'weight': 1,
                })
        
        # ═══ اختر الأوسع (الأكثر حماية) ═══
        # مايكل: "the widest one defines the structural invalidation"
        if is_long:
            # Long: أدنى نقطة = أوسع حماية
            chosen = min(invalidation_levels, key=lambda x: x['price'])
        else:
            # Short: أعلى نقطة = أوسع حماية
            chosen = max(invalidation_levels, key=lambda x: x['price'])
        
        sl_base = chosen['price']
        
        # ═══ Buffer ديناميكي — مش رقم ثابت ═══
        # "Stops parked exactly at the level get hunted on the wick"
        # Buffer = حسب حالة السوق:
        if ctx.volatility_regime == "HIGH":
            buffer_factor = 0.20  # سوق عنيف = buffer أكبر
        elif ctx.volatility_regime == "LOW":
            buffer_factor = 0.10  # سوق هادي = buffer أصغر
        else:
            buffer_factor = 0.15  # عادي
        
        buffer = ctx.current_atr * buffer_factor
        
        if is_long:
            sl_price = sl_base - buffer
        else:
            sl_price = sl_base + buffer
        
        distance = abs(entry_price - sl_price)
        
        # ═══ فحص "هل المخاطرة منطقية؟" ═══
        # مايكل Ep6: "إذا المخاطرة كبيرة: لا تأخذ الصفقة"
        # العكس أيضاً: إذا صغيرة جداً = سيُضرب بالnoise
        
        min_distance = ctx.current_atr * 0.5
        max_distance = ctx.current_atr * 8  # أكثر من 8 ATR = غير منطقي
        
        tradeable = True
        rejection_reason = None
        
        if distance < min_distance:
            tradeable = False
            rejection_reason = f"SL too tight ({distance:.0f} < {min_distance:.0f} = 0.5×ATR)"
        elif distance > max_distance:
            tradeable = False
            rejection_reason = f"SL too wide ({distance:.0f} > {max_distance:.0f} = 8×ATR)"
        
        return {
            'price': round(sl_price, 6),
            'distance': round(distance, 2),
            'distance_pct': round(distance / entry_price * 100, 4),
            'atr_multiple': round(distance / ctx.current_atr, 2) if ctx.current_atr > 0 else 0,
            'method': chosen['reason'],
            'buffer': round(buffer, 2),
            'tradeable': tradeable,
            'rejection_reason': rejection_reason,
            'all_levels_considered': invalidation_levels,
        }


class NarrativeTargets:
    """
    يحدد الأهداف بفهم — "أين السيولة التالية؟"
    
    TP1 = Low Hanging Fruit (أقرب سيولة — safe money)
    TP2 = Draw on Liquidity (أبعد سيولة على HTF — golden money)
    
    المصادر:
    - 2022 Notes: "closest target (low-hanging fruit)"
    - 2022 Notes: "Draw on Liquidity found on Daily Chart"
    - innercircletrader.net Fib: "partials at -1.0, trailing toward -2.0"
    """
    
    @staticmethod
    def compute(ctx_entry, ctx_htf, entry_price, sl_price, sweep, is_long):
        """يحدد TP1 وTP2 بالسياق."""
        risk = abs(entry_price - sl_price)
        if risk <= 0:
            return {'tp1': None, 'tp2': None}
        
        # ═══ TP1: Low Hanging Fruit ═══
        # "أقرب مستوى سيولة حقيقي باتجاه الصفقة"
        tp1_candidates = []
        
        # 1. Swings على فريم الدخول
        target_swings = ctx_entry.swings['swing_highs'] if is_long else ctx_entry.swings['swing_lows']
        for sw in target_swings:
            price = sw['price']
            if (is_long and price > entry_price) or (not is_long and price < entry_price):
                dist = abs(price - entry_price)
                rr = dist / risk
                if rr >= 1.5:
                    tp1_candidates.append({
                        'price': price, 'kind': 'SWING',
                        'rr': round(rr, 2), 'dist': dist,
                        'source': ctx_entry.tf,
                    })
        
        # 2. Fib -1.0 extension
        impulse = abs(entry_price - sweep['wick_extreme'])
        if impulse > 0:
            fib_1 = entry_price + impulse if is_long else entry_price - impulse
            fib_rr = impulse / risk
            if fib_rr >= 1.5:
                tp1_candidates.append({
                    'price': round(fib_1, 6), 'kind': 'FIB_-1.0',
                    'rr': round(fib_rr, 2), 'dist': impulse,
                    'source': 'FIB',
                })
        
        # اختر الأقرب (low hanging fruit)
        tp1_candidates.sort(key=lambda c: c['dist'])
        tp1 = tp1_candidates[0] if tp1_candidates else None
        
        # ═══ TP2: Draw on Liquidity (HTF) ═══
        tp2 = None
        if ctx_htf and ctx_htf.n > 10:
            tp2_candidates = []
            htf_targets = ctx_htf.swings['swing_highs'] if is_long else ctx_htf.swings['swing_lows']
            
            for sw in htf_targets:
                price = sw['price']
                if (is_long and price > entry_price + risk * 3) or \
                   (not is_long and price < entry_price - risk * 3):
                    dist = abs(price - entry_price)
                    rr = dist / risk
                    tp2_candidates.append({
                        'price': price, 'kind': 'HTF_DRAW',
                        'rr': round(rr, 2), 'dist': dist,
                        'source': ctx_htf.tf,
                    })
            
            # Fib -2.0
            if impulse > 0:
                fib_2 = entry_price + impulse * 2 if is_long else entry_price - impulse * 2
                fib2_rr = (impulse * 2) / risk
                if fib2_rr >= 3:
                    tp2_candidates.append({
                        'price': round(fib_2, 6), 'kind': 'FIB_-2.0',
                        'rr': round(fib2_rr, 2), 'dist': impulse * 2,
                        'source': 'FIB',
                    })
            
            # اختر: أقرب مستوى HTF يعطي RR جيد (مش أبعد!)
            # مايكل: "opposite end of the range" — عملي مش خيالي
            tp2_candidates.sort(key=lambda c: c['dist'])
            tp2 = tp2_candidates[0] if tp2_candidates else None
        
        if not tp2:
            tp2 = {'mode': 'OPEN_TRAILING', 'kind': 'STRUCTURAL_TRAIL'}
        
        return {'tp1': tp1, 'tp2': tp2}


class NarrativeTradeManager:
    """
    يدير الصفقة بفهم — مش بأرقام.
    
    يسأل كل شمعة: "هل القصة لسا صحيحة؟"
    
    المصادر:
    - 2022 Notes: "trailing stop below previous bullish OB's low"
    - 2022 Notes: "If your ITH is broken... your idea was wrong"
    - 2022 Notes: "down-closed candles should support price" (bullish)
    - fxnx.com: "prompt, energetic reaction back in your direction"
    """
    
    @staticmethod
    def update(candle, state, ctx_trail=None):
        """
        يحدث الصفقة شمعة بشمعة.
        
        state = dict مع:
            entry, sl, tp1, tp2, is_short,
            tp1_hit, phase, confirmed_structure_levels, ...
        
        ctx_trail = MarketContext للفريم الأعلى (15m) — للـtrailing الذكي
        """
        h, l, c, o = candle['h'], candle['l'], candle['c'], candle.get('o', candle['c'])
        is_short = state['is_short']
        events = []
        closed = False
        
        # ═══ PHASE 1: قبل TP1 ═══
        if not state.get('tp1_hit'):
            # SL check
            if (is_short and h >= state['sl']) or (not is_short and l <= state['sl']):
                state['exit_price'] = state['sl']
                state['exit_reason'] = 'SL_HIT'
                state['pnl_pct'] = -abs(state['entry'] - state['sl']) / state['entry'] * 100
                events.append('❌ SL')
                closed = True
                return events, closed
            
            # TP1 check
            tp1_price = state.get('tp1')
            if tp1_price:
                if (is_short and l <= tp1_price) or (not is_short and h >= tp1_price):
                    state['tp1_hit'] = True
                    state['tp1_pnl'] = abs(tp1_price - state['entry']) / state['entry'] * 100 * 0.5
                    state['sl'] = state['entry']  # BE
                    state['phase'] = 'RUNNER'
                    events.append(f"🎯 TP1 +BE")
                    
                    # تهيئة الـtrailing — نبدأ بـBE
                    state['trail_anchor'] = state['entry']
        
        # ═══ PHASE 2: RUNNER (بعد TP1) ═══
        elif state.get('tp1_hit') and not closed:
            # TP2 check
            tp2 = state.get('tp2')
            if isinstance(tp2, dict) and tp2.get('price'):
                tp2_price = tp2['price']
                if (is_short and l <= tp2_price) or (not is_short and h >= tp2_price):
                    state['tp2_hit'] = True
                    state['exit_price'] = tp2_price
                    state['exit_reason'] = 'TP2_GOLDEN'
                    tp2_pnl = abs(tp2_price - state['entry']) / state['entry'] * 100 * 0.5
                    state['pnl_pct'] = state.get('tp1_pnl', 0) + tp2_pnl
                    events.append(f"🏆 TP2 GOLDEN!")
                    closed = True
                    return events, closed
            
            # Trailing check
            if (is_short and h >= state['sl']) or (not is_short and l <= state['sl']):
                state['exit_price'] = state['sl']
                state['exit_reason'] = 'TRAIL_EXIT'
                trail_pnl = abs(state['sl'] - state['entry']) / state['entry'] * 100 * 0.5
                # إذا trailing عند BE = 0, يعني ربح TP1 فقط
                if abs(state['sl'] - state['entry']) < state.get('min_tick', 1):
                    trail_pnl = 0
                state['pnl_pct'] = state.get('tp1_pnl', 0) + trail_pnl
                events.append(f"🧠 Trail exit")
                closed = True
                return events, closed
            
            # ═══ TRAILING الذكي ═══
            # مايكل: "trailing stop below previous down-closed candle"
            # مش أي swing — بل شموع اتجاهية (OB-like behavior)
            #
            # الفكرة الذكية:
            # بدل ما نلاحق كل swing على 5m (noise!)
            # نلاحق "مستويات هيكلية" — يعني:
            #   - شمعة أغلقت بقوة بالاتجاه (OB-like)
            #   - تشكل swing مؤكد على فريم أعلى
            #   - أو accumulation zone (عدة شموع بنفس المنطقة)
            
            # Approach: "Structural Support/Resistance Trail"
            # نبحث عن آخر "support level" = أدنى نقطة بين آخر شمعتين صعوديتين
            if not is_short:
                # Long: نبحث عن "higher low" حقيقي
                # "down-closed candles should support price"
                # = شمعة هابطة ما كسرت القاع السابق → support
                if c > o:  # شمعة صعودية
                    # قاع هاي الشمعة الصعودية = support محتمل
                    potential_support = l
                    if potential_support > state.get('trail_anchor', state['entry']):
                        old_sl = state['sl']
                        state['sl'] = potential_support - (state.get('atr', abs(state['entry']*0.001)) * 0.1)
                        if state['sl'] > old_sl:
                            events.append(f"📈 Trail→{state['sl']:.0f}")
                            state['trail_anchor'] = potential_support
                        else:
                            state['sl'] = old_sl  # لا تتراجع!
            else:
                # Short: mirror
                if c < o:  # شمعة هابطة
                    potential_resistance = h
                    if potential_resistance < state.get('trail_anchor', state['entry']):
                        old_sl = state['sl']
                        state['sl'] = potential_resistance + (state.get('atr', abs(state['entry']*0.001)) * 0.1)
                        if state['sl'] < old_sl:
                            events.append(f"📉 Trail→{state['sl']:.0f}")
                            state['trail_anchor'] = potential_resistance
                        else:
                            state['sl'] = old_sl
        
        return events, closed
