import sys, time
sys.path.insert(0, ".")
from data_manager import DataManager
from authenticity_engine import AuthenticityEngine
from ict_math_engine import classify_sweep_or_run

dm = DataManager()
data_15m = dm.get_ohlcv("SOLUSDT", "15m", 200, output_format="dict")
closed_15m = {k: v[:-1] for k, v in data_15m.items() if isinstance(v, list)}
current_p = data_15m['closes'][-1]
ae = AuthenticityEngine()
sig = ae.detect_significant_swings(closed_15m, swing_window=3, lookback_candles=150)

lows_raw = [s for s in sig.get("all_lows_tiered", []) if s['price'] < current_p and s.get("tier") in ["MAJOR", "MODERATE"]]
lows = []
n_closes = len(closed_15m['closes'])
check_idx = n_closes - 1
for s in lows_raw:
    s_idx = n_closes + s['index_from_end']
    if s_idx < check_idx - 1:
        min_before = min(closed_15m['lows'][s_idx+1 : check_idx])
        if min_before < s['price']:
            continue
    lows.append(s)

if lows:
    lows.sort(key=lambda x: current_p - x['price'])
    valid_target = lows[0]
    print(f"Nearest Valid SSL: {valid_target['price']}")
else:
    print("No valid SSL found.")

