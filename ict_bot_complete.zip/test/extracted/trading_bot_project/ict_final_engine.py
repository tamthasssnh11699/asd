# -*- coding: utf-8 -*-
"""
ict_final_engine.py — المحرك النهائي
═════════════════════════════════════
يجمع أفضل ما وصلنا إليه:

1. PD Array Runner (trailing خلف FVG/OB حقيقية)
2. Multi-TF Narrative Filter (B يخرج على 15M إغلاق — مش 5M)
3. B يقفل عند +1R hard floor بعد 3R (حماية أرباح)
4. C يلاحق HTF DOL على 4H structure
5. Premium/Discount filter (لا trailing بالـDiscount)
"""
import numpy as np


class PDTracker:
    """يتتبع PD Arrays على فريم واحد."""
    def __init__(self, label=""):
        self.label = label
        self.candles = []
        self.fvgs = []
        self.obs = []
        self.swings_lo = []
        self.swings_hi = []
    
    def add(self, c):
        self.candles.append(c)
        n = len(self.candles)
        if n < 3: return
        c1,c2,c3 = self.candles[-3], self.candles[-2], self.candles[-1]
        
        # FVG
        if c3['l'] > c1['h']:
            self.fvgs.append({'t':'BULL','top':c3['l'],'bot':c1['h'],'ce':(c3['l']+c1['h'])/2,'live':True,'idx':n-2})
        if c3['h'] < c1['l']:
            self.fvgs.append({'t':'BEAR','top':c1['l'],'bot':c3['h'],'ce':(c1['l']+c3['h'])/2,'live':True,'idx':n-2})
        
        # OB
        if n >= 2:
            p,cu = self.candles[-2], self.candles[-1]
            if p['c']<p['o'] and cu['c']>cu['o'] and cu['c']>p['h'] and cu['l']<=p['l']:
                self.obs.append({'t':'BULL','top':p['h'],'bot':p['l'],'live':True,'idx':n-2})
            if p['c']>p['o'] and cu['c']<cu['o'] and cu['c']<p['l'] and cu['h']>=p['h']:
                self.obs.append({'t':'BEAR','top':p['h'],'bot':p['l'],'live':True,'idx':n-2})
        
        # Update fills
        for f in self.fvgs:
            if not f['live']: continue
            if f['t']=='BULL' and c3['c']<f['bot']: f['live']=False
            elif f['t']=='BEAR' and c3['c']>f['top']: f['live']=False
        for o in self.obs:
            if not o['live']: continue
            if o['t']=='BULL' and c3['c']<o['bot']: o['live']=False
            elif o['t']=='BEAR' and c3['c']>o['top']: o['live']=False
        
        # Structural swings (need 5 candles)
        if n >= 5:
            mid = n-3
            if all(self.candles[mid]['l'] < self.candles[mid+d]['l'] for d in [-2,-1,1,2]):
                disp = self._has_displacement(mid)
                self.swings_lo.append({'p':self.candles[mid]['l'],'i':mid,'disp':disp})
            if all(self.candles[mid]['h'] > self.candles[mid+d]['h'] for d in [-2,-1,1,2]):
                disp = self._has_displacement(mid)
                self.swings_hi.append({'p':self.candles[mid]['h'],'i':mid,'disp':disp})
    
    def _has_displacement(self, mid):
        n = len(self.candles)
        for k in range(mid+1, min(mid+4, n)):
            body = abs(self.candles[k]['c']-self.candles[k]['o'])
            rng = self.candles[k]['h']-self.candles[k]['l']
            if rng > 0 and body/rng > 0.5:
                prev = [abs(self.candles[j]['c']-self.candles[j]['o']) for j in range(max(0,k-3),k)]
                if prev and body > np.mean(prev)*1.5: return True
        return False
    
    def best_pd_trail(self, is_long, ref_price, buf=0):
        """أفضل مستوى PD Array للـtrailing."""
        cands = []
        if is_long:
            for f in self.fvgs:
                if f['t']=='BULL' and f['live'] and f['bot']<ref_price: cands.append(f['bot']-buf)
            for o in self.obs:
                if o['t']=='BULL' and o['live'] and o['bot']<ref_price: cands.append(o['bot']-buf)
            for s in self.swings_lo:
                if s['disp'] and s['p']<ref_price: cands.append(s['p']-buf)
            return max(cands) if cands else None
        else:
            for f in self.fvgs:
                if f['t']=='BEAR' and f['live'] and f['top']>ref_price: cands.append(f['top']+buf)
            for o in self.obs:
                if o['t']=='BEAR' and o['live'] and o['top']>ref_price: cands.append(o['top']+buf)
            for s in self.swings_hi:
                if s['disp'] and s['p']>ref_price: cands.append(s['p']+buf)
            return min(cands) if cands else None
    
    def narrative_broken(self, is_long, close_price):
        """هل القصة انتهت على هالفريم؟ (body close through PD Array)"""
        if is_long:
            for f in self.fvgs[-3:]:
                if f['t']=='BULL' and f['live'] and close_price<f['bot']:
                    f['live']=False; return True, f"FVG broken {f['bot']:.0f}"
            for o in self.obs[-3:]:
                if o['t']=='BULL' and o['live'] and close_price<o['bot']:
                    o['live']=False; return True, f"OB broken {o['bot']:.0f}"
        else:
            for f in self.fvgs[-3:]:
                if f['t']=='BEAR' and f['live'] and close_price>f['top']:
                    f['live']=False; return True, f"FVG broken {f['top']:.0f}"
            for o in self.obs[-3:]:
                if o['t']=='BEAR' and o['live'] and close_price>o['top']:
                    o['live']=False; return True, f"OB broken {o['top']:.0f}"
        return False, "OK"


def manage_final(c5, c15, c4h, state):
    """
    المحرك النهائي:
    A (60%): Scalp → TP1 → trailing سريع على 5M
    B (30%): Day Runner → 15M narrative filter → +1R hard floor بعد 3R
    C (10%): Swing Runner → 4H structure → 5 أيام max
    """
    h,l,c,o = c5['h'],c5['l'],c5['c'],c5.get('o',c5['c'])
    is_short=state['is_short']; is_long=not is_short
    events=[]; risk=state['risk']
    
    # Init trackers
    if 'pd15' not in state: state['pd15']=PDTracker("15M")
    if 'pd4h' not in state: state['pd4h']=PDTracker("4H")
    if c15: state['pd15'].add(c15)
    if c4h: state['pd4h'].add(c4h)
    
    state['candle_count']=state.get('candle_count',0)+1
    days=state['candle_count']/288
    
    # Track best price for Premium/Discount
    bp=state.get('best_price',state.get('pos_a',{}).get('entry',c))
    if is_long and h>bp: state['best_price']=h; bp=h
    elif is_short and l<bp: state['best_price']=l; bp=l
    entry=state.get('pos_a',{}).get('entry',c)
    wave=abs(bp-entry)
    in_discount = False
    if wave>0:
        ret = ((bp-c)/wave*100) if is_long else ((c-bp)/wave*100)
        in_discount = ret > 50
    
    atr=state.get('atr',1)
    
    # ═══ A: Scalp ═══
    pa=state.get('pos_a',{})
    if pa.get('active'):
        if not pa.get('tp1_hit'):
            if (is_short and h>=pa['sl']) or (is_long and l<=pa['sl']):
                pa['active']=False;pa['pnl']=-state['risk_pct_a'];pa['exit_reason']='SL';events.append('❌ A:SL')
            elif pa.get('tp1'):
                if (is_short and l<=pa['tp1']) or (is_long and h>=pa['tp1']):
                    pa['tp1_hit']=True;rr=abs(pa['tp1']-pa['entry'])/risk if risk>0 else 0
                    pa['pnl']=rr*state['risk_pct_a'];pa['sl']=pa['entry'];events.append('🎯 A:TP1')
        elif pa.get('tp1_hit'):
            if (is_short and h>=pa['sl']) or (is_long and l<=pa['sl']):
                pa['active']=False;pa['exit_reason']='A_TR';events.append('🧠 A:Tr')
            else:
                body=abs(c-o);rng=h-l
                if rng>0 and body/rng>0.5:
                    if is_long and c>o:
                        ns=l-atr*0.1
                        if ns>pa['sl']:pa['sl']=ns
                    elif is_short and c<o:
                        ns=h+atr*0.1
                        if ns<pa['sl']:pa['sl']=ns
    
    # ═══ B: Day Runner (15M narrative — مش 5M!) ═══
    pb=state.get('pos_b',{})
    if pb.get('active'):
        # TP2
        if pb.get('tp2_price'):
            if (is_short and l<=pb['tp2_price']) or (is_long and h>=pb['tp2_price']):
                pb['active']=False;rr=abs(pb['tp2_price']-pb['entry'])/risk if risk>0 else 0
                pb['pnl']=rr*state['risk_pct_b'];pb['exit_reason']='TP2';events.append('🏆 B:TP2')
        
        if pb.get('active') and not pb.get('be_set'):
            if (is_short and h>=pb['sl']) or (is_long and l<=pb['sl']):
                pb['active']=False;pb['pnl']=-state['risk_pct_b'];pb['exit_reason']='SL';events.append('❌ B:SL')
        
        if pb.get('active') and pb.get('be_set'):
            # SL check
            if (is_short and h>=pb['sl']) or (is_long and l<=pb['sl']):
                pb['active']=False
                rr=abs(pb['sl']-pb['entry'])/risk if risk>0 else 0
                ok=(is_long and pb['sl']>pb['entry']) or (is_short and pb['sl']<pb['entry'])
                pb['pnl']=rr*state['risk_pct_b'] if ok else 0
                pb['exit_reason']='B_TR';events.append('🧠 B:Tr')
            else:
                # ══ Hard Floor: بعد 3R → قفل عند +1R ══
                current_move = abs(c - pb['entry'])
                current_rr = current_move / risk if risk>0 else 0
                if current_rr >= 3 and not pb.get('floor_set'):
                    floor = pb['entry'] + risk if is_long else pb['entry'] - risk  # +1R
                    if (is_long and floor > pb['sl']) or (is_short and floor < pb['sl']):
                        pb['sl'] = floor; pb['floor_set'] = True
                        events.append(f'🔒 B:Floor +1R')
                
                # ══ 15M Narrative check (مش 5M!) ══
                if c15:  # فقط عند إغلاق شمعة 15M
                    broken15, reason15 = state['pd15'].narrative_broken(is_long, c15['c'])
                    if broken15:
                        pb['active']=False
                        rr=abs(c-pb['entry'])/risk if risk>0 else 0
                        ok=(is_long and c>pb['entry']) or (is_short and c<pb['entry'])
                        pb['pnl']=rr*state['risk_pct_b'] if ok else 0
                        pb['exit_reason']='B_15M';events.append(f'📖 B:15M {reason15[:20]}')
                
                # PD Array trailing (فقط خارج Discount)
                if not in_discount and pb.get('active'):
                    tl=state['pd15'].best_pd_trail(is_long,pb['entry'],buf=atr*0.2)
                    if tl:
                        if is_long and tl>pb['sl']:pb['sl']=tl
                        elif is_short and tl<pb['sl']:pb['sl']=tl
        
        if pa.get('tp1_hit') and not pb.get('be_set') and pb.get('active'):
            pb['sl']=pb['entry'];pb['be_set']=True;events.append('🛡️ B:BE')
    
    # ═══ C: Swing Runner (4H — يبقى أيام!) ═══
    pc=state.get('pos_c',{})
    if pc.get('active'):
        # TP3
        if pc.get('tp3_price'):
            if (is_short and l<=pc['tp3_price']) or (is_long and h>=pc['tp3_price']):
                pc['active']=False;rr=abs(pc['tp3_price']-pc['entry'])/risk if risk>0 else 0
                pc['pnl']=rr*state['risk_pct_c'];pc['exit_reason']='TP3';events.append('💎 C:TP3!')
                # Close A and B too
                for px in [pa,pb]:
                    if px.get('active'):
                        px['active']=False;rr_x=abs(pc['tp3_price']-px.get('entry',c))/risk if risk>0 else 0
                        px['pnl']=rr_x*state.get('risk_pct_a' if px is pa else 'risk_pct_b',0)
                        px['exit_reason']='WITH_C'
        
        if pc.get('active') and not pc.get('be_set'):
            if (is_short and h>=pc['sl']) or (is_long and l<=pc['sl']):
                pc['active']=False;pc['pnl']=-state['risk_pct_c'];pc['exit_reason']='SL';events.append('❌ C:SL')
        
        if pc.get('active') and pc.get('be_set'):
            if (is_short and h>=pc['sl']) or (is_long and l<=pc['sl']):
                pc['active']=False
                rr=abs(pc['sl']-pc['entry'])/risk if risk>0 else 0
                ok=(is_long and pc['sl']>pc['entry']) or (is_short and pc['sl']<pc['entry'])
                pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                pc['exit_reason']='C_TR';events.append('🧠 C:4H Tr')
            elif days>=5:
                pc['active']=False;ok=(is_long and c>pc['entry']) or (is_short and c<pc['entry'])
                rr=abs(c-pc['entry'])/risk if risk>0 else 0
                pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                pc['exit_reason']='5D';events.append('📅 C:5d')
            else:
                # 4H narrative (أبطأ بكثير)
                if c4h:
                    broken4h,reason4h=state['pd4h'].narrative_broken(is_long,c4h['c'])
                    if broken4h:
                        pc['active']=False
                        rr=abs(c-pc['entry'])/risk if risk>0 else 0
                        ok=(is_long and c>pc['entry']) or (is_short and c<pc['entry'])
                        pc['pnl']=rr*state['risk_pct_c'] if ok else 0
                        pc['exit_reason']='C_4H';events.append(f'📖 C:4H {reason4h[:20]}')
                
                # 4H PD trail (فقط خارج Discount)
                if not in_discount and pc.get('active'):
                    tl4=state['pd4h'].best_pd_trail(is_long,pc['entry'],buf=atr*0.4)
                    if tl4:
                        if is_long and tl4>pc['sl']:pc['sl']=tl4
                        elif is_short and tl4<pc['sl']:pc['sl']=tl4
        
        if pa.get('tp1_hit') and not pc.get('be_set') and pc.get('active'):
            pc['sl']=pc['entry'];pc['be_set']=True;events.append('🛡️ C:BE')
    
    done=(not pa.get('active',False)) and (not pb.get('active',False)) and (not pc.get('active',False))
    if done:
        state['pnl_pct']=(pa.get('pnl',0) or 0)+(pb.get('pnl',0) or 0)+(pc.get('pnl',0) or 0)
        state['exit_reason_a']=pa.get('exit_reason','?')
        state['exit_reason_b']=pb.get('exit_reason','?')
        state['exit_reason_c']=pc.get('exit_reason','?')
    return events,done
