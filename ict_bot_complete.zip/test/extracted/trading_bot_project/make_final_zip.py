import os
import zipfile

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        for file in files:
            if "__pycache__" not in root and ".git" not in root:
                ziph.write(os.path.join(root, file), 
                           os.path.relpath(os.path.join(root, file), 
                                           os.path.join(path, '..')))

with zipfile.ZipFile('/home/user/ICT_Sniper_Bot_Clean_Final.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir('.', zipf)
    
print("تم ضغط الملفات بنجاح.")
