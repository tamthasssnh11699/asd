import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 3500, output_format="dict")
n = len(full_data["closes"])
start_idx = max(500, n - 2880)

candidates = []
# فحص كل شمعة لتأمين أكبر عدد ممكن من الصفقات، لكن بشكل أسرع بقليل.
for i in range(start_idx, n, 3):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
        daily_bias = anchor.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"): continue

        current_ts = window_data["timestamps"][-1]
        sig = ae.detect_significant_swings(window_data, swing_window=1, lookback_candles=100)
        
        levels = sig.get("all_lows_tiered", []) if daily_bias == "BULLISH" else sig.get("all_highs_tiered", [])
        for cand in levels:
            res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(daily_bias=="BEARISH"), check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                # 4 ساعات cooldown
                if not any(abs(c["timestamp"] - current_ts) < 4*3600*1000 for c in candidates):
                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                    candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                    break
    except Exception: pass

candidates.sort(key=lambda c: c["timestamp"])

results = []
account = ACCOUNT_BALANCE

# تسريع فحص الشموع لتفادي التايم آوت: نفحص 4 مرات (تغطي 4 شمعات 15م = ساعة واحدة فقط كحد أقصى لدخول الماركت ميكر)
for cand in candidates:
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    found_trade = False
    for k in range(0, 16, 4):
        sim_ts = sweep_ts + (k * 5 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                plan = res.get("chosen_model", {}).get("plan", {})
                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    
                    if outcome and outcome.get("outcome") not in ["PENDING", "ENTRY_NEVER_HIT", "ORDER_INVALIDATED_BEFORE_FILL"]:
                        out_code = outcome.get("outcome")
                        sl_dist = abs(entry - sl)
                        risk_amount = account * RISK_PCT
                        pos_size = risk_amount / sl_dist if sl_dist > 0 else 0
                        
                        profit = 0.0
                        if out_code in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
                            tp1_dist = abs(tp1 - entry)
                            profit = (tp1_dist * pos_size) * 0.8 
                        elif out_code == "SL_HIT":
                            profit = -risk_amount
                        elif out_code == "DYNAMIC_TRAIL_HIT":
                            pnl_pct = outcome.get("pnl_pct", 0)
                            profit = (pnl_pct / 100) * risk_amount
                            
                        account += profit
                        results.append({
                            "date": cand['datetime_utc'][:16].replace('T', ' '),
                            "bias": "بيع 🔴" if is_short else "شراء 🟢",
                            "entry": entry,
                            "tp1": tp1,
                            "outcome": out_code,
                            "profit": profit,
                            "balance": account
                        })
                        found_trade = True
                        break
        except Exception: pass

print("="*100)
print(f"{'التاريخ (UTC)':<18} | {'الاتجاه':<8} | {'الدخول':<8} | {'الهدف (80%)':<12} | {'النتيجة النهائية للصفقة':<35} | {'الربح':<8} | {'الرصيد':<8}")
print("="*100)

for r in results:
    out_label = r['outcome']
    if out_label in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: out_label = "ربح جزئي وتأمين (80%) 🎯"
    elif out_label == "SL_HIT": out_label = "ضرب ستوب لوس ❌"
    elif out_label == "BREAK_EVEN_HIT": out_label = "خروج على الدخول (أمان) 🛡️"
    elif out_label == "DYNAMIC_TRAIL_HIT": out_label = "قنص هيكلي متتبع 🧠🎯"
    
    print(f"{r['date']:<18} | {r['bias']:<8} | {r['entry']:>7.2f} | {r['tp1']:>10.2f} | {out_label:<35} | {r['profit']:>6.2f}$ | {r['balance']:>6.2f}$")

wins = sum(1 for r in results if r['profit'] > 0)
losses = sum(1 for r in results if r['profit'] < 0)
bes = sum(1 for r in results if r['profit'] == 0)

print("="*100)
print(f"إجمالي الصفقات المنفذة فعلياً (آخر 30 يوم): {len(results)} صفقة.")
print(f"✅ صفقات رابحة: {wins}")
print(f"🛡️ صفقات تعادل (Break-Even): {bes}")
print(f"❌ صفقات خاسرة: {losses}")
if (wins+losses)>0:
    print(f"نسبة النجاح (استبعاد التعادل): {wins/(wins+losses)*100:.1f}%")
print(f"الرصيد النهائي: {account:.2f}$ (صافي الربح: +{((account-100)/100)*100:.2f}%)")
print("="*100)

